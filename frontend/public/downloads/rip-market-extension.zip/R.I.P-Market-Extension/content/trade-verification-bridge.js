"use strict";
(() => {
  // src/shared/trade-verification-runtime.ts
  var TRADE_VERIFICATION_RUNTIME = {
    GET_ACTIVE_TRADES: "RIP_MARKET_GET_ACTIVE_TRADES",
    VERIFY_TRADE: "RIP_MARKET_VERIFY_TRADE",
    ACK_TRADE: "RIP_MARKET_ACK_TRADE",
    REFRESH_ACTIVE_TRADES: "RIP_MARKET_REFRESH_ACTIVE_TRADES",
    REPORT_STEAM_OFFER_PAGE: "RIP_MARKET_REPORT_STEAM_OFFER_PAGE",
    RESOLVE_ASSET_FLOAT: "RIP_MARKET_RESOLVE_ASSET_FLOAT",
    GET_INVENTORY_PLATFORM_STATUS: "RIP_MARKET_GET_INVENTORY_PLATFORM_STATUS",
    GET_INVENTORY_PRICE_HINTS: "RIP_MARKET_GET_INVENTORY_PRICE_HINTS",
    /** Load CS2 enrichment facts from the Steam inventory tab MAIN world. */
    GET_INVENTORY_PAGE_FACTS: "RIP_MARKET_GET_INVENTORY_PAGE_FACTS",
    BROWSER_ASSIST_INVENTORY_SYNC: "RIP_MARKET_BROWSER_ASSIST_INVENTORY_SYNC",
    CREATE_INVENTORY_LOT: "RIP_MARKET_CREATE_INVENTORY_LOT",
    CREATE_INVENTORY_LOTS_BATCH: "RIP_MARKET_CREATE_INVENTORY_LOTS_BATCH",
    UPDATE_INVENTORY_LOT_PRICE: "RIP_MARKET_UPDATE_INVENTORY_LOT_PRICE",
    CANCEL_INVENTORY_LOT: "RIP_MARKET_CANCEL_INVENTORY_LOT",
    GET_SELLER_ONBOARDING_STATUS: "RIP_MARKET_GET_SELLER_ONBOARDING_STATUS",
    MANUAL_CREATE_OFFER: "RIP_MARKET_MANUAL_CREATE_OFFER"
  };

  // src/shared/trade-offer-observed-item.ts
  var SELLER_SLOT_ROOTS = [
    "#your_slots",
    "#trade_offer_your_slots"
  ];
  var BUYER_SLOT_ROOTS = [
    "#them_slots",
    "#trade_theirs",
    // Prefer the "their items" column — avoid broad wrappers that include both sides.
    ".tradeoffer_items.primary .tradeoffer_item_list",
    ".tradeoffer_items.primary"
  ];
  function parseAssetIdFromElement(element) {
    const dataAssetId = element.getAttribute("data-assetid")?.trim();
    if (dataAssetId) {
      return dataAssetId;
    }
    const elementId = element.id?.trim() ?? "";
    const steamItem = elementId.match(/^(?:item|asset)_?730_\d+_(\d+)/i);
    if (steamItem?.[1]) {
      return steamItem[1];
    }
    const suffixMatch = elementId.match(/_(\d{8,})$/);
    return suffixMatch?.[1] ?? null;
  }
  function parseMarketHashNameFromElement(element) {
    const title = element.getAttribute("title")?.trim();
    if (title) {
      return title;
    }
    const image = element.querySelector("img");
    const alt = image?.getAttribute("alt")?.trim();
    if (alt) {
      return alt;
    }
    return null;
  }
  function detectTradePageRole(pathname) {
    return pathname.includes("/tradeoffer/new") ? "seller" : "buyer";
  }
  function isInsideInventoryBrowser(element) {
    return Boolean(element.closest("#inventories, #inventory_box, .inventory_ctn"));
  }
  function parseObservedItemsFromTradeSlots(role, root = document) {
    const roots = role === "seller" ? SELLER_SLOT_ROOTS : BUYER_SLOT_ROOTS;
    const found = [];
    const seen = /* @__PURE__ */ new Set();
    for (const selector of roots) {
      const container = root.querySelector(selector);
      if (!container) {
        continue;
      }
      for (const element of Array.from(container.querySelectorAll(".item"))) {
        if (isInsideInventoryBrowser(element)) {
          continue;
        }
        const assetId = parseAssetIdFromElement(element);
        if (!assetId || seen.has(assetId)) {
          continue;
        }
        seen.add(assetId);
        found.push({
          assetId,
          marketHashName: parseMarketHashNameFromElement(element)
        });
      }
      if (found.length > 0) {
        return found;
      }
    }
    return found;
  }
  function parseObservedItemFromTradePage(role, root = document) {
    return parseObservedItemsFromTradeSlots(role, root)[0] ?? null;
  }

  // src/shared/seller-trade-offer-gate.ts
  function isDisplayed(element) {
    if (element.hasAttribute("hidden")) {
      return false;
    }
    if (element.style.display === "none" || element.style.visibility === "hidden") {
      return false;
    }
    return true;
  }
  function isCs2InventoryVisibleOnTradeOffer(root = document) {
    const candidates = [
      root.querySelector("#inventory_730_2"),
      root.querySelector("#inventory_730_16"),
      ...Array.from(
        root.querySelectorAll('#inventories [id^="inventory_730"]')
      )
    ].filter((el) => Boolean(el));
    return candidates.some(
      (el) => isDisplayed(el) && Boolean(el.querySelector(".item, .itemHolder .item"))
    );
  }
  function resolveSellerTradeOfferGate(params) {
    const root = params.root ?? document;
    const inSlots = parseObservedItemsFromTradeSlots("seller", root);
    if (inSlots.length > 0) {
      return "item_ready";
    }
    if (!isCs2InventoryVisibleOnTradeOffer(root)) {
      return "need_cs2";
    }
    return "need_item";
  }

  // src/shared/extension-i18n-core.ts
  var DEFAULT_EXTENSION_LOCALE = "ru";
  var EXTENSION_LOCALE_STORAGE_KEY = "rip:extension.locale";
  function isExtensionLocale(value) {
    return value === "ru" || value === "en";
  }
  function normalizeExtensionLocale(value, fallback = DEFAULT_EXTENSION_LOCALE) {
    if (isExtensionLocale(value)) {
      return value;
    }
    if (typeof value === "string") {
      const lower = value.trim().toLowerCase();
      if (lower.startsWith("en")) {
        return "en";
      }
      if (lower.startsWith("ru")) {
        return "ru";
      }
    }
    return fallback;
  }
  function getMessageByPath(tree, path) {
    const parts = path.split(".");
    let current = tree;
    for (const part of parts) {
      if (current == null || typeof current === "string") {
        return void 0;
      }
      current = current[part];
    }
    return typeof current === "string" ? current : void 0;
  }
  function interpolateExtension(template, params) {
    if (!params) {
      return template;
    }
    return template.replace(/\{\{(\w+)\}\}/g, (_match, key) => {
      const value = params[key];
      return value === void 0 || value === null ? "" : String(value);
    });
  }
  function translateExtension(tree, key, params) {
    const template = getMessageByPath(tree, key);
    if (template == null) {
      return key;
    }
    return interpolateExtension(template, params);
  }
  async function getStoredExtensionLocale() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local?.get) {
        const stored = await chrome.storage.local.get(EXTENSION_LOCALE_STORAGE_KEY);
        return normalizeExtensionLocale(stored[EXTENSION_LOCALE_STORAGE_KEY]);
      }
    } catch {
    }
    return DEFAULT_EXTENSION_LOCALE;
  }

  // src/shared/extension-messages-en.ts
  var extensionMessagesEn = {
    common: {
      openOrder: "Open order",
      openSite: "Open site",
      more: "More",
      loading: "Loading\u2026",
      cancel: "Cancel",
      buy: "Buy",
      sell: "Sell",
      buyer: "Buyer",
      seller: "Seller"
    },
    popup: {
      lead: "Deals and status \xB7 p2pcs",
      openSite: "Open site",
      refreshHealth: "Status",
      refreshTrades: "Deals",
      copyDebug: "Copy support report",
      copyDebugBusy: "Copying\u2026",
      copyDebugDone: "Copied \u2713",
      copyDebugOpened: "Copied \xB7 opening support",
      disconnect: "Disconnect",
      pairHint: "Connect the extension on the account page on p2pcs.ru.",
      advanced: "Advanced",
      toolsTitle: "Tools",
      healthTitle: "Health",
      trustTitle: "Trust",
      quietNotifyLabel: "Quiet notifications (deal / Guard / Accept / Mismatch)",
      quietNotifyNote: "Only when a deal state changes. Multiple events \u2192 one group alert. \u201CLater\u201D hides the card for 15 minutes. \u201CMute deal\u201D silences alerts until the deal ends.",
      supportEmergency: "Support \xB7 emergency access",
      apiKeyNote: "Not for everyday use. Paste a key only if R.I.P Market support explicitly asked \u2014 and only while Steam is broken.",
      apiKeyLabel: "Backup Steam Web API key",
      apiKeyPlaceholder: "Only if support asked you to",
      apiKeySave: "Save",
      apiKeyClear: "Clear",
      apiKeyStatusSaved: "Key stored locally; api.steampowered.com access granted only for fallback.",
      apiKeyStatusEmpty: "No key \u2014 the extension uses your Steam session in Chrome.",
      apiKeyPermissionDenied: "Chrome did not grant api.steampowered.com \u2014 key was not saved.",
      permissionsTitle: "Why these permissions",
      languageLabel: "Interface language",
      languageRu: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
      languageEn: "English",
      languageHint: "Synced from the site on pair; you can change it here.",
      buyersTitle: "Purchases",
      buyersSub: "Waiting for offer \xB7 verifying",
      sellersTitle: "Sales",
      sellersSub: "In progress \xB7 delivery check",
      receiptsTitle: "Recent deals",
      receiptsSub: "Compact list \xB7 tap for details",
      receiptsAllOnSite: "All deals on the site",
      receiptsMoreOnSite: "{{count}} more on the site",
      actionTitle: "Action needed",
      actionSub: "One primary step per card",
      snoozeLater: "Later",
      emptyTitle: "All quiet",
      emptyBody: "No deals need action right now."
    },
    safeMode: {
      offlineTitle: "Server link lost \xB7 safe mode",
      offlineBody: "The site page may still load in the browser, but the deals API is unreachable. Showing cache; listing and sending offers are paused until the link recovers.",
      degradedTitle: "Unstable link to the server",
      degradedBody: "Cached deals on screen. List / send are paused \u2014 confirm Guard or Accept only in Steam if the offer is already verified.",
      cacheLine: "Deal cache \xB7 {{when}}",
      cacheEmpty: "No cached deals yet \u2014 refresh when the API is back.",
      hint: "Safe mode: platform list and send are paused.",
      waitCta: "Waiting for server link",
      blockMessage: "Deals API unreachable or unstable \u2014 listing and sending offers are paused (safe mode)."
    },
    cta: {
      openDispute: "Open dispute",
      openDisputeSupport: "Open dispute / support",
      openOrder: "Open order",
      confirmGuard: "Confirm in Steam Mobile",
      openTradeUrl: "Open Trade URL",
      retrySend: "Retry send",
      retryAutoSend: "Retry auto-send",
      confirmSent: "I sent the trade",
      openVerifiedOffer: "Open verified offer",
      openVerifiedOfferSteam: "Open verified offer in Steam",
      preAcceptAck: "I see the correct offer",
      problemSupport: "Trade problem",
      confirmReceived: "Item is mine",
      openOfferSteam: "Open offer in Steam",
      platformStatus: "Status on site",
      refreshStatus: "Refresh status",
      waitSeller: "Waiting for seller",
      open: "Open",
      openAccount: "Open account",
      loginNeededSteam: "Sign in to the right Steam",
      loginSteam: "Sign in to Steam",
      openSteamInventory: "Open Steam inventory"
    },
    nextAction: {
      hintDisputeOpen: "A dispute is already open \u2014 evidence goes into the ticket. Do not accept other offers.",
      hintMismatch: "Do not accept this trade in Steam. Evidence (offerId, verify, time) will fill the ticket.",
      hintGuard: "The extension never confirms Guard \u2014 only you in Steam Mobile.",
      hintManualWithUrl: "Send the skin manually, then paste the offerId on the order.",
      hintManualRetry: "Auto-send could not finish \u2014 retry or open the order.",
      hintAccept: "Accept only with Steam\u2019s Accept button on this offer page.",
      hintConfirmReceived: "Confirm here \u2014 no need to return to the site.",
      hintVerifying: "The platform is checking delivery \u2014 usually nothing to do.",
      hintWaitSeller: "As soon as the offer appears, an accept button shows here.",
      hintWaitBuyer: "Offer is with the buyer. Status updates after they Accept."
    },
    dealConfirm: {
      acceptTitle: "Accept the trade in Steam",
      acceptBody: "Check the shield, then press Accept. We never accept for you.",
      receivedTitle: "Item with you?",
      receivedBody: "Confirm here \u2014 the site status updates on its own.",
      verifyingTitle: "Checking delivery",
      verifyingBody: "Matching Steam and inventory. Usually quick.",
      doneTitle: "Done",
      doneBody: "The platform has the deal. Open the order only if you need it.",
      guardTitle: "Confirm in Steam Mobile",
      guardBody: "Guard is only in the Steam app. Status updates here by itself."
    },
    badge: {
      rePair: "Connect",
      steam: "Steam",
      inventory: "Inventory",
      guard: "Guard",
      accept: "Accept",
      mismatch: "Mismatch",
      sendManual: "Manual",
      confirmSent: "Confirm",
      confirmReceived: "Received",
      reportIssue: "Issue"
    },
    connection: {
      revokedTitle: "Session expired",
      revokedDetail: "Reconnect the extension on the account page.",
      offTitle: "Not connected to the site",
      offDetail: "The site may already be open \u2014 go to Account \u2192 \u201CConnect extension\u201D (this is not a Chrome setting).",
      steamUnknown: "Steam: unknown",
      mismatchTitle: "Site connected \xB7 wrong Steam",
      mismatchDetail: "Steam does not match",
      noSteamTitle: "Site connected \xB7 not signed in to Steam",
      noSteamDetail: "Steam: no session",
      connectedUntil: "Connected until {{expires}}",
      connectedOkTitle: "Connected \xB7 site and Steam match",
      inventoryIssueTitle: "Steam OK \xB7 inventory issue",
      connectedTitle: "Connected",
      connectedDetail: "Site and Steam match \u2014 ready for deals.",
      steamAligned: "Site and Steam match"
    },
    buyerPhase: {
      wait_offer: "Waiting for offer",
      accept: "Accept",
      verifying: "Verifying",
      dispute: "Dispute / issue"
    },
    timeout: {
      expired: "Trade window expired \u2014 a dispute may open soon",
      minutes: "~{{minutes}} min left until auto-dispute",
      hoursMinutes: "~{{hours}} h {{minutes}} min left until auto-dispute"
    },
    settlement: {
      soonSuffix: "{{formatted}} (soon)",
      offerOk: "Steam offer: accepted",
      offerWarn: "Steam offer: problem",
      offerPending: "Steam offer: checking",
      offerUnknown: "Steam offer: clarifying",
      invOk: "Inventory: skin with buyer",
      invWarn: "Inventory: still with seller",
      invPending: "Inventory: checking",
      invUnknown: "Inventory: clarifying",
      deliveryTitleSeller: "Verifying delivery",
      deliveryTitleBuyer: "Item is yours \u2014 verifying delivery",
      deliveryBodySeller: "Matching Steam offer and inventory. No new offer needed for this deal.",
      deliveryBodyBuyer: "Nothing to do \u2014 the platform matches Steam offer and inventory.",
      fundsSellerKnown: "Funds available from: {{date}}",
      fundsSellerUnknown: "Funds available after the review window (up to {{days}} days)",
      fundsBuyerKnown: "Seller payout from: {{date}}",
      fundsBuyerUnknown: "Seller payout after the review window (up to {{days}} days)",
      holdTitleSeller: "Funds on hold",
      holdTitleBuyer: "Skin is yours \u2014 settlement on-platform",
      holdBodySeller: "Protects against chargebacks and Steam trade reversals. Payout to balance after hold.",
      holdBodyBuyer: "Item is in your inventory. Seller funds unlock after the on-platform review window."
    },
    dispute: {
      openTitle: "Dispute open",
      openBody: "Support is reviewing the deal. Do not accept other offers for this order and do not send money in chat.",
      needTitle: "Dispute needed",
      needMismatch: "Offer does not match the order. Do not press Accept \u2014 open a dispute with evidence (offerId, verify, time).",
      needGeneric: "There is a problem with this deal. Open a dispute \u2014 evidence fills the ticket automatically.",
      ticketPlaceholder: "(describe what went wrong)"
    },
    receipt: {
      eyebrow: "Receipt",
      bought: "Bought",
      sold: "Sold",
      price: "Deal price",
      commission: "Platform fee (5%)",
      paid: "You paid",
      credited: "Credited to balance",
      openOrder: "Open order"
    },
    session: {
      okTitle: "Ready for deals",
      okMessage: "Extension and Steam are connected.",
      disconnectedTitle: "Extension not connected",
      disconnectedMessage: "Open the site \u2192 Account \u2192 \u201CConnect extension\u201D.",
      disconnectedCta: "Open account on site",
      revokedTitle: "Extension session expired",
      revokedMessage: "Reconnect the extension on the account page.",
      revokedCta: "Connect on site",
      cookieTitle: "Not signed in to Steam",
      cookieMessage: "Sign in to steamcommunity.com in this Chrome with the seller account.",
      cookieCta: "Sign in to Steam",
      mismatchTitle: "Wrong Steam in the browser",
      mismatchMessage: "Chrome is signed in as {{session}}, need {{expected}}",
      mismatchCta: "Sign in to the right Steam",
      privateTitle: "Inventory is private",
      privateMessage: "Make your CS2 inventory visible to the extension (Privacy \u2192 Inventory: Public).",
      privateCta: "Open Steam settings",
      rateTitle: "Steam temporarily limited requests",
      rateMessage: "Wait 1\u20132 minutes and tap \u201CCheck again\u201D. No Steam key needed \u2014 if it lasts, contact support.",
      rateCta: "Open Steam inventory",
      inventoryTitle: "Inventory failed to load",
      inventoryMessage: "Open your CS2 inventory in Steam and check again.",
      inventoryCta: "Open Steam inventory"
    },
    notify: {
      guardTitle: "Sale \u2014 confirm Guard",
      guardBody: "{{short}} \xB7 {{item}}. Open Steam Mobile and confirm the trade.",
      acceptTitle: "Purchase \u2014 offer ready to accept",
      acceptBody: "{{short}} \xB7 {{item}}. Open the verified offer in Steam.",
      mismatchTitle: "Mismatch \u2014 do not accept",
      mismatchBody: "{{short}} \xB7 {{item}}. Skin mismatch \u2014 do not press Accept.",
      newDealTitle: "New sale \u2014 sending the trade",
      newDealBody: "{{short}} \xB7 {{item}}. Keep Steam open \u2014 the extension will send the offer.",
      groupMismatch: "Several mismatches \u2014 do not accept",
      groupGuard: "Several sales waiting for Guard",
      groupAccept: "Several purchases waiting to accept",
      groupNewDeal: "Several new sales",
      groupBody: "{{count}} deals need action",
      muteDeal: "Mute deal"
    },
    cardContext: {
      buy: "Buy",
      sell: "Sell",
      dispute: "Dispute",
      mismatch: "Mismatch",
      waitGuard: "Waiting for Guard",
      waitAccept: "Waiting for Accept",
      sendManual: "Send manually",
      confirmSent: "Confirm sent",
      confirmReceived: "Confirm received",
      platformCheck: "Platform check",
      completed: "Completed",
      offerReady: "Offer ready",
      waitBuyer: "Waiting for buyer",
      checking: "Checking\u2026",
      waitTrade: "Waiting for trade",
      tradeConfirmed: "Trade confirmed",
      hold: "Hold / settlement",
      failed: "Failed",
      canceled: "Canceled",
      inProgress: "In progress"
    },
    guided: {
      mismatchTitle: "Mismatch \u2014 do not accept",
      mismatchBuyer: "This offer does not match the R.I.P Market order. Do not press Accept in Steam.",
      mismatchSeller: "Offer does not match the order. Check on the site and do not ask the buyer to accept.",
      verifiedTitle: "Skin matched",
      verifiedBuyer: "You can accept with Steam\u2019s button on this page. Funds are already on the platform \u2014 do not pay in chat.",
      verifiedSeller: "Trade matched the order. Follow the next step on the site / Guard.",
      partialTitle: "Checking\u2026",
      partialBody: "Some checks are still running. Wait \u2014 do not rush Accept yet.",
      pendingTitle: "Waiting for verification",
      pendingBody: "Matching the offer to the R.I.P Market order.",
      name: "Name",
      stickers: "Stickers",
      partner: "Partner SteamID",
      assetId: "Asset ID",
      wear: "Wear",
      float: "Float",
      hintBlock: "Do not accept this trade in Steam",
      hintAccept: "Accept the trade with Steam\u2019s button on this page",
      hintWait: "Wait for verification to finish \u2014 do not rush Accept"
    },
    offerGate: {
      needCs2Title: "Select CS2",
      needCs2Body: "In the inventory list on the left, choose Counter-Strike 2. The extension will add the deal skin.",
      needItemTitle: "Add the skin to the trade",
      needItemBody: "Needed item: {{name}}. Click it in your inventory \u2014 it should appear under \u201CYour items\u201D.",
      itemReadyTitle: "Skin is in the offer",
      itemReadyBody: "Check the shield, then press \u201CMake Offer\u201D in Steam. Guard is confirmed only in the Steam app."
    },
    shield: {
      dealLine: "Order #{{short}} \xB7 {{amount}}",
      wear: "Wear",
      float: "Float",
      stickers: "Stickers",
      unknownPartner: "Counterparty",
      partnerMatch: "Steam partner matches",
      partnerMismatch: "Steam partner MISMATCH \u2014 do not accept",
      partnerMissingObserved: "Could not read partner from the Steam page",
      partnerMissingExpected: "Order has no counterparty SteamID",
      partnerUnknown: "Partner not recognized",
      partnerMatchCheck: "Partner SteamID matches the order",
      partnerMismatchCheck: "Partner SteamID does not match the order",
      partnerMissingObservedCheck: "Partner SteamID not found on the page",
      partnerMissingExpectedCheck: "Order has no counterparty SteamID",
      copySteamId: "Copy",
      copied: "Copied",
      openProfile: "Steam profile",
      steamIdMissing: "SteamID unavailable",
      expectedCol: "Expected",
      observedCol: "In offer",
      preSendTitle: "Before you send",
      preSendBody: "Confirm the buyer and item. Confirm Guard only in Steam Mobile.",
      compareTitle: "Match against Steam"
    },
    acceptAssist: {
      acceptSteam: "Accept (Steam)",
      confirmAccept: "Confirm Accept in Steam",
      cancel: "Cancel",
      openVerified: "Open verified offer #{{short}} and accept with Steam\u2019s button",
      acceptNotFound: "Steam Accept button not found. Press the green Accept on the page manually.",
      acceptClickFailed: "Could not click Accept. Press Steam\u2019s green button manually.",
      doubleConfirm: "Confirm again \u2014 only then we click Accept in Steam. We never auto-accept.",
      guardHint: "If Steam asks for Guard \u2014 confirm in Steam Mobile.",
      confirmAgain: "If Confirm appears \u2014 tap \u201CAccept (Steam)\u201D again, or Confirm in Steam.",
      commandSent: "Command sent to Steam. {{guardHint}}",
      assistFailed: "Could not help with Accept. Press Steam\u2019s green button on the page.",
      highlightHint: "We highlight Steam\u2019s button. Accept only after your second confirmation."
    },
    manualCreate: {
      buildOffer: "Build offer #{{short}}",
      autoFailed: "Auto-send failed \u2014 we will build the offer via Steam UI: item + buyer Trade URL.",
      canBuild: "You can build the offer manually with the same autofill as auto-send."
    },
    ops: {
      never: "never yet",
      justNow: "just now",
      secondsAgo: "{{seconds}}s ago",
      minutesAgo: "{{minutes}} min ago",
      hoursAgo: "{{hours}} h ago",
      pollStale: "Poll stale \xB7 {{age}}",
      pollNever: "Poll: no successful run yet",
      pollOld: "Poll old \xB7 {{age}}",
      pollOk: "Poll: {{age}}",
      rateLimited: "Steam: rate limit \u2014 wait 1\u20132 min",
      rateOk: "Steam: no rate limit",
      version: "Version {{version}}",
      updateExtension: "Update extension"
    },
    onboarding: {
      coachTitle: "Sell on R.I.P right from here",
      coachBody: "List here \u2014 the trade goes out on purchase. You confirm Guard only in Steam Mobile.",
      coachDismiss: "Got it",
      autoHideHint: "Hides in ~30 sec",
      extensionReady: "Extension connected",
      extensionHint: "Pairing with the site is needed for prices, listing, and auto-trade.",
      extensionAction: "Connect",
      tradeUrlTitle: "Trade URL on the site",
      tradeUrlHint: "Without a Trade URL buyers cannot receive the trade after paying.",
      tradeUrlAction: "Add Trade URL",
      checklistTitle: "Seller readiness",
      checklistReady: "All set \u2014 you can list from Steam",
      checklistProgress: "Ready {{ready}} of {{total}}"
    },
    twoMin: {
      title: "Start",
      lead: "Four steps \u2014 then deals run themselves.",
      progress: "{{ready}} / {{total}}",
      stepInstall: "Extension installed",
      hintInstall: "You\u2019re already here \u2014 this step is done.",
      stepPair: "Connect to the site",
      hintPair: "Account \u2192 \u201CConnect extension\u201D on p2pcs.ru.",
      stepInventory: "Open CS2 inventory",
      hintInventory: "Steam Community \u2192 Inventory \u2192 Counter-Strike 2.",
      stepList: "Trial list",
      hintList: "Pick a skin \u2192 blue \u201CSell\u201D on the card. Guard later only in Mobile.",
      ctaPair: "Open account on site",
      ctaInventory: "Open CS2 inventory",
      ctaList: "List your first skin",
      ctaDone: "Done",
      dismiss: "Later",
      trialTitle: "Trial list (~30 sec)",
      trialBody: "On a skin card in the grid, tap blue \u201CSell\u201D (not Steam\u2019s green Sell on the right). This checks the path \u2014 not play money.",
      trialDismiss: "Hide tip"
    },
    overlay: {
      brand: "R.I.P Market",
      openDispute: "Open dispute",
      openDisputeSupport: "Open dispute / support",
      openOrder: "Open order"
    },
    inventory: {
      layerBrand: "R.I.P Market",
      steamEnrichmentDegraded: "Some Steam float/prices are still loading \u2014 blue \u201CSell\u201D on cards is already available."
    }
  };

  // src/shared/extension-messages-ru.ts
  var extensionMessagesRu = {
    common: {
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437",
      openSite: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u0430\u0439\u0442",
      more: "\u0415\u0449\u0451",
      loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026",
      cancel: "\u041E\u0442\u043C\u0435\u043D\u0430",
      buy: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430",
      sell: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430",
      buyer: "\u041F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044C",
      seller: "\u041F\u0440\u043E\u0434\u0430\u0432\u0435\u0446"
    },
    popup: {
      lead: "\u0421\u0434\u0435\u043B\u043A\u0438 \u0438 \u0441\u0442\u0430\u0442\u0443\u0441 \xB7 p2pcs",
      openSite: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u0430\u0439\u0442",
      refreshHealth: "\u0421\u0442\u0430\u0442\u0443\u0441",
      refreshTrades: "\u0421\u0434\u0435\u043B\u043A\u0438",
      copyDebug: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043E\u0442\u0447\u0451\u0442",
      copyDebugBusy: "\u041A\u043E\u043F\u0438\u0440\u0443\u0435\u043C\u2026",
      copyDebugDone: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u2713",
      copyDebugOpened: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E \xB7 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u043C \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      disconnect: "\u041E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      pairHint: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430 \u043D\u0430 p2pcs.ru.",
      advanced: "\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E",
      toolsTitle: "\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B",
      healthTitle: "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435",
      trustTitle: "\u0414\u043E\u0432\u0435\u0440\u0438\u0435",
      quietNotifyLabel: "\u0422\u043E\u043B\u044C\u043A\u043E \u0432\u0430\u0436\u043D\u044B\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043F\u043E \u0441\u0434\u0435\u043B\u043A\u0430\u043C",
      quietNotifyNote: "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0438 \u0441\u043C\u0435\u043D\u0435 \u0441\u0442\u0430\u0442\u0443\u0441\u0430 \u0441\u0434\u0435\u043B\u043A\u0438. \u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u2192 \u043E\u0434\u043D\u043E \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0435. \xAB\u041F\u043E\u0437\u0436\u0435\xBB \u043F\u0440\u044F\u0447\u0435\u0442 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u043D\u0430 15 \u043C\u0438\u043D\u0443\u0442. \xAB\u0421\u043A\u0440\u044B\u0442\u044C \u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0443\xBB \u0433\u043B\u0443\u0448\u0438\u0442 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u0434\u043E \u043A\u043E\u043D\u0446\u0430 \u0441\u0434\u0435\u043B\u043A\u0438.",
      supportEmergency: "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \xB7 \u0430\u0432\u0430\u0440\u0438\u0439\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F",
      apiKeyNote: "\u041D\u0435 \u0434\u043B\u044F \u043E\u0431\u044B\u0447\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u044B. \u0412\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u043A\u043B\u044E\u0447 \u0442\u043E\u043B\u044C\u043A\u043E \u0435\u0441\u043B\u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 R.I.P Market \u044F\u0432\u043D\u043E \u043F\u043E\u043F\u0440\u043E\u0441\u0438\u043B\u0430 \u2014 \u0438 \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 \u0432\u0440\u0435\u043C\u044F \u0441\u0431\u043E\u044F Steam.",
      apiKeyLabel: "\u0417\u0430\u043F\u0430\u0441\u043D\u043E\u0439 Steam Web API key",
      apiKeyPlaceholder: "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u043E \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0438",
      apiKeySave: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",
      apiKeyClear: "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C",
      apiKeyStatusSaved: "\u041A\u043B\u044E\u0447 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E; \u0434\u043E\u0441\u0442\u0443\u043F \u043A api.steampowered.com \u0432\u044B\u0434\u0430\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F fallback.",
      apiKeyStatusEmpty: "\u041A\u043B\u044E\u0447 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D \u2014 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u0432\u0430\u0448\u0443 \u0441\u0435\u0441\u0441\u0438\u044E Steam \u0432 Chrome.",
      apiKeyPermissionDenied: "Chrome \u043D\u0435 \u0432\u044B\u0434\u0430\u043B \u0434\u043E\u0441\u0442\u0443\u043F \u043A api.steampowered.com \u2014 \u043A\u043B\u044E\u0447 \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D.",
      permissionsTitle: "\u0417\u0430\u0447\u0435\u043C \u043D\u0443\u0436\u043D\u044B \u043F\u0440\u0430\u0432\u0430",
      languageLabel: "\u042F\u0437\u044B\u043A \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u0430",
      languageRu: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
      languageEn: "English",
      languageHint: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0441 \u0441\u0430\u0439\u0442\u043E\u043C \u043F\u0440\u0438 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0438; \u043C\u043E\u0436\u043D\u043E \u0441\u043C\u0435\u043D\u0438\u0442\u044C \u0437\u0434\u0435\u0441\u044C.",
      buyersTitle: "\u041F\u043E\u043A\u0443\u043F\u043A\u0438",
      buyersSub: "\u0416\u0434\u0451\u043C \u043E\u0444\u0444\u0435\u0440 \xB7 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F",
      sellersTitle: "\u041F\u0440\u043E\u0434\u0430\u0436\u0438",
      sellersSub: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435 \xB7 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438",
      receiptsTitle: "\u041D\u0435\u0434\u0430\u0432\u043D\u0438\u0435 \u0441\u0434\u0435\u043B\u043A\u0438",
      receiptsSub: "\u041A\u0440\u0430\u0442\u043A\u0438\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \xB7 \u0434\u0435\u0442\u0430\u043B\u0438 \u043F\u043E \u043A\u043B\u0438\u043A\u0443",
      receiptsAllOnSite: "\u0412\u0441\u0435 \u0441\u0434\u0435\u043B\u043A\u0438 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      receiptsMoreOnSite: "\u0415\u0449\u0451 {{count}} \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      actionTitle: "\u041D\u0443\u0436\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435",
      actionSub: "\u041E\u0434\u0438\u043D \u0433\u043B\u0430\u0432\u043D\u044B\u0439 \u0448\u0430\u0433 \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435",
      snoozeLater: "\u041F\u043E\u0437\u0436\u0435",
      emptyTitle: "\u0412\u0441\u0451 \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u043E",
      emptyBody: "\u041D\u0435\u0442 \u0441\u0434\u0435\u043B\u043E\u043A, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u044F\u043C\u043E \u0441\u0435\u0439\u0447\u0430\u0441."
    },
    safeMode: {
      offlineTitle: "\u0421\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u0430 \xB7 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C",
      offlineBody: "\u0421\u0430\u0439\u0442 \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435 \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0442\u044C\u0441\u044F, \u043D\u043E API \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u041F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u043C \u043A\u044D\u0448; \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043E\u0444\u0444\u0435\u0440\u043E\u0432 \u0441 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B, \u043F\u043E\u043A\u0430 \u0441\u0432\u044F\u0437\u044C \u043D\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0441\u044F.",
      degradedTitle: "\u0421\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430",
      degradedBody: "\u041A\u044D\u0448 \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435. \u0412\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u2014 Guard \u0438\u043B\u0438 Accept \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Steam, \u0435\u0441\u043B\u0438 \u043E\u0444\u0444\u0435\u0440 \u0443\u0436\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D.",
      cacheLine: "\u041A\u044D\u0448 \u0441\u0434\u0435\u043B\u043E\u043A \xB7 {{when}}",
      cacheEmpty: "\u041A\u044D\u0448\u0430 \u0441\u0434\u0435\u043B\u043E\u043A \u043F\u043E\u043A\u0430 \u043D\u0435\u0442 \u2014 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435, \u043A\u043E\u0433\u0434\u0430 API \u043E\u0436\u0438\u0432\u0451\u0442.",
      hint: "\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C: list \u0438 send \u0441 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B.",
      waitCta: "\u0416\u0434\u0451\u043C \u0441\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C",
      blockMessage: "API \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0438\u043B\u0438 \u0441\u0432\u044F\u0437\u044C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430 \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043E\u0444\u0444\u0435\u0440\u043E\u0432 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B (\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C)."
    },
    cta: {
      openDispute: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440",
      openDisputeSupport: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440 / \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437",
      confirmGuard: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile",
      openTradeUrl: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C Trade URL",
      retrySend: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      retryAutoSend: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0430\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      confirmSent: "\u042F \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043B \u043E\u0431\u043C\u0435\u043D",
      openVerifiedOffer: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440",
      openVerifiedOfferSteam: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u0432 Steam",
      preAcceptAck: "\u0412\u0438\u0436\u0443 \u0432\u0435\u0440\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435",
      problemSupport: "\u041F\u0440\u043E\u0431\u043B\u0435\u043C\u0430 \u0441 \u043E\u0431\u043C\u0435\u043D\u043E\u043C",
      confirmReceived: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u043C\u0435\u043D\u044F",
      openOfferSteam: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u0444\u0444\u0435\u0440 \u0432 Steam",
      platformStatus: "\u0421\u0442\u0430\u0442\u0443\u0441 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      refreshStatus: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0430\u0442\u0443\u0441",
      waitSeller: "\u0416\u0434\u0451\u043C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      open: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C",
      openAccount: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442",
      loginNeededSteam: "\u0412\u043E\u0439\u0442\u0438 \u0432 \u043D\u0443\u0436\u043D\u044B\u0439 Steam",
      loginSteam: "\u0412\u043E\u0439\u0442\u0438 \u0432 Steam",
      openSteamInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam"
    },
    nextAction: {
      hintDisputeOpen: "\u0421\u043F\u043E\u0440 \u0443\u0436\u0435 \u043E\u0442\u043A\u0440\u044B\u0442 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0443\u0439\u0434\u0451\u0442 \u0432 \u0442\u0438\u043A\u0435\u0442. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u0438\u0435 \u043E\u0444\u0444\u0435\u0440\u044B.",
      hintMismatch: "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u0432 Steam. \u0414\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u0441\u044F \u0432 \u0442\u0438\u043A\u0435\u0442.",
      hintGuard: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 Guard \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u044B \u0432 Steam Mobile.",
      hintManualWithUrl: "\u041E\u0442\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0441\u043A\u0438\u043D \u0432\u0440\u0443\u0447\u043D\u0443\u044E, \u0437\u0430\u0442\u0435\u043C \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 offerId \u043D\u0430 \u0437\u0430\u043A\u0430\u0437\u0435.",
      hintManualRetry: "\u0410\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043D\u0435 \u0441\u043C\u043E\u0433\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C\u0441\u044F \u2014 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437.",
      hintAccept: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Accept \u0432 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043E\u0444\u0444\u0435\u0440\u0430.",
      hintConfirmReceived: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u043D\u0430 \u0441\u0430\u0439\u0442 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.",
      hintVerifying: "\u041F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u0441\u0432\u0435\u0440\u044F\u0435\u0442 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443 \u2014 \u043E\u0431\u044B\u0447\u043D\u043E \u043D\u0438\u0447\u0435\u0433\u043E \u0434\u0435\u043B\u0430\u0442\u044C \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.",
      hintWaitSeller: "\u041A\u0430\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0444\u0444\u0435\u0440 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u2014 \u0437\u0434\u0435\u0441\u044C \u0431\u0443\u0434\u0435\u0442 \u043A\u043D\u043E\u043F\u043A\u0430 \u043F\u0440\u0438\u043D\u044F\u0442\u044C.",
      hintWaitBuyer: "\u041E\u0431\u043C\u0435\u043D \u0443 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F. \u0421\u0442\u0430\u0442\u0443\u0441 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0441\u0430\u043C \u043F\u043E\u0441\u043B\u0435 Accept."
    },
    dealConfirm: {
      acceptTitle: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u0432 Steam",
      acceptBody: "\u0421\u0432\u0435\u0440\u044C\u0442\u0435 \u0449\u0438\u0442 \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 Accept. \u041C\u044B \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C \u0437\u0430 \u0432\u0430\u0441.",
      receivedTitle: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u0432\u0430\u0441?",
      receivedBody: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u0441\u0442\u0430\u0442\u0443\u0441 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0441\u0430\u043C.",
      verifyingTitle: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      verifyingBody: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C Steam \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C. \u041E\u0431\u044B\u0447\u043D\u043E \u0436\u0434\u0430\u0442\u044C \u043D\u0435\u0434\u043E\u043B\u0433\u043E.",
      doneTitle: "\u0413\u043E\u0442\u043E\u0432\u043E",
      doneBody: "\u0421\u0434\u0435\u043B\u043A\u0430 \u0443 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438. \u0417\u0430\u043A\u0430\u0437 \u043C\u043E\u0436\u043D\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438.",
      guardTitle: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile",
      guardBody: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443 \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438 Steam. \u0415\u0441\u043B\u0438 \u0441\u0442\u0430\u0442\u0443\u0441 \u0437\u0430\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F, \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435."
    },
    badge: {
      rePair: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      steam: "Steam",
      inventory: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C",
      guard: "Guard",
      accept: "Accept",
      mismatch: "Mismatch",
      sendManual: "\u0412\u0440\u0443\u0447\u043D\u0443\u044E",
      confirmSent: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C",
      confirmReceived: "\u041F\u043E\u043B\u0443\u0447\u0435\u043D\u043E",
      reportIssue: "\u041F\u0440\u043E\u0431\u043B\u0435\u043C\u0430"
    },
    connection: {
      revokedTitle: "\u0421\u0435\u0441\u0441\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u0430",
      revokedDetail: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430.",
      offTitle: "\u041D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u043A \u0441\u0430\u0439\u0442\u0443",
      offDetail: "\u0421\u0430\u0439\u0442 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442 \u2014 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB (\u044D\u0442\u043E \u043D\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 Chrome).",
      steamUnknown: "Steam: \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E",
      mismatchTitle: "\u0421\u0430\u0439\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \xB7 \u0434\u0440\u0443\u0433\u043E\u0439 Steam",
      mismatchDetail: "Steam \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      noSteamTitle: "\u0421\u0430\u0439\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \xB7 \u043D\u0435\u0442 \u0432\u0445\u043E\u0434\u0430 \u0432 Steam",
      noSteamDetail: "Steam: \u043D\u0435\u0442 \u0441\u0435\u0441\u0441\u0438\u0438",
      connectedUntil: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u0434\u043E {{expires}}",
      connectedOkTitle: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \xB7 \u0441\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442",
      inventoryIssueTitle: "Steam \u043E\u043A \xB7 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u0441 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u043E\u0439",
      connectedTitle: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      connectedDetail: "\u0421\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442 \u2014 \u043C\u043E\u0436\u043D\u043E \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0441\u043E \u0441\u0434\u0435\u043B\u043A\u0430\u043C\u0438.",
      steamAligned: "\u0421\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442"
    },
    buyerPhase: {
      wait_offer: "\u0416\u0434\u0451\u043C \u043E\u0444\u0444\u0435\u0440",
      accept: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C",
      verifying: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F",
      dispute: "\u0421\u043F\u043E\u0440 / \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430"
    },
    timeout: {
      expired: "\u0412\u0440\u0435\u043C\u044F \u043D\u0430 \u043E\u0431\u043C\u0435\u043D \u0438\u0441\u0442\u0435\u043A\u043B\u043E \u2014 \u0441\u043A\u043E\u0440\u043E \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0442\u044C\u0441\u044F \u0441\u043F\u043E\u0440",
      minutes: "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ~{{minutes}} \u043C\u0438\u043D \u0434\u043E \u0430\u0432\u0442\u043E\u0441\u043F\u043E\u0440\u0430",
      hoursMinutes: "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ~{{hours}} \u0447 {{minutes}} \u043C\u0438\u043D \u0434\u043E \u0430\u0432\u0442\u043E\u0441\u043F\u043E\u0440\u0430"
    },
    settlement: {
      soonSuffix: "{{formatted}} (\u0441\u043A\u043E\u0440\u043E)",
      offerOk: "Steam offer: \u043F\u0440\u0438\u043D\u044F\u0442",
      offerWarn: "Steam offer: \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430",
      offerPending: "Steam offer: \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C",
      offerUnknown: "Steam offer: \u0443\u0442\u043E\u0447\u043D\u044F\u0435\u043C",
      invOk: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0441\u043A\u0438\u043D \u0443 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F",
      invWarn: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0435\u0449\u0451 \u0443 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      invPending: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C",
      invUnknown: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0443\u0442\u043E\u0447\u043D\u044F\u0435\u043C",
      deliveryTitleSeller: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      deliveryTitleBuyer: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u0432\u0430\u0441 \u2014 \u0441\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      deliveryBodySeller: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C Steam offer \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C. \u041D\u043E\u0432\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u043F\u043E \u044D\u0442\u043E\u0439 \u0441\u0434\u0435\u043B\u043A\u0435 \u043D\u0435 \u043D\u0443\u0436\u0435\u043D.",
      deliveryBodyBuyer: "\u041D\u0438\u0447\u0435\u0433\u043E \u0434\u0435\u043B\u0430\u0442\u044C \u043D\u0435 \u043D\u0443\u0436\u043D\u043E \u2014 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u0441\u0432\u0435\u0440\u044F\u0435\u0442 Steam offer \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C.",
      fundsSellerKnown: "\u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0431\u0443\u0434\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B: {{date}}",
      fundsSellerUnknown: "\u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0431\u0443\u0434\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 (\u0434\u043E {{days}} \u0434\u043D.)",
      fundsBuyerKnown: "\u0412\u044B\u043F\u043B\u0430\u0442\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u0441: {{date}}",
      fundsBuyerUnknown: "\u0412\u044B\u043F\u043B\u0430\u0442\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 (\u0434\u043E {{days}} \u0434\u043D.)",
      holdTitleSeller: "\u0412\u044B\u0440\u0443\u0447\u043A\u0430 \u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0435",
      holdTitleBuyer: "\u0421\u043A\u0438\u043D \u0432\u0430\u0448 \u2014 \u0440\u0430\u0441\u0447\u0451\u0442 \u0443 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438",
      holdBodySeller: "\u0417\u0430\u0449\u0438\u0442\u0430 \u043E\u0442 chargeback \u0438 \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u0430 \u043E\u0431\u043C\u0435\u043D\u0430 \u0432 Steam. \u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0441\u0442\u0430\u043D\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u043F\u043E\u0441\u043B\u0435 \u043F\u0435\u0440\u0438\u043E\u0434\u0430 \u0437\u0430\u0449\u0438\u0442\u044B.",
      holdBodyBuyer: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0432 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u0435. \u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u2014 \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435."
    },
    dispute: {
      openTitle: "\u0421\u043F\u043E\u0440 \u043E\u0442\u043A\u0440\u044B\u0442",
      openBody: "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \u0440\u0430\u0437\u0431\u0438\u0440\u0430\u0435\u0442 \u0441\u0434\u0435\u043B\u043A\u0443. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u0438\u0435 \u043E\u0444\u0444\u0435\u0440\u044B \u043F\u043E \u044D\u0442\u043E\u043C\u0443 \u0437\u0430\u043A\u0430\u0437\u0443 \u0438 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442\u0435 \u0434\u0435\u043D\u044C\u0433\u0438 \u0432 \u0447\u0430\u0442.",
      needTitle: "\u041D\u0443\u0436\u0435\u043D \u0441\u043F\u043E\u0440",
      needMismatch: "\u041E\u0444\u0444\u0435\u0440 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u041D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435 Accept \u2014 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u043F\u043E\u0440 \u0441 \u0434\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438.",
      needGeneric: "\u0415\u0441\u0442\u044C \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430 \u043F\u043E \u0441\u0434\u0435\u043B\u043A\u0435. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u043F\u043E\u0440 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u0441\u044F \u0432 \u0442\u0438\u043A\u0435\u0442 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438.",
      ticketPlaceholder: "(\u043E\u043F\u0438\u0448\u0438\u0442\u0435, \u0447\u0442\u043E \u043F\u043E\u0448\u043B\u043E \u043D\u0435 \u0442\u0430\u043A)"
    },
    receipt: {
      eyebrow: "\u041A\u0432\u0438\u0442\u0430\u043D\u0446\u0438\u044F",
      bought: "\u041A\u0443\u043F\u0438\u043B\u0438",
      sold: "\u041F\u0440\u043E\u0434\u0430\u043B\u0438",
      price: "\u0426\u0435\u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0438",
      commission: "\u041A\u043E\u043C\u0438\u0441\u0441\u0438\u044F \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 (5%)",
      paid: "\u041E\u043F\u043B\u0430\u0442\u0438\u043B\u0438",
      credited: "\u041A \u0437\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044E",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437"
    },
    session: {
      okTitle: "\u0413\u043E\u0442\u043E\u0432\u043E \u043A \u0441\u0434\u0435\u043B\u043A\u0430\u043C",
      okMessage: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0438 Steam \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u044B.",
      disconnectedTitle: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      disconnectedMessage: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0430\u0439\u0442 \u2192 \u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB.",
      disconnectedCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      revokedTitle: "\u0421\u0435\u0441\u0441\u0438\u044F \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u0430",
      revokedMessage: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430.",
      revokedCta: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      cookieTitle: "\u041D\u0435\u0442 \u0432\u0445\u043E\u0434\u0430 \u0432 Steam",
      cookieMessage: "\u0412\u043E\u0439\u0434\u0438\u0442\u0435 \u0432 steamcommunity.com \u0432 \u044D\u0442\u043E\u043C Chrome \u043F\u043E\u0434 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u043E\u043C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430.",
      cookieCta: "\u0412\u043E\u0439\u0442\u0438 \u0432 Steam",
      mismatchTitle: "\u0414\u0440\u0443\u0433\u043E\u0439 Steam \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435",
      mismatchMessage: "\u0412 Chrome \u0437\u0430\u043B\u043E\u0433\u0438\u043D\u0435\u043D {{session}}, \u043D\u0443\u0436\u0435\u043D {{expected}}",
      mismatchCta: "\u0412\u043E\u0439\u0442\u0438 \u0432 \u043D\u0443\u0436\u043D\u044B\u0439 Steam",
      privateTitle: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u0441\u043A\u0440\u044B\u0442",
      privateMessage: "\u0421\u0434\u0435\u043B\u0430\u0439\u0442\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2 \u0432\u0438\u0434\u0438\u043C\u044B\u043C \u0434\u043B\u044F \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F (Privacy \u2192 Inventory: Public).",
      privateCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 Steam",
      rateTitle: "Steam \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0438\u043B \u0437\u0430\u043F\u0440\u043E\u0441\u044B",
      rateMessage: "\u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 1\u20132 \u043C\u0438\u043D\u0443\u0442\u044B \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0441\u043D\u043E\u0432\u0430\xBB. \u041A\u043B\u044E\u0447 Steam \u043D\u0435 \u043D\u0443\u0436\u0435\u043D \u2014 \u043F\u0440\u0438 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u043C \u0441\u0431\u043E\u0435 \u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 \u0432 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443.",
      rateCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam",
      inventoryTitle: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u043B\u0441\u044F",
      inventoryMessage: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2 \u0432 Steam \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443.",
      inventoryCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam"
    },
    notify: {
      guardTitle: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430 \u2014 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 Guard",
      guardBody: "{{short}} \xB7 {{item}}. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 Steam Mobile \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D.",
      acceptTitle: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430 \u2014 \u043E\u0444\u0444\u0435\u0440 \u0433\u043E\u0442\u043E\u0432 \u043A accept",
      acceptBody: "{{short}} \xB7 {{item}}. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u0432 Steam.",
      mismatchTitle: "Mismatch \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      mismatchBody: "{{short}} \xB7 {{item}}. \u0421\u043A\u0438\u043D \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u2014 \u043D\u0435 \u0436\u043C\u0438\u0442\u0435 Accept.",
      newDealTitle: "\u041D\u043E\u0432\u0430\u044F \u043F\u0440\u043E\u0434\u0430\u0436\u0430 \u2014 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u043C \u043E\u0431\u043C\u0435\u043D",
      newDealBody: "{{short}} \xB7 {{item}}. \u041E\u0441\u0442\u0430\u0432\u044C\u0442\u0435 Steam \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u043C \u2014 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442 offer.",
      groupMismatch: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E mismatch \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      groupGuard: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E\u0434\u0430\u0436 \u0436\u0434\u0443\u0442 Guard",
      groupAccept: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u043A\u0443\u043F\u043E\u043A \u0436\u0434\u0443\u0442 accept",
      groupNewDeal: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043D\u043E\u0432\u044B\u0445 \u043F\u0440\u043E\u0434\u0430\u0436",
      groupBody: "{{count}} \u0441\u0434\u0435\u043B\u043A\u0438 \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F",
      muteDeal: "\u0421\u043A\u0440\u044B\u0442\u044C \u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0443"
    },
    cardContext: {
      buy: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430",
      sell: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430",
      dispute: "\u0421\u043F\u043E\u0440",
      mismatch: "\u041D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      waitGuard: "\u0416\u0434\u0451\u043C Guard",
      waitAccept: "\u0416\u0434\u0451\u0442 Accept",
      sendManual: "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0432\u0440\u0443\u0447\u043D\u0443\u044E",
      confirmSent: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      confirmReceived: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u0435",
      platformCheck: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438",
      completed: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E",
      offerReady: "\u041E\u0444\u0444\u0435\u0440 \u0433\u043E\u0442\u043E\u0432",
      waitBuyer: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F",
      checking: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u2026",
      waitTrade: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043E\u0431\u043C\u0435\u043D",
      tradeConfirmed: "\u041E\u0431\u043C\u0435\u043D \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D",
      hold: "Hold / \u0440\u0430\u0441\u0447\u0451\u0442",
      failed: "\u0412\u043E\u0437\u0432\u0440\u0430\u0442",
      canceled: "\u041E\u0442\u043C\u0435\u043D\u0451\u043D",
      inProgress: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435"
    },
    guided: {
      mismatchTitle: "\u041D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      mismatchBuyer: "\u042D\u0442\u043E\u0442 offer \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C R.I.P Market. \u041D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435 Accept \u0432 Steam.",
      mismatchSeller: "Offer \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u0438 \u043D\u0435 \u043F\u0440\u043E\u0441\u0438\u0442\u0435 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C.",
      verifiedTitle: "\u0421\u043A\u0438\u043D \u0441\u043E\u0432\u043F\u0430\u043B",
      verifiedBuyer: "\u041C\u043E\u0436\u043D\u043E \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435. \u0414\u0435\u043D\u044C\u0433\u0438 \u0443\u0436\u0435 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435 \u2014 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442\u0435 \u0432 \u0447\u0430\u0442.",
      verifiedSeller: "\u041E\u0431\u043C\u0435\u043D \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u0414\u0430\u043B\u044C\u0448\u0435 \u043F\u043E next step \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 / Guard.",
      partialTitle: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u2026",
      partialBody: "\u0427\u0430\u0441\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043E\u043A \u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430. \u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u2014 Accept \u043F\u043E\u043A\u0430 \u043D\u0435 \u0442\u043E\u0440\u043E\u043F\u0438\u0442\u0435.",
      pendingTitle: "\u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438",
      pendingBody: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C offer \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C R.I.P Market.",
      name: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435",
      stickers: "\u0421\u0442\u0438\u043A\u0435\u0440\u044B",
      partner: "\u041F\u0430\u0440\u0442\u043D\u0451\u0440 SteamID",
      assetId: "Asset ID",
      wear: "\u0418\u0437\u043D\u043E\u0441",
      float: "Float",
      hintBlock: "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u044D\u0442\u043E\u0442 \u043E\u0431\u043C\u0435\u043D \u0432 Steam",
      hintAccept: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435",
      hintWait: "\u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u2014 Accept \u043F\u043E\u043A\u0430 \u043D\u0435 \u0442\u043E\u0440\u043E\u043F\u0438\u0442\u0435"
    },
    offerGate: {
      needCs2Title: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 CS2",
      needCs2Body: "\u0412 \u0441\u043F\u0438\u0441\u043A\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044F \u0441\u043B\u0435\u0432\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 Counter-Strike 2. \u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u0430\u043C\u043E \u0434\u043E\u0431\u0430\u0432\u0438\u0442 \u0441\u043A\u0438\u043D \u0441\u0434\u0435\u043B\u043A\u0438.",
      needItemTitle: "\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0441\u043A\u0438\u043D \u0432 \u043E\u0431\u043C\u0435\u043D",
      needItemBody: "\u041D\u0443\u0436\u043D\u044B\u0439 \u043F\u0440\u0435\u0434\u043C\u0435\u0442: {{name}}. \u041A\u043B\u0438\u043A\u043D\u0438\u0442\u0435 \u0435\u0433\u043E \u0432 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u0435 \u2014 \u043E\u043D \u0434\u043E\u043B\u0436\u0435\u043D \u043F\u043E\u044F\u0432\u0438\u0442\u044C\u0441\u044F \u0432 \xAB\u0412\u0430\u0448\u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B\xBB.",
      itemReadyTitle: "\u0421\u043A\u0438\u043D \u0432 \u043E\u0431\u043C\u0435\u043D\u0435",
      itemReadyBody: "\u0421\u0432\u0435\u0440\u044C\u0442\u0435 \u0449\u0438\u0442 \u0441\u043F\u0440\u0430\u0432\u0430 \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0438\u0442\u044C \u043E\u0431\u043C\u0435\u043D\xBB \u0432 Steam. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438."
    },
    shield: {
      dealLine: "\u0417\u0430\u043A\u0430\u0437 #{{short}} \xB7 {{amount}}",
      wear: "\u0418\u0437\u043D\u043E\u0441",
      float: "Float",
      stickers: "\u0421\u0442\u0438\u043A\u0435\u0440\u044B",
      unknownPartner: "\u041A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442",
      partnerMatch: "Steam-\u043F\u0430\u0440\u0442\u043D\u0451\u0440 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      partnerMismatch: "Steam-\u043F\u0430\u0440\u0442\u043D\u0451\u0440 \u041D\u0415 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      partnerMissingObserved: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u0447\u0438\u0442\u0430\u0442\u044C \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B Steam",
      partnerMissingExpected: "\u0412 \u0437\u0430\u043A\u0430\u0437\u0435 \u043D\u0435\u0442 SteamID \u043A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442\u0430",
      partnerUnknown: "\u041F\u0430\u0440\u0442\u043D\u0451\u0440 \u043D\u0435 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D",
      partnerMatchCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C",
      partnerMismatchCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C",
      partnerMissingObservedCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D",
      partnerMissingExpectedCheck: "\u0412 \u0437\u0430\u043A\u0430\u0437\u0435 \u043D\u0435\u0442 SteamID \u043A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442\u0430",
      copySteamId: "\u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C",
      copied: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E",
      openProfile: "\u041F\u0440\u043E\u0444\u0438\u043B\u044C Steam",
      steamIdMissing: "SteamID \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D",
      expectedCol: "\u041E\u0436\u0438\u0434\u0430\u0435\u043C",
      observedCol: "\u0412 \u043E\u0444\u0444\u0435\u0440\u0435",
      preSendTitle: "\u041F\u0435\u0440\u0435\u0434 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u043E\u0439",
      preSendBody: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Steam Mobile.",
      compareTitle: "\u0421\u0432\u0435\u0440\u043A\u0430 \u0441 Steam"
    },
    acceptAssist: {
      acceptSteam: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C (Steam)",
      confirmAccept: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C Accept \u0432 Steam",
      cancel: "\u041E\u0442\u043C\u0435\u043D\u0430",
      openVerified: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 #{{short}} \u0438 \u043F\u0440\u0438\u043D\u044F\u0442\u044C \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam",
      acceptNotFound: "\u041A\u043D\u043E\u043F\u043A\u0430 Accept \u0432 Steam \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E Accept \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0432\u0440\u0443\u0447\u043D\u0443\u044E.",
      acceptClickFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043D\u0430\u0436\u0430\u0442\u044C Accept. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u0432\u0440\u0443\u0447\u043D\u0443\u044E.",
      doubleConfirm: "\u0415\u0449\u0451 \u0440\u0430\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u043E\u0433\u0434\u0430 \u043D\u0430\u0436\u043C\u0451\u043C Accept \u0432 Steam. \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u043E\u043C \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C.",
      guardHint: "\u0415\u0441\u043B\u0438 Steam \u043F\u043E\u043F\u0440\u043E\u0441\u0438\u0442 Guard \u2014 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile.",
      confirmAgain: "\u0415\u0441\u043B\u0438 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F Confirm \u2014 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437 \xAB\u041F\u0440\u0438\u043D\u044F\u0442\u044C (Steam)\xBB, \u043B\u0438\u0431\u043E Confirm \u0432 Steam.",
      commandSent: "\u041A\u043E\u043C\u0430\u043D\u0434\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0430 \u0432 Steam. {{guardHint}}",
      assistFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043C\u043E\u0447\u044C \u0441 Accept. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435.",
      highlightHint: "\u041F\u043E\u0434\u0441\u0432\u0435\u0442\u0438\u043C \u043A\u043D\u043E\u043F\u043A\u0443 Steam. Accept \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0441\u043B\u0435 \u0432\u0430\u0448\u0435\u0433\u043E \u0432\u0442\u043E\u0440\u043E\u0433\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F."
    },
    manualCreate: {
      buildOffer: "\u0421\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440 #{{short}}",
      autoFailed: "\u0410\u0432\u0442\u043E \u043D\u0435 \u0441\u043C\u043E\u0433 \u2014 \u0441\u043E\u0431\u0435\u0440\u0451\u043C \u043E\u0444\u0444\u0435\u0440 \u0447\u0435\u0440\u0435\u0437 Steam UI: \u043F\u0440\u0435\u0434\u043C\u0435\u0442 + Trade URL \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F.",
      canBuild: "\u041C\u043E\u0436\u043D\u043E \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440 \u0432\u0440\u0443\u0447\u043D\u0443\u044E \u0447\u0435\u0440\u0435\u0437 \u0442\u043E\u0442 \u0436\u0435 autofill, \u0447\u0442\u043E \u0438 \u0430\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430."
    },
    ops: {
      never: "\u0435\u0449\u0451 \u043D\u0435 \u0431\u044B\u043B\u043E",
      justNow: "\u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E",
      secondsAgo: "{{seconds}} \u0441\u0435\u043A \u043D\u0430\u0437\u0430\u0434",
      minutesAgo: "{{minutes}} \u043C\u0438\u043D \u043D\u0430\u0437\u0430\u0434",
      hoursAgo: "{{hours}} \u0447 \u043D\u0430\u0437\u0430\u0434",
      pollStale: "\u041E\u043F\u0440\u043E\u0441 \u0443\u0441\u0442\u0430\u0440\u0435\u043B \xB7 {{age}}",
      pollNever: "\u041E\u043F\u0440\u043E\u0441: \u0435\u0449\u0451 \u043D\u0435 \u0431\u044B\u043B\u043E \u0443\u0441\u043F\u0435\u0448\u043D\u043E\u0433\u043E",
      pollOld: "\u041E\u043F\u0440\u043E\u0441 \u0434\u0430\u0432\u043D\u043E \xB7 {{age}}",
      pollOk: "\u041E\u043F\u0440\u043E\u0441: {{age}}",
      rateLimited: "Steam: rate limit \u2014 \u043F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 1\u20132 \u043C\u0438\u043D",
      rateOk: "Steam: \u0431\u0435\u0437 rate limit",
      version: "\u0412\u0435\u0440\u0441\u0438\u044F {{version}}",
      updateExtension: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435"
    },
    onboarding: {
      coachTitle: "\u041F\u0440\u043E\u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u043D\u0430 R.I.P \u043F\u0440\u044F\u043C\u043E \u043E\u0442\u0441\u044E\u0434\u0430",
      coachBody: "\u0412\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0441\u044E\u0434\u0430 \u2014 \u043E\u0431\u043C\u0435\u043D \u043F\u0440\u0438 \u043F\u043E\u043A\u0443\u043F\u043A\u0435 \u0443\u0439\u0434\u0451\u0442 \u0441\u0430\u043C. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u044B \u0432 Steam Mobile.",
      coachDismiss: "\u041F\u043E\u043D\u044F\u0442\u043D\u043E",
      autoHideHint: "\u0421\u043A\u0440\u043E\u0435\u0442\u0441\u044F \u0447\u0435\u0440\u0435\u0437 ~30 \u0441\u0435\u043A",
      extensionReady: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      extensionHint: "\u041F\u0430\u0440\u0430 \u0441 \u0441\u0430\u0439\u0442\u043E\u043C \u043D\u0443\u0436\u043D\u0430 \u0434\u043B\u044F \u0446\u0435\u043D, \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0438 \u0438 \u0430\u0432\u0442\u043E-\u043E\u0431\u043C\u0435\u043D\u0430.",
      extensionAction: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      tradeUrlTitle: "Trade URL \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      tradeUrlHint: "\u0411\u0435\u0437 Trade URL \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u0438 \u043D\u0435 \u0441\u043C\u043E\u0433\u0443\u0442 \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043E\u0431\u043C\u0435\u043D \u043F\u043E\u0441\u043B\u0435 \u043E\u043F\u043B\u0430\u0442\u044B.",
      tradeUrlAction: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C Trade URL",
      checklistTitle: "\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      checklistReady: "\u0412\u0441\u0451 \u0433\u043E\u0442\u043E\u0432\u043E \u2014 \u043C\u043E\u0436\u043D\u043E \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u0438\u0437 Steam",
      checklistProgress: "\u0413\u043E\u0442\u043E\u0432\u043E {{ready}} \u0438\u0437 {{total}}"
    },
    twoMin: {
      title: "\u0421\u0442\u0430\u0440\u0442",
      lead: "\u0427\u0435\u0442\u044B\u0440\u0435 \u0448\u0430\u0433\u0430 \u2014 \u0438 \u0441\u0434\u0435\u043B\u043A\u0438 \u0438\u0434\u0443\u0442 \u0441\u0430\u043C\u0438.",
      progress: "{{ready}} / {{total}}",
      stepInstall: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E",
      hintInstall: "\u0412\u044B \u0443\u0436\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u044D\u0442\u043E\u0442 \u0448\u0430\u0433 \u0433\u043E\u0442\u043E\u0432.",
      stepPair: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043A \u0441\u0430\u0439\u0442\u0443",
      hintPair: "\u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB \u043D\u0430 p2pcs.ru.",
      stepInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2",
      hintInventory: "Steam Community \u2192 Inventory \u2192 Counter-Strike 2.",
      stepList: "\u041F\u0440\u043E\u0431\u043D\u044B\u0439 list",
      hintList: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043A\u0438\u043D \u2192 \u0441\u0438\u043D\u044F\u044F \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435. Guard \u043F\u043E\u0442\u043E\u043C \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Mobile.",
      ctaPair: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      ctaInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2",
      ctaList: "\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u0435\u0440\u0432\u044B\u0439 \u0441\u043A\u0438\u043D",
      ctaDone: "\u0413\u043E\u0442\u043E\u0432\u043E",
      dismiss: "\u041F\u043E\u0437\u0436\u0435",
      trialTitle: "\u041F\u0440\u043E\u0431\u043D\u044B\u0439 list (~30 \u0441\u0435\u043A)",
      trialBody: "\u041D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435 \u0441\u043A\u0438\u043D\u0430 \u0432 \u0441\u0435\u0442\u043A\u0435 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0441\u0438\u043D\u044E\u044E \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB (\u043D\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u0441\u043F\u0440\u0430\u0432\u0430). \u042D\u0442\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u0443\u0442\u0438 \u2014 \u043D\u0435 \u0442\u0435\u0441\u0442-\u0434\u0435\u043D\u044C\u0433\u0438.",
      trialDismiss: "\u0421\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0443"
    },
    overlay: {
      brand: "R.I.P Market",
      openDispute: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440",
      openDisputeSupport: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440 / \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437"
    },
    inventory: {
      layerBrand: "R.I.P Market",
      steamEnrichmentDegraded: "\u0427\u0430\u0441\u0442\u044C float/\u0446\u0435\u043D Steam \u0435\u0449\u0451 \u043F\u043E\u0434\u0433\u0440\u0443\u0436\u0430\u0435\u0442\u0441\u044F \u2014 \u0441\u0438\u043D\u044F\u044F \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430\u0445 \u0443\u0436\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430."
    }
  };

  // src/shared/extension-i18n.ts
  var messagesByLocale = {
    ru: extensionMessagesRu,
    en: extensionMessagesEn
  };
  function tx(locale, key, params) {
    return translateExtension(messagesByLocale[locale], key, params);
  }
  function createExtensionT(locale) {
    return (key, params) => tx(locale, key, params);
  }

  // src/shared/trade-offer-guided-gate.ts
  function guidedGateHeadline(status, role, locale = DEFAULT_EXTENSION_LOCALE) {
    const t2 = createExtensionT(locale);
    if (status === "mismatch") {
      return {
        title: t2("guided.mismatchTitle"),
        subtitle: role === "buyer" ? t2("guided.mismatchBuyer") : t2("guided.mismatchSeller"),
        tone: "error"
      };
    }
    if (status === "verified") {
      return {
        title: t2("guided.verifiedTitle"),
        subtitle: role === "buyer" ? t2("guided.verifiedBuyer") : t2("guided.verifiedSeller"),
        tone: "ok"
      };
    }
    if (status === "partial") {
      return {
        title: t2("guided.partialTitle"),
        subtitle: t2("guided.partialBody"),
        tone: "warn"
      };
    }
    return {
      title: t2("guided.pendingTitle"),
      subtitle: t2("guided.pendingBody"),
      tone: "pending"
    };
  }
  function normalize(value) {
    const trimmed = value?.trim() ?? "";
    return trimmed || "\u2014";
  }
  function compareTone(expected, observed, opts) {
    if (expected === "\u2014" && observed === "\u2014") {
      return "neutral";
    }
    if (observed === "\u2014") {
      return opts?.softWhenMissingObserved ? "warn" : "warn";
    }
    if (expected === "\u2014") {
      return "warn";
    }
    return expected === observed ? "ok" : "error";
  }
  function buildGuidedCompareRows(expected, observed, locale = DEFAULT_EXTENSION_LOCALE, partner) {
    const t2 = createExtensionT(locale);
    const expectedName = normalize(expected.marketHashName);
    const observedName = normalize(observed?.marketHashName);
    const expectedAsset = normalize(expected.assetExternalId);
    const observedAsset = normalize(observed?.assetId);
    const expectedFloat = normalize(expected.floatValue);
    const observedFloat = normalize(observed?.floatValue);
    const expectedWear = normalize(expected.wear);
    const observedWear = normalize(observed?.wear);
    const expectedPartner = normalize(
      partner?.expectedPartnerSteamId ?? null
    );
    const observedPartner = normalize(
      partner?.observedPartnerSteamId ?? observed?.partnerSteamId
    );
    const rows = [
      {
        key: "partner",
        label: t2("guided.partner"),
        expected: expectedPartner,
        observed: observedPartner,
        tone: compareTone(expectedPartner, observedPartner, {
          softWhenMissingObserved: true
        })
      },
      {
        key: "name",
        label: t2("guided.name"),
        expected: expectedName,
        observed: observedName,
        tone: compareTone(expectedName, observedName, {
          softWhenMissingObserved: true
        })
      },
      {
        key: "asset",
        label: t2("guided.assetId"),
        expected: expectedAsset,
        observed: observedAsset,
        tone: compareTone(expectedAsset, observedAsset, {
          softWhenMissingObserved: true
        })
      }
    ];
    if (expectedWear !== "\u2014" || observedWear !== "\u2014") {
      rows.push({
        key: "wear",
        label: t2("guided.wear"),
        expected: expectedWear,
        observed: observedWear,
        tone: compareTone(expectedWear, observedWear, {
          softWhenMissingObserved: true
        })
      });
    }
    if (expectedFloat !== "\u2014" || observedFloat !== "\u2014") {
      rows.push({
        key: "float",
        label: t2("guided.float"),
        expected: expectedFloat,
        observed: observedFloat,
        tone: compareTone(expectedFloat, observedFloat, {
          softWhenMissingObserved: true
        })
      });
    }
    if (expected.stickers && expected.stickers.length > 0) {
      rows.push({
        key: "stickers",
        label: t2("guided.stickers"),
        expected: expected.stickers.map(
          (sticker) => sticker.wearPercent != null ? `${sticker.name} (${sticker.wearPercent}%)` : sticker.name
        ).join(", "),
        observed: "\u2014",
        tone: "neutral"
      });
    }
    return rows;
  }
  function buyerOfferPagePrimaryHint(status, locale = DEFAULT_EXTENSION_LOCALE) {
    const t2 = createExtensionT(locale);
    if (status === "mismatch") {
      return {
        kind: "block",
        text: t2("guided.hintBlock")
      };
    }
    if (status === "verified") {
      return {
        kind: "accept_steam",
        text: t2("guided.hintAccept")
      };
    }
    return {
      kind: "wait",
      text: t2("guided.hintWait")
    };
  }

  // src/shared/site-origin.ts
  var DEFAULT_SITE_ORIGIN = "https://p2pcs.ru";
  var IPV4_HOST = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  function scoreOrigin(origin, index) {
    try {
      const url = new URL(origin);
      let score = 0;
      if (url.protocol === "https:") score += 100;
      else if (url.protocol === "http:") score += 10;
      if (!IPV4_HOST.test(url.hostname) && !url.hostname.includes(":")) {
        score += 50;
      }
      if (!url.hostname.toLowerCase().startsWith("www.")) score += 10;
      score -= Math.min(index, 20);
      return score;
    } catch {
      return Number.NEGATIVE_INFINITY;
    }
  }
  function normalizeSiteOriginCandidate(raw) {
    if (!raw) return null;
    let value = raw.trim();
    if (!value || value.includes(",")) return null;
    if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(value)) {
      value = `https://${value}`;
    }
    try {
      const url = new URL(value);
      if (url.protocol !== "http:" && url.protocol !== "https:") return null;
      if (!url.hostname) return null;
      return url.origin;
    } catch {
      return null;
    }
  }
  function resolveSiteOriginFromTradeUrl(siteUrl, fallbackOrigin = DEFAULT_SITE_ORIGIN) {
    const raw = siteUrl?.trim() ?? "";
    if (!raw) {
      return normalizeSiteOriginCandidate(fallbackOrigin) ?? DEFAULT_SITE_ORIGIN;
    }
    if (!raw.includes(",")) {
      const withoutOrder = raw.replace(/\/orders\/[^/?#]+\/?$/, "");
      const origin = normalizeSiteOriginCandidate(withoutOrder);
      if (origin) return origin;
    }
    const parts = raw.split(",").map((p) => p.trim()).filter(Boolean);
    const candidates = [];
    for (const part of parts) {
      const withoutOrder = part.replace(/\/orders\/[^/?#]+\/?$/, "");
      const origin = normalizeSiteOriginCandidate(withoutOrder);
      if (origin) candidates.push(origin);
    }
    if (candidates.length === 0) {
      return normalizeSiteOriginCandidate(fallbackOrigin) ?? DEFAULT_SITE_ORIGIN;
    }
    let best = candidates[0];
    let bestScore = scoreOrigin(best, 0);
    for (let i = 1; i < candidates.length; i += 1) {
      const score = scoreOrigin(candidates[i], i);
      if (score > bestScore) {
        best = candidates[i];
        bestScore = score;
      }
    }
    return best;
  }
  function sanitizeTradeOrderUrl(siteUrl, orderId, fallbackOrigin = DEFAULT_SITE_ORIGIN) {
    const origin = resolveSiteOriginFromTradeUrl(siteUrl, fallbackOrigin);
    const id = orderId.trim();
    if (!id) {
      return origin;
    }
    if (siteUrl && !siteUrl.includes(",")) {
      try {
        const url = new URL(
          /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(siteUrl) ? siteUrl : `https://${siteUrl}`
        );
        if (url.pathname.includes(`/orders/${id}`)) {
          return `${url.origin}/orders/${id}`;
        }
      } catch {
      }
    }
    return `${origin}/orders/${id}`;
  }

  // src/shared/in-flow-dispute.ts
  function siteOriginFromTradeUrl(siteUrl) {
    return resolveSiteOriginFromTradeUrl(siteUrl);
  }
  function resolveInFlowDisputeReason(trade) {
    if (trade.verificationStatus === "mismatch") {
      return "mismatch";
    }
    if (trade.orderStatus === "DISPUTE") {
      return "timeout";
    }
    return "trade_problem";
  }
  function buildInFlowDisputeEvidence(trade, capturedAt = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      version: 1,
      reason: resolveInFlowDisputeReason(trade),
      orderId: trade.orderId,
      offerId: trade.offerId?.trim() || null,
      orderStatus: trade.orderStatus,
      role: trade.role,
      verificationStatus: trade.verificationStatus ?? null,
      failedCheckKeys: trade.checks.filter((check) => !check.passed).map((check) => check.key),
      nextActionKind: trade.nextAction.kind,
      tradeTimeoutAt: trade.tradeTimeoutAt?.trim() || null,
      capturedAt
    };
  }
  function encodeInFlowDisputeEvidence(evidence) {
    const json = JSON.stringify(evidence);
    const bytes = new TextEncoder().encode(json);
    let binary = "";
    for (const byte of bytes) {
      binary += String.fromCharCode(byte);
    }
    return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/g, "");
  }
  function buildInFlowDisputeSupportUrl(trade, opts) {
    const evidence = buildInFlowDisputeEvidence(trade, opts?.capturedAt);
    const origin = siteOriginFromTradeUrl(trade.siteUrl);
    const query = new URLSearchParams();
    query.set("dealId", evidence.orderId);
    query.set("topic", "deal");
    query.set("reason", evidence.reason);
    if (evidence.offerId) {
      query.set("offerId", evidence.offerId);
    }
    if (evidence.verificationStatus) {
      query.set("verifyStatus", evidence.verificationStatus);
    }
    if (evidence.failedCheckKeys.length > 0) {
      query.set("failedChecks", evidence.failedCheckKeys.join(","));
    }
    if (evidence.nextActionKind) {
      query.set("nextAction", evidence.nextActionKind);
    }
    query.set("capturedAt", evidence.capturedAt);
    query.set("evidence", encodeInFlowDisputeEvidence(evidence));
    return `${origin}/support?${query.toString()}`;
  }

  // src/shared/trade-offer-anti-scam.ts
  var YOUR_ITEM_SELECTORS = [
    "#your_slots .item",
    "#trade_yours .item",
    ".tradeoffer_items.secondary .item",
    "#trade_offer_your_slots .item"
  ];
  var THEIR_ITEM_SELECTORS = [
    "#them_slots .item",
    "#trade_theirs .item",
    ".tradeoffer_items.primary .item",
    "#trade_offer_their_slots .item"
  ];
  var STICKY_HINT = {
    id: "never_accept_from_chat",
    severity: "info",
    title: "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u043E\u0431\u043C\u0435\u043D\u044B \u0438\u0437 \u0447\u0430\u0442\u0430",
    body: "\u041E\u0431\u043C\u0435\u043D\u044B \u0438\u0437 \u0447\u0430\u0442\u0430, \u043F\u0440\u043E\u0444\u0438\u043B\u044F \u0438\u043B\u0438 \u043E\u0442 \u043D\u0435\u0437\u043D\u0430\u043A\u043E\u043C\u0446\u0435\u0432 \u2014 \u043A\u043B\u0430\u0441\u0441\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0441\u043A\u0430\u043C. \u041F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0444\u0444\u0435\u0440\u044B, \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u043A \u0437\u0430\u043A\u0430\u0437\u0443 R.I.P Market."
  };
  function countUniqueItems(root, selectors) {
    const seen = /* @__PURE__ */ new Set();
    for (const selector of selectors) {
      for (const element of Array.from(root.querySelectorAll(selector))) {
        const assetId = parseAssetIdFromElement(element);
        if (assetId) {
          seen.add(`asset:${assetId}`);
          continue;
        }
        const economy = element.getAttribute("data-economy-item")?.trim();
        if (economy) {
          seen.add(`economy:${economy}`);
          continue;
        }
        const title = element.getAttribute("title")?.trim();
        if (title) {
          seen.add(`title:${title}:${seen.size}`);
        } else {
          seen.add(`node:${selector}:${seen.size}`);
        }
      }
    }
    return seen.size;
  }
  function detectSteamEscrowHint(text) {
    const normalized = text.replace(/\s+/g, " ").trim();
    if (!normalized) {
      return null;
    }
    const patterns = [
      /items?\s+will\s+be\s+held[^.!?\n]{0,100}/i,
      /will\s+be\s+held\s+by\s+steam[^.!?\n]{0,100}/i,
      /trade\s+hold[^.!?\n]{0,80}/i,
      /held\s+in\s+escrow[^.!?\n]{0,80}/i,
      /предмет[аы]?\s+будут?\s+удержан[^.!?\n]{0,100}/i,
      /удержани[ея]\s+steam[^.!?\n]{0,80}/i,
      /trade\s+hold\s+на\s+\d+[^.!?\n]{0,40}/i
    ];
    for (const pattern of patterns) {
      const match = normalized.match(pattern);
      if (match?.[0]) {
        return match[0].trim().slice(0, 160);
      }
    }
    return null;
  }
  function parseOfferSlotSnapshot(root) {
    const pageText = root instanceof Document ? root.body?.textContent ?? root.documentElement?.textContent ?? "" : root.textContent ?? "";
    return {
      yourItemCount: countUniqueItems(root, YOUR_ITEM_SELECTORS),
      theirItemCount: countUniqueItems(root, THEIR_ITEM_SELECTORS),
      steamEscrowHint: detectSteamEscrowHint(pageText)
    };
  }
  function evaluateAntiScamRules(input) {
    const warnings = [];
    const includeSticky = input.includeStickyHint !== false;
    if (!input.hasLinkedActiveOrder) {
      warnings.push({
        id: "offer_not_linked",
        severity: "block",
        title: "Offer \u043D\u0435 \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D \u043A \u0437\u0430\u043A\u0430\u0437\u0443 R.I.P",
        body: "\u041D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0433\u043E \u0437\u0430\u043A\u0430\u0437\u0430 \u0441 \u044D\u0442\u0438\u043C offerId. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u2014 \u0442\u0430\u043A \u0447\u0430\u0441\u0442\u043E \u043F\u043E\u0434\u043C\u0435\u043D\u044F\u044E\u0442 \u0441\u0434\u0435\u043B\u043A\u0443 \u043F\u043E\u0441\u043B\u0435 \u043E\u043F\u043B\u0430\u0442\u044B \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u0439 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435 \u0438\u043B\u0438 \u0432 \u0447\u0430\u0442\u0435."
      });
    }
    const slots = input.slots;
    if (slots) {
      const viewerIsBuyer = input.role === "buyer" || input.role === null;
      if (viewerIsBuyer && slots.yourItemCount > 0) {
        warnings.push({
          id: "requests_your_items",
          severity: "block",
          title: "\u0412 \u043E\u0444\u0444\u0435\u0440\u0435 \u043F\u0440\u043E\u0441\u044F\u0442 \u0432\u0430\u0448\u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B",
          body: "\u0414\u043B\u044F \u043F\u043E\u043A\u0443\u043F\u043A\u0438 \u043D\u0430 R.I.P Market \u0432\u044B \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043E\u0442\u0434\u0430\u0451\u0442\u0435 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u0442\u0435 \u0441\u043A\u0438\u043D. \u0417\u0430\u043F\u0440\u043E\u0441 \u0432\u0430\u0448\u0438\u0445 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432 = \u0440\u0438\u0441\u043A \u0441\u043A\u0430\u043C\u0430."
        });
      }
      if (slots.theirItemCount > 1) {
        warnings.push({
          id: "extra_items_from_them",
          severity: "warn",
          title: "\u0412 \u043E\u0444\u0444\u0435\u0440\u0435 \u043B\u0438\u0448\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B",
          body: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442\u0441\u044F \u043E\u0434\u0438\u043D \u0441\u043A\u0438\u043D \u043F\u043E \u0437\u0430\u043A\u0430\u0437\u0443. \u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432 \u0432 \u043E\u0444\u0444\u0435\u0440\u0435 \u2014 \u0447\u0430\u0441\u0442\u044B\u0439 \u043F\u0440\u0438\u0451\u043C \u043F\u043E\u0434\u043C\u0435\u043D\u044B (\u0434\u043E\u0431\u0430\u0432\u0438\u043B\u0438 \u0434\u0435\u0448\u0451\u0432\u043E\u0435, \u0443\u0431\u0440\u0430\u043B\u0438 \u043D\u0443\u0436\u043D\u043E\u0435)."
        });
      }
      if (slots.steamEscrowHint) {
        warnings.push({
          id: "steam_trade_hold",
          severity: "warn",
          title: "Steam Trade Hold / escrow",
          body: `Steam \u0443\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442 \u043E\u0431\u043C\u0435\u043D: \xAB${slots.steamEscrowHint}\xBB. \u0423\u0447\u0442\u0438\u0442\u0435 \u0437\u0430\u0434\u0435\u0440\u0436\u043A\u0443 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438 \u0438 \u043D\u0435 \u0441\u043E\u0433\u043B\u0430\u0448\u0430\u0439\u0442\u0435\u0441\u044C \u043D\u0430 \u043E\u043F\u043B\u0430\u0442\u0443 \xAB\u0432 \u043E\u0431\u0445\u043E\u0434\xBB \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438.`
        });
      }
    }
    if (includeSticky) {
      warnings.push(STICKY_HINT);
    }
    return warnings;
  }
  function antiScamHasBlocking(warnings) {
    return warnings.some((warning) => warning.severity === "block");
  }
  function antiScamStickyShort() {
    return "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u043E\u0431\u043C\u0435\u043D\u044B \u0438\u0437 \u0447\u0430\u0442\u0430 / \u043F\u0440\u043E\u0444\u0438\u043B\u044F \u043D\u0435\u0437\u043D\u0430\u043A\u043E\u043C\u0446\u0430 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u0434\u0435\u043B\u043A\u0438 R.I.P.";
  }

  // src/shared/manual-accept-assist.ts
  var MANUAL_ACCEPT_ASSIST = {
    HIGHLIGHT_ATTR: "data-rip-accept-highlight",
    STYLE_ID: "rip-market-accept-assist-style"
  };
  function canShowManualAcceptAssist(trade) {
    if (trade.role !== "buyer") {
      return false;
    }
    if (trade.verificationStatus !== "verified") {
      return false;
    }
    if (!trade.offerId?.trim()) {
      return false;
    }
    if (trade.orderStatus === "DISPUTE") {
      return false;
    }
    if (trade.nextAction.kind === "report_issue" || trade.nextAction.kind === "platform_verifying") {
      return false;
    }
    return trade.orderStatus === "WAITING_TRADE" || trade.nextAction.kind === "accept_in_steam";
  }
  function normalizeLabel(value) {
    return (value ?? "").replace(/\s+/g, " ").trim();
  }
  function classifyAcceptLabel(label) {
    const lower = label.toLowerCase();
    if (/confirm|подтверд/.test(lower)) {
      return "confirm";
    }
    if (/accept|принять/.test(lower)) {
      return "accept";
    }
    return "unknown";
  }
  function controlFromElement(element) {
    if (!(element instanceof HTMLElement)) {
      return null;
    }
    if (element.getAttribute("aria-disabled") === "true" || element instanceof HTMLButtonElement && element.disabled) {
      return null;
    }
    const style = element.ownerDocument.defaultView?.getComputedStyle(element);
    if (style && (style.display === "none" || style.visibility === "hidden")) {
      return null;
    }
    const onclick = element.getAttribute("onclick") ?? "";
    const label = normalizeLabel(element.textContent) || normalizeLabel(element.title);
    let kind = classifyAcceptLabel(label);
    if (/ConfirmTradeOffer/i.test(onclick)) {
      kind = "confirm";
    } else if (/AcceptTradeOffer/i.test(onclick)) {
      kind = "accept";
    }
    if (kind === "unknown" && !onclick) {
      return null;
    }
    return {
      element,
      kind: kind === "unknown" ? "accept" : kind,
      label: label || (kind === "confirm" ? "Confirm" : "Accept")
    };
  }
  function findSteamAcceptControls(root = document) {
    const seen = /* @__PURE__ */ new Set();
    const found = [];
    const push = (element) => {
      if (!(element instanceof HTMLElement) || seen.has(element)) {
        return;
      }
      const control = controlFromElement(element);
      if (!control) {
        return;
      }
      seen.add(element);
      found.push(control);
    };
    if (root instanceof Document || root instanceof Element) {
      push(root.querySelector("#trade_confirmbtn"));
      push(root.querySelector("#trade_offer_accept_button"));
      push(root.querySelector("#accept_trade_button"));
      for (const el of Array.from(
        root.querySelectorAll(
          '[onclick*="AcceptTradeOffer"], [onclick*="ConfirmTradeOffer"]'
        )
      )) {
        push(el);
      }
      for (const el of Array.from(
        root.querySelectorAll(
          "a.btn_green_white_innerfade, a.btn_green_steamui, button.btn_green_white_innerfade, .trade_confirmbtn, .btn_green_white_innerfade"
        )
      )) {
        push(el);
      }
      for (const el of Array.from(
        root.querySelectorAll('a, button, div[role="button"]')
      )) {
        const text = normalizeLabel(el.textContent).toLowerCase();
        if (text === "accept" || text === "accept trade" || text === "\u043F\u0440\u0438\u043D\u044F\u0442\u044C" || text === "\u043F\u0440\u0438\u043D\u044F\u0442\u044C \u043E\u0431\u043C\u0435\u043D" || text === "confirm" || text === "confirm trade" || text === "\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C") {
          push(el);
        }
      }
    }
    return found;
  }
  function pickSteamAcceptControl(controls, prefer = "accept") {
    if (controls.length === 0) {
      return null;
    }
    return controls.find((entry) => entry.kind === prefer) ?? controls.find((entry) => entry.kind === "confirm") ?? controls[0] ?? null;
  }
  function ensureAcceptAssistHighlightStyles(doc = document) {
    if (doc.getElementById(MANUAL_ACCEPT_ASSIST.STYLE_ID)) {
      return;
    }
    const style = doc.createElement("style");
    style.id = MANUAL_ACCEPT_ASSIST.STYLE_ID;
    style.textContent = `
    [${MANUAL_ACCEPT_ASSIST.HIGHLIGHT_ATTR}="1"] {
      outline: 3px solid #7dd3fc !important;
      outline-offset: 4px !important;
      box-shadow: 0 0 0 6px rgba(2, 132, 199, 0.35) !important;
      animation: rip-accept-pulse 1.1s ease-in-out 3;
    }
    @keyframes rip-accept-pulse {
      0%, 100% { box-shadow: 0 0 0 4px rgba(2, 132, 199, 0.22); }
      50% { box-shadow: 0 0 0 10px rgba(37, 99, 235, 0.4); }
    }
  `;
    doc.documentElement.appendChild(style);
  }
  function clearSteamAcceptHighlights(root = document) {
    const scope = root instanceof Document || root instanceof Element ? root : document;
    for (const el of Array.from(
      scope.querySelectorAll(`[${MANUAL_ACCEPT_ASSIST.HIGHLIGHT_ATTR}]`)
    )) {
      el.removeAttribute(MANUAL_ACCEPT_ASSIST.HIGHLIGHT_ATTR);
    }
  }
  function highlightSteamAcceptControl(control) {
    ensureAcceptAssistHighlightStyles(control.element.ownerDocument);
    clearSteamAcceptHighlights(control.element.ownerDocument);
    control.element.setAttribute(MANUAL_ACCEPT_ASSIST.HIGHLIGHT_ATTR, "1");
    control.element.scrollIntoView({ behavior: "smooth", block: "center" });
  }
  function clickSteamAcceptControl(control, locale = DEFAULT_EXTENSION_LOCALE) {
    const t2 = createExtensionT(locale);
    if (!control) {
      return {
        ok: false,
        error: t2("acceptAssist.acceptNotFound")
      };
    }
    try {
      control.element.click();
      return { ok: true, kind: control.kind, label: control.label };
    } catch {
      return {
        ok: false,
        error: t2("acceptAssist.acceptClickFailed")
      };
    }
  }
  function buildOfferAcceptAssistView(params) {
    const locale = params.locale ?? DEFAULT_EXTENSION_LOCALE;
    const t2 = createExtensionT(locale);
    if (params.phase === "armed") {
      return {
        phase: "armed",
        primaryLabel: t2("acceptAssist.confirmAccept"),
        secondaryLabel: t2("acceptAssist.cancel"),
        hint: t2("acceptAssist.doubleConfirm"),
        tone: "warn"
      };
    }
    if (params.phase === "done") {
      const guardHint = params.lastClickedKind === "confirm" ? t2("acceptAssist.guardHint") : t2("acceptAssist.confirmAgain");
      return {
        phase: "done",
        primaryLabel: t2("acceptAssist.acceptSteam"),
        secondaryLabel: null,
        hint: t2("acceptAssist.commandSent", { guardHint }),
        tone: "ok"
      };
    }
    if (params.phase === "error") {
      return {
        phase: "error",
        primaryLabel: t2("acceptAssist.acceptSteam"),
        secondaryLabel: null,
        hint: params.errorMessage?.trim() || t2("acceptAssist.assistFailed"),
        tone: "error"
      };
    }
    return {
      phase: "ready",
      primaryLabel: t2("acceptAssist.acceptSteam"),
      secondaryLabel: null,
      hint: t2("acceptAssist.highlightHint"),
      tone: "ok"
    };
  }

  // src/shared/active-trades-cache.ts
  var GUIDED_BUYER_ENABLED_KEY = "extensionGuidedBuyerEnabled";

  // src/shared/extension-flags.ts
  function isRemoteFlagOn(stored) {
    return stored !== false;
  }
  async function isExtensionGuidedBuyerEnabled() {
    try {
      const stored = await chrome.storage.local.get(GUIDED_BUYER_ENABLED_KEY);
      return isRemoteFlagOn(stored[GUIDED_BUYER_ENABLED_KEY]);
    } catch {
      return true;
    }
  }

  // src/shared/steam-id64.ts
  var STEAM_ID64_BASE = 76561197960265728n;
  function isRealSteamId64(steamId) {
    return typeof steamId === "string" && /^7656119\d{10}$/.test(steamId.trim());
  }
  function accountIdToSteamId64(accountId) {
    const trimmed = accountId.trim();
    if (!/^\d{1,17}$/.test(trimmed)) {
      return null;
    }
    try {
      const id = BigInt(trimmed);
      if (id < 0n || id > 0xffffffffn) {
        return null;
      }
      return (id + STEAM_ID64_BASE).toString();
    } catch {
      return null;
    }
  }
  function buildSteamProfileUrl(steamId64) {
    return `https://steamcommunity.com/profiles/${steamId64.trim()}`;
  }
  function extractSteamId64FromHref(href) {
    if (!href) {
      return null;
    }
    const trimmed = href.trim();
    const profileMatch = trimmed.match(/\/profiles\/(7656119\d{10})\b/i);
    if (profileMatch?.[1]) {
      return profileMatch[1];
    }
    if (isRealSteamId64(trimmed)) {
      return trimmed.trim();
    }
    return null;
  }

  // src/shared/trade-offers-list-marking.ts
  function formatMoneyMinor(amountMinor) {
    const value = Number(amountMinor) / 100;
    if (!Number.isFinite(value)) {
      return amountMinor;
    }
    return `$${value.toFixed(2)}`;
  }

  // src/shared/deal-shield.ts
  function normalizeId(value) {
    return value?.trim() ?? "";
  }
  function resolvePartnerMatch(params) {
    const expected = normalizeId(params.expectedSteamId);
    const observed = normalizeId(params.observedSteamId);
    if (!expected || !isRealSteamId64(expected)) {
      return "missing_expected";
    }
    if (!observed) {
      return "missing_observed";
    }
    if (!isRealSteamId64(observed)) {
      return "unknown";
    }
    return expected === observed ? "match" : "mismatch";
  }
  function applyPartnerObservation(trade, observedPartnerSteamId, locale = DEFAULT_EXTENSION_LOCALE) {
    const t2 = createExtensionT(locale);
    const match = resolvePartnerMatch({
      expectedSteamId: trade.counterparty.steamId,
      observedSteamId: observedPartnerSteamId
    });
    const withoutPartnerChecks = trade.checks.filter(
      (check) => check.key !== "partner_steam_match"
    );
    if (match === "mismatch") {
      return {
        ...trade,
        verificationStatus: "mismatch",
        checks: [
          ...withoutPartnerChecks,
          {
            key: "partner_steam_match",
            passed: false,
            label: t2("shield.partnerMismatchCheck"),
            severity: "error"
          }
        ]
      };
    }
    if (match === "match") {
      return {
        ...trade,
        checks: [
          ...withoutPartnerChecks,
          {
            key: "partner_steam_match",
            passed: true,
            label: t2("shield.partnerMatchCheck"),
            severity: "ok"
          }
        ]
      };
    }
    if (match === "missing_observed" && trade.verificationStatus === "verified") {
      return {
        ...trade,
        verificationStatus: "partial",
        checks: [
          ...withoutPartnerChecks,
          {
            key: "partner_steam_match",
            passed: false,
            label: t2("shield.partnerMissingObservedCheck"),
            severity: "warn"
          }
        ]
      };
    }
    if (match === "missing_expected") {
      return {
        ...trade,
        verificationStatus: trade.verificationStatus === "verified" ? "partial" : trade.verificationStatus,
        checks: [
          ...withoutPartnerChecks,
          {
            key: "partner_steam_match",
            passed: false,
            label: t2("shield.partnerMissingExpectedCheck"),
            severity: "warn"
          }
        ]
      };
    }
    return trade;
  }
  function buildItemCharacteristicLines(item, locale = DEFAULT_EXTENSION_LOCALE) {
    const t2 = createExtensionT(locale);
    const lines = [];
    const wear = item.wear?.trim();
    if (wear) {
      lines.push({ key: "wear", label: t2("shield.wear"), value: wear });
    }
    const floatValue = item.floatValue?.trim();
    if (floatValue) {
      lines.push({ key: "float", label: t2("shield.float"), value: floatValue });
    }
    const stickers = item.stickers?.filter((s) => s.name?.trim()) ?? [];
    if (stickers.length > 0) {
      lines.push({
        key: "stickers",
        label: t2("shield.stickers"),
        value: stickers.map(
          (s) => s.wearPercent != null ? `${s.name} (${s.wearPercent}%)` : s.name
        ).join(", ")
      });
    }
    return lines;
  }
  function partnerMatchLabel(match, locale) {
    const t2 = createExtensionT(locale);
    switch (match) {
      case "match":
        return t2("shield.partnerMatch");
      case "mismatch":
        return t2("shield.partnerMismatch");
      case "missing_observed":
        return t2("shield.partnerMissingObserved");
      case "missing_expected":
        return t2("shield.partnerMissingExpected");
      default:
        return t2("shield.partnerUnknown");
    }
  }
  function buildDealShieldModel(params) {
    const locale = params.locale ?? DEFAULT_EXTENSION_LOCALE;
    const t2 = createExtensionT(locale);
    const observedPartner = params.observed?.partnerSteamId ?? null;
    const trade = applyPartnerObservation(
      params.trade,
      observedPartner,
      locale
    );
    const match = resolvePartnerMatch({
      expectedSteamId: trade.counterparty.steamId,
      observedSteamId: observedPartner
    });
    const steamId = trade.counterparty.steamId?.trim() || null;
    const displayName = trade.counterparty.personaName?.trim() || trade.counterparty.username.trim() || t2("shield.unknownPartner");
    const isPreSend = params.isPreSend === true || trade.role === "seller" && !trade.offerId;
    const compareRows = buildGuidedCompareRows(
      trade.item,
      params.observed ?? null,
      locale,
      {
        expectedPartnerSteamId: steamId,
        observedPartnerSteamId: observedPartner
      }
    );
    return {
      orderId: trade.orderId,
      orderShortId: trade.orderShortId,
      amountLabel: formatMoneyMinor(trade.amountMinor),
      role: trade.role,
      counterpartyRoleLabel: trade.role === "buyer" ? t2("common.seller") : t2("common.buyer"),
      headline: guidedGateHeadline(trade.verificationStatus, trade.role, locale),
      effectiveStatus: trade.verificationStatus,
      partner: {
        displayName,
        steamId,
        avatarUrl: trade.counterparty.avatarUrl?.trim() || null,
        profileUrl: steamId && isRealSteamId64(steamId) ? buildSteamProfileUrl(steamId) : null,
        match,
        matchLabel: partnerMatchLabel(match, locale)
      },
      item: {
        marketHashName: trade.item.marketHashName,
        iconUrl: trade.item.iconUrl,
        lines: buildItemCharacteristicLines(trade.item, locale),
        assetExternalId: trade.item.assetExternalId
      },
      compareRows,
      checks: trade.checks,
      blocksAccept: trade.verificationStatus === "mismatch" || match === "mismatch",
      isPreSend,
      siteUrl: trade.siteUrl,
      offerId: trade.offerId
    };
  }

  // src/shared/parse-trade-partner-steamid.ts
  var PARTNER_LINK_SELECTORS = [
    '.trade_partner_header a[href*="/profiles/"]',
    '.trade_partner_header a[href*="/id/"]',
    '.tradeoffer_header a[href*="/profiles/"]',
    '.tradeoffer_header a[href*="/id/"]',
    '#trade_them a[href*="/profiles/"]',
    '#trade_them a[href*="/id/"]',
    '.trade_partner_info_block a[href*="/profiles/"]',
    '.trade_partner_info_block a[href*="/id/"]',
    'a.trade_partner_headline_name[href*="/profiles/"]',
    'a.trade_partner_headline_name[href*="/id/"]',
    '.playerAvatar a[href*="/profiles/"]',
    '.playerAvatar a[href*="/id/"]'
  ];
  var PARTNER_MINIPROFILE_SELECTORS = [
    ".trade_partner_header [data-miniprofile]",
    ".tradeoffer_header [data-miniprofile]",
    "#trade_them [data-miniprofile]",
    ".trade_partner_info_block [data-miniprofile]",
    "a.trade_partner_headline_name[data-miniprofile]",
    ".trade_partner_header .playerAvatar[data-miniprofile]",
    ".tradeoffer_items_avatar[data-miniprofile]"
  ];
  function parsePartnerSteamIdFromTradeOfferUrl(href) {
    try {
      const url = new URL(href);
      if (!/\/tradeoffer\/new/i.test(url.pathname)) {
        return null;
      }
      const partner = url.searchParams.get("partner")?.trim();
      if (!partner) {
        return null;
      }
      if (isRealSteamId64(partner)) {
        return partner;
      }
      return accountIdToSteamId64(partner);
    } catch {
      return null;
    }
  }
  function steamIdFromMiniprofileAttr(raw) {
    const value = raw?.trim();
    if (!value) {
      return null;
    }
    if (isRealSteamId64(value)) {
      return value;
    }
    return accountIdToSteamId64(value);
  }
  function parsePartnerSteamIdFromPageGlobals(globals) {
    if (!globals) {
      return null;
    }
    const candidates = [
      globals.g_rgPartnerSteamId,
      globals.g_ulTradePartnerSteamID,
      globals.g_steamIDPartner,
      globals.UserThem?.strSteamId,
      globals.UserThem?.steamid
    ];
    for (const candidate of candidates) {
      if (typeof candidate === "string" || typeof candidate === "number") {
        const asString = String(candidate).trim();
        if (isRealSteamId64(asString)) {
          return asString;
        }
        const fromAccount = accountIdToSteamId64(asString);
        if (fromAccount) {
          return fromAccount;
        }
      }
    }
    return null;
  }
  function parsePartnerSteamIdFromDocument(doc = document, pageUrl = typeof location !== "undefined" ? location.href : "", pageGlobals) {
    const fromGlobals = parsePartnerSteamIdFromPageGlobals(pageGlobals);
    if (fromGlobals) {
      return fromGlobals;
    }
    const fromUrl = parsePartnerSteamIdFromTradeOfferUrl(pageUrl);
    if (fromUrl) {
      return fromUrl;
    }
    for (const selector of PARTNER_MINIPROFILE_SELECTORS) {
      const nodes = doc.querySelectorAll(selector);
      for (const node of Array.from(nodes)) {
        const id = steamIdFromMiniprofileAttr(node.getAttribute("data-miniprofile"));
        if (id) {
          return id;
        }
      }
    }
    for (const selector of PARTNER_LINK_SELECTORS) {
      const anchors = doc.querySelectorAll(selector);
      for (const anchor of Array.from(anchors)) {
        const id = extractSteamId64FromHref(anchor.getAttribute("href"));
        if (id) {
          return id;
        }
        const fromMini = steamIdFromMiniprofileAttr(
          anchor.getAttribute("data-miniprofile")
        );
        if (fromMini) {
          return fromMini;
        }
      }
    }
    const scope = doc.querySelector(".trade_partner_header, .tradeoffer_header, #mainContents") ?? doc;
    for (const anchor of Array.from(
      scope.querySelectorAll('a[href*="/profiles/7656119"]')
    )) {
      const id = extractSteamId64FromHref(anchor.getAttribute("href"));
      if (id) {
        return id;
      }
    }
    for (const node of Array.from(
      scope.querySelectorAll("[data-miniprofile]")
    )) {
      if (node.closest("#inventories, #inventory_box, .inventory_ctn")) {
        continue;
      }
      const id = steamIdFromMiniprofileAttr(node.getAttribute("data-miniprofile"));
      if (id) {
        return id;
      }
    }
    return null;
  }

  // src/shared/resolve-trade-for-offer-page.ts
  function resolveTradeForOfferPage(params) {
    const offerId = params.offerId?.trim() || null;
    if (offerId) {
      const byOffer = params.trades.find(
        (trade) => trade.offerId?.trim() === offerId
      ) ?? null;
      if (byOffer) {
        return byOffer;
      }
    }
    const waiting = params.trades.filter(
      (trade) => trade.orderStatus === "WAITING_TRADE" && (params.roleHint ? trade.role === params.roleHint : true)
    );
    const assetId = params.observedAssetId?.trim() || null;
    if (assetId) {
      const byAsset = waiting.filter(
        (trade) => trade.item.assetExternalId?.trim() === assetId
      );
      if (byAsset.length === 1) {
        return byAsset[0] ?? null;
      }
      if (byAsset.length > 1 && offerId) {
        const unlinked = byAsset.find((trade) => !trade.offerId?.trim());
        if (unlinked) {
          return unlinked;
        }
      }
    }
    if (waiting.length === 1) {
      const only = waiting[0];
      const expectedAsset = only.item.assetExternalId?.trim() || null;
      if (assetId && expectedAsset && assetId !== expectedAsset) {
        return null;
      }
      if (!only.offerId?.trim() || offerId && only.offerId.trim() === offerId) {
        return only;
      }
      if (offerId && only.offerId.trim() !== offerId) {
        return null;
      }
      return only;
    }
    return null;
  }

  // src/shared/deal-confirm-flow.ts
  function isDeliveryDualSignalOk(progress) {
    if (!progress) {
      return false;
    }
    const inventoryOk = progress.inventoryTone === "ok" || progress.inventoryHint === "confirmed";
    return progress.offerTone === "ok" && inventoryOk;
  }
  function needsBuyerReceivedConfirm(trade, options) {
    if (trade.role !== "buyer") {
      return false;
    }
    if (trade.acknowledgments.buyerReceived) {
      return false;
    }
    if (!trade.offerId?.trim()) {
      return false;
    }
    if (trade.verificationStatus === "mismatch" || trade.nextAction.kind === "report_issue" || trade.orderStatus === "DISPUTE") {
      return false;
    }
    if (isDeliveryDualSignalOk(trade.deliveryProgress)) {
      return false;
    }
    if (trade.orderStatus === "SETTLEMENT_HOLD") {
      return false;
    }
    if (trade.nextAction.kind === "confirm_received") {
      return true;
    }
    if (trade.orderStatus === "TRADE_CONFIRMED") {
      return true;
    }
    if (options?.acceptAssistDone === true && trade.orderStatus === "WAITING_TRADE") {
      return true;
    }
    return false;
  }
  function resolveDealConfirmPhase(trade, options) {
    if (trade.nextAction.kind === "confirm_guard") {
      return "guard";
    }
    if (needsBuyerReceivedConfirm(trade, options)) {
      return "confirm_received";
    }
    if (trade.orderStatus === "SETTLEMENT_HOLD" || trade.nextAction.kind === "completed" || trade.acknowledgments.buyerReceived) {
      return "done";
    }
    if (trade.nextAction.kind === "accept_in_steam" || trade.role === "buyer" && trade.orderStatus === "WAITING_TRADE" && Boolean(trade.offerId)) {
      return "accept_steam";
    }
    if (trade.nextAction.kind === "platform_verifying" || trade.orderStatus === "TRADE_CONFIRMED") {
      return "verifying";
    }
    return "other";
  }
  function buildDealConfirmBanner(trade, locale = DEFAULT_EXTENSION_LOCALE, options) {
    const t2 = createExtensionT(locale);
    const phase = resolveDealConfirmPhase(trade, options);
    switch (phase) {
      case "confirm_received":
        return {
          phase,
          title: t2("dealConfirm.receivedTitle"),
          body: t2("dealConfirm.receivedBody"),
          tone: "ok"
        };
      case "verifying":
        return {
          phase,
          title: t2("dealConfirm.verifyingTitle"),
          body: t2("dealConfirm.verifyingBody"),
          tone: "info"
        };
      case "done":
        return {
          phase,
          title: t2("dealConfirm.doneTitle"),
          body: t2("dealConfirm.doneBody"),
          tone: "ok"
        };
      case "guard":
        return {
          phase,
          title: t2("dealConfirm.guardTitle"),
          body: t2("dealConfirm.guardBody"),
          tone: "warn"
        };
      case "accept_steam":
        return {
          phase,
          title: t2("dealConfirm.acceptTitle"),
          body: t2("dealConfirm.acceptBody"),
          tone: "info"
        };
      default:
        return null;
    }
  }
  function dealConfirmBannerHtml(banner, escapeHtml2) {
    return `<div class="deal-confirm tone-${banner.tone}" data-phase="${escapeHtml2(banner.phase)}">
    <p class="deal-confirm-title">${escapeHtml2(banner.title)}</p>
    <p class="deal-confirm-body">${escapeHtml2(banner.body)}</p>
  </div>`;
  }

  // src/shared/deal-flow-metrics.ts
  var STORAGE_KEY = "rip:deal-flow-metrics-v1";
  var ZERO = {
    steam_panel_views: 0,
    accept_assist_armed: 0,
    accept_assist_done: 0,
    received_ack_shown: 0,
    received_ack_clicked: 0,
    received_ack_skipped_dual_signal: 0,
    popup_confirm_primary: 0,
    order_link_clicks: 0,
    updatedAt: null
  };
  function asMetrics(raw) {
    if (!raw || typeof raw !== "object") {
      return { ...ZERO };
    }
    const entry = raw;
    return {
      steam_panel_views: Number(entry.steam_panel_views) || 0,
      accept_assist_armed: Number(entry.accept_assist_armed) || 0,
      accept_assist_done: Number(entry.accept_assist_done) || 0,
      received_ack_shown: Number(entry.received_ack_shown) || 0,
      received_ack_clicked: Number(entry.received_ack_clicked) || 0,
      received_ack_skipped_dual_signal: Number(entry.received_ack_skipped_dual_signal) || 0,
      popup_confirm_primary: Number(entry.popup_confirm_primary) || 0,
      order_link_clicks: Number(entry.order_link_clicks) || 0,
      updatedAt: typeof entry.updatedAt === "string" ? entry.updatedAt : null
    };
  }
  async function readDealFlowMetrics() {
    try {
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      return asMetrics(stored[STORAGE_KEY]);
    } catch {
      return { ...ZERO };
    }
  }
  async function bumpDealFlowMetric(key, by = 1) {
    try {
      const current = await readDealFlowMetrics();
      const next = {
        ...current,
        [key]: (current[key] ?? 0) + by,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      await chrome.storage.local.set({ [STORAGE_KEY]: next });
    } catch {
    }
  }

  // src/shared/extension-context.ts
  function isExtensionContextValid() {
    try {
      return Boolean(
        typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.id === "string" && chrome.runtime.id.length > 0
      );
    } catch {
      return false;
    }
  }
  function isExtensionContextInvalidatedError(error) {
    if (!error) {
      return false;
    }
    const message = error instanceof Error ? error.message : typeof error === "string" ? error : String(error);
    return /Extension context invalidated/i.test(message);
  }

  // src/shared/steam-offer-page-lifecycle.ts
  var ACCEPTED_RE = /trade\s*accepted|обмен\s*принят|предложение\s*принято|trade\s*completed|обмен\s*заверш/i;
  var INVALID_RE = /no\s*longer\s*valid|больше\s*не\s*действ|is\s*no\s*longer\s*available|это\s*предложение\s*обмена\s*больше\s*не\s*действ/i;
  var ERROR_BANNER_RE = /oh\s*nooooooes|some\s*kind\s*of\s*error\s*has\s*occurred/i;
  function detectSteamOfferPageLifecycle(root = document) {
    const doc = root;
    const hasSlots = typeof doc.querySelector === "function" && Boolean(
      doc.querySelector(
        "#trade_ygifts, #trade_themitems, .trade_item_box, #you_notready, #trade_confirmbtn"
      )
    );
    const text = collectSteamStatusText(root);
    if (text) {
      if (ACCEPTED_RE.test(text)) {
        return {
          lifecycle: "accepted",
          offerStatusHint: "accepted",
          reasonRu: "Steam \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442: \u043E\u0431\u043C\u0435\u043D \u043F\u0440\u0438\u043D\u044F\u0442"
        };
      }
      if (INVALID_RE.test(text) || ERROR_BANNER_RE.test(text)) {
        return {
          lifecycle: "invalid",
          offerStatusHint: null,
          reasonRu: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u0442\u044C \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0432 Steam"
        };
      }
    }
    if (hasSlots) {
      return { lifecycle: "active", offerStatusHint: null, reasonRu: null };
    }
    return { lifecycle: "unknown", offerStatusHint: null, reasonRu: null };
  }
  function collectSteamStatusText(root) {
    const chunks = [];
    const doc = root;
    if (typeof doc.querySelectorAll === "function") {
      const nodes = doc.querySelectorAll(
        ".error_ctn, .error_msg, #error_msg, .tradeoffer_items_banner, .trade_accepted, .pageheader, h2, .maincontent"
      );
      for (const node of Array.from(nodes).slice(0, 12)) {
        const value = node.textContent?.replace(/\s+/g, " ").trim();
        if (value) {
          chunks.push(value);
        }
      }
    }
    if (chunks.length === 0 && "body" in doc && doc.body) {
      chunks.push(
        (doc.body.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 2e3)
      );
    }
    return chunks.join("\n");
  }
  function isPostAcceptSteamLifecycle(lifecycle) {
    return lifecycle === "accepted";
  }

  // src/content/trade-verification-bridge.ts
  var PANEL_ID = "rip-market-trade-verification-panel";
  var STICKY_ID = "rip-market-anti-scam-sticky";
  var STEAM_INCOMING_OFFERS_URL = "https://steamcommunity.com/my/tradeoffers/";
  var STEAM_ITEM_IMAGE_CDN = "https://community.cloudflare.steamstatic.com/economy/image";
  var overlayLocale = "ru";
  var t = createExtensionT(overlayLocale);
  var guidedBuyerEnabled = true;
  async function ensureOverlayLocale() {
    overlayLocale = await getStoredExtensionLocale();
    t = createExtensionT(overlayLocale);
  }
  async function refreshGuidedBuyerFlag() {
    guidedBuyerEnabled = await isExtensionGuidedBuyerEnabled();
  }
  var metricOnceKeys = /* @__PURE__ */ new Set();
  function bumpMetricOnce(onceKey, metric) {
    if (metricOnceKeys.has(onceKey)) {
      return;
    }
    metricOnceKeys.add(onceKey);
    void bumpDealFlowMetric(metric);
  }
  var reportedSteamPageKeys = /* @__PURE__ */ new Set();
  function maybeReportSteamOfferPage(trade) {
    const offerId = trade.offerId?.trim();
    if (!offerId) {
      return;
    }
    const page = detectSteamOfferPageLifecycle(document);
    if (!isPostAcceptSteamLifecycle(page.lifecycle)) {
      return;
    }
    const key = `${trade.orderId}:${offerId}:${page.lifecycle}`;
    if (reportedSteamPageKeys.has(key)) {
      return;
    }
    reportedSteamPageKeys.add(key);
    void runtimeRequest({
      type: TRADE_VERIFICATION_RUNTIME.REPORT_STEAM_OFFER_PAGE,
      orderId: trade.orderId,
      offerId,
      lifecycle: page.lifecycle === "invalid" ? "invalid" : "accepted",
      idempotencyKey: `steam-page:${trade.orderId}:${offerId}:${page.lifecycle}`
    }).then((result) => {
      if (!result.ok) reportedSteamPageKeys.delete(key);
    }).catch(() => {
      reportedSteamPageKeys.delete(key);
    });
  }
  var acceptAssistUi = null;
  var lastPanelContext = null;
  function rerenderOfferPanel() {
    if (lastPanelContext) {
      replacePanel(lastPanelContext);
    }
  }
  function preferredSteamAcceptKind() {
    return acceptAssistUi?.lastClickedKind === "accept" ? "confirm" : "accept";
  }
  function armManualAcceptAssist(trade) {
    const offerId = trade.offerId?.trim();
    if (!offerId || !canShowManualAcceptAssist(trade)) {
      return;
    }
    if (!trade.acknowledgments.buyerPreAccept) {
      void runtimeRequest({
        type: TRADE_VERIFICATION_RUNTIME.ACK_TRADE,
        orderId: trade.orderId,
        ackType: "BUYER_ACK_PRE_ACCEPT",
        offerId,
        idempotencyKey: `ack:${trade.orderId}:BUYER_ACK_PRE_ACCEPT:assist-arm`
      }).catch(() => void 0);
    }
    void bumpDealFlowMetric("accept_assist_armed");
    const control = pickSteamAcceptControl(
      findSteamAcceptControls(document),
      preferredSteamAcceptKind()
    );
    if (!control) {
      acceptAssistUi = {
        offerId,
        phase: "error",
        errorMessage: "\u041A\u043D\u043E\u043F\u043A\u0430 Accept \u0432 Steam \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E Accept \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0432\u0440\u0443\u0447\u043D\u0443\u044E."
      };
      rerenderOfferPanel();
      return;
    }
    highlightSteamAcceptControl(control);
    acceptAssistUi = {
      offerId,
      phase: "armed",
      lastClickedKind: acceptAssistUi?.lastClickedKind
    };
    rerenderOfferPanel();
  }
  function cancelManualAcceptAssist(trade) {
    const offerId = trade.offerId?.trim();
    clearSteamAcceptHighlights(document);
    acceptAssistUi = offerId ? {
      offerId,
      phase: "ready",
      lastClickedKind: acceptAssistUi?.lastClickedKind
    } : null;
    rerenderOfferPanel();
  }
  function confirmManualAcceptAssist(trade) {
    const offerId = trade.offerId?.trim();
    if (!offerId || !canShowManualAcceptAssist(trade)) {
      return;
    }
    if (acceptAssistUi?.offerId !== offerId || acceptAssistUi.phase !== "armed") {
      armManualAcceptAssist(trade);
      return;
    }
    const control = pickSteamAcceptControl(
      findSteamAcceptControls(document),
      preferredSteamAcceptKind()
    );
    const result = clickSteamAcceptControl(control, overlayLocale);
    clearSteamAcceptHighlights(document);
    if (!result.ok) {
      acceptAssistUi = {
        offerId,
        phase: "error",
        errorMessage: result.error,
        lastClickedKind: acceptAssistUi.lastClickedKind
      };
      rerenderOfferPanel();
      return;
    }
    acceptAssistUi = {
      offerId,
      phase: "done",
      lastClickedKind: result.kind
    };
    void bumpDealFlowMetric("accept_assist_done");
    rerenderOfferPanel();
    if (!trade.acknowledgments.buyerPreAccept) {
      void runtimeRequest({
        type: TRADE_VERIFICATION_RUNTIME.ACK_TRADE,
        orderId: trade.orderId,
        ackType: "BUYER_ACK_PRE_ACCEPT",
        offerId,
        idempotencyKey: `ack:${trade.orderId}:BUYER_ACK_PRE_ACCEPT:assist`
      }).catch(() => void 0);
    }
  }
  function parseOfferIdFromPath(pathname) {
    const match = pathname.match(/\/tradeoffer\/(\d+)/i);
    return match?.[1] ?? null;
  }
  function formatMoneyMinor2(amountMinor) {
    const value = Number(amountMinor) / 100;
    if (!Number.isFinite(value)) {
      return amountMinor;
    }
    return `$${value.toFixed(2)}`;
  }
  function escapeHtml(value) {
    return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }
  function statusClass(status) {
    if (status === "verified") return "rip-verified";
    if (status === "mismatch") return "rip-mismatch";
    if (status === "partial") return "rip-partial";
    return "rip-pending";
  }
  function getItemImageUrl(iconUrl) {
    if (!iconUrl) {
      return null;
    }
    const normalized = iconUrl.replace(/^\//, "");
    return `${STEAM_ITEM_IMAGE_CDN}/${normalized}`;
  }
  async function runtimeRequest(message) {
    if (!isExtensionContextValid()) {
      throw new Error("Extension context invalidated");
    }
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (error) {
      if (isExtensionContextInvalidatedError(error)) {
        throw error;
      }
      if (!isExtensionContextValid()) {
        throw new Error("Extension context invalidated");
      }
      throw error;
    }
  }
  async function resolveObservedFloat(assetId) {
    const response = await runtimeRequest({
      type: TRADE_VERIFICATION_RUNTIME.RESOLVE_ASSET_FLOAT,
      assetId
    });
    return response.ok ? response.floatValue ?? null : null;
  }
  async function resolveObservedFromPage() {
    const role = detectTradePageRole(window.location.pathname);
    const observedItem = parseObservedItemFromTradePage(role);
    const partnerSteamId = parsePartnerSteamIdFromDocument(
      document,
      window.location.href
    );
    if (!observedItem?.assetId && !partnerSteamId) {
      return null;
    }
    const floatValue = observedItem?.assetId ? await resolveObservedFloat(observedItem.assetId) : null;
    return {
      assetId: observedItem?.assetId ?? null,
      marketHashName: observedItem?.marketHashName ?? null,
      floatValue: floatValue ?? null,
      partnerSteamId
    };
  }
  function readSlotsFromPage() {
    return parseOfferSlotSnapshot(document);
  }
  async function loadTradeForPage() {
    const offerId = parseOfferIdFromPath(window.location.pathname);
    const observed = await resolveObservedFromPage();
    const slots = readSlotsFromPage();
    const observedPayload = {
      ...observed?.assetId ? { observedAssetId: observed.assetId } : {},
      ...observed?.floatValue ? { observedFloatValue: observed.floatValue } : {},
      ...observed?.partnerSteamId ? { observedPartnerSteamId: observed.partnerSteamId } : {}
    };
    if (offerId) {
      const verified = await runtimeRequest({
        type: TRADE_VERIFICATION_RUNTIME.VERIFY_TRADE,
        offerId,
        ...observedPayload
      });
      if (verified.ok && verified.trade) {
        return { trade: verified.trade, observed, slots, offerId };
      }
    }
    const active = await runtimeRequest({
      type: TRADE_VERIFICATION_RUNTIME.GET_ACTIVE_TRADES
    });
    const trades = active.ok ? active.trades : [];
    if (offerId) {
      const fallback = resolveTradeForOfferPage({
        trades,
        offerId,
        observedAssetId: observed?.assetId,
        roleHint: "buyer"
      }) ?? resolveTradeForOfferPage({
        trades,
        offerId,
        observedAssetId: observed?.assetId,
        roleHint: "seller"
      });
      if (!fallback) {
        return { trade: null, observed, slots, offerId };
      }
      if (!observedPayload.observedAssetId && !observedPayload.observedFloatValue && !observedPayload.observedPartnerSteamId) {
        return { trade: fallback, observed, slots, offerId };
      }
      const reverified = await runtimeRequest({
        type: TRADE_VERIFICATION_RUNTIME.VERIFY_TRADE,
        orderId: fallback.orderId,
        // Prefer the canonical linked offer id when present so we do not stamp
        // a false offer_id warning from a duplicate Steam tab.
        offerId: fallback.offerId?.trim() || offerId,
        ...observedPayload
      });
      return {
        trade: reverified.ok && reverified.trade ? reverified.trade : fallback,
        observed,
        slots,
        offerId
      };
    }
    if (window.location.pathname.includes("/tradeoffer/new")) {
      const trade = trades.find(
        (entry) => entry.role === "seller" && entry.orderStatus === "WAITING_TRADE" && !entry.offerId && // After submit/Guard, Steam often redirects back to /new. Do not treat
        // that as "create another offer" — confirm_guard means already in flight.
        entry.nextAction?.kind !== "confirm_guard" && entry.nextAction?.kind !== "send_manual"
      ) ?? null;
      return trade ? { trade, observed, slots, offerId: null } : null;
    }
    return null;
  }
  function collectAntiScamWarnings(context) {
    return evaluateAntiScamRules({
      hasLinkedActiveOrder: Boolean(context.trade),
      role: context.trade?.role ?? detectTradePageRole(window.location.pathname),
      slots: context.slots,
      includeStickyHint: true
    });
  }
  function renderAntiScamWarnings(warnings, options) {
    const actionable = warnings.filter(
      (warning) => warning.id !== "never_accept_from_chat"
    );
    if (actionable.length === 0) {
      return "";
    }
    const blocks = actionable.filter((warning) => warning.severity === "block");
    const warns = actionable.filter((warning) => warning.severity === "warn");
    const infos = actionable.filter((warning) => warning.severity === "info");
    const renderCards = (list) => list.map(
      (warning) => `
        <div class="scam-rule severity-${warning.severity}">
          <p class="scam-rule-title">${escapeHtml(warning.title)}</p>
          <p class="scam-rule-body">${escapeHtml(warning.body)}</p>
        </div>`
    ).join("");
    const critical = renderCards(blocks);
    if (!options?.compact) {
      return `
    <div class="scam-rules" data-testid="anti-scam-rules">
      ${critical}
      ${renderCards(warns)}
      ${renderCards(infos)}
    </div>`;
    }
    const soft = [...warns, ...infos];
    const softHtml = soft.length > 0 ? `<details class="more">
          <summary>\u0417\u0430\u0449\u0438\u0442\u0430 \xB7 ${soft.length}</summary>
          <div class="more-body">${renderCards(soft)}</div>
        </details>` : "";
    if (!critical && !softHtml) {
      return "";
    }
    return `
    <div class="scam-rules" data-testid="anti-scam-rules">
      ${critical}
      ${softHtml}
    </div>`;
  }
  function ensureStickyHint() {
    if (!document.getElementById("rip-market-anti-scam-sticky-style")) {
      const style = document.createElement("style");
      style.id = "rip-market-anti-scam-sticky-style";
      style.textContent = `
      #${STICKY_ID} {
        position: fixed; left: 12px; right: 12px; bottom: 12px; z-index: 2147483645;
        max-width: 420px; margin: 0 auto; padding: 10px 14px; border-radius: 10px;
        background: rgba(24, 28, 38, 0.96); color: #fde047;
        border: 1px solid rgba(234, 179, 8, 0.35);
        font-family: Inter, system-ui, -apple-system, sans-serif;
        font-size: 12px; line-height: 1.4;
        box-shadow: 0 12px 32px rgba(0,0,0,.45); pointer-events: none;
      }
    `;
      document.documentElement.appendChild(style);
    }
    let sticky = document.getElementById(STICKY_ID);
    if (!sticky) {
      sticky = document.createElement("div");
      sticky.id = STICKY_ID;
      document.documentElement.appendChild(sticky);
    }
    sticky.textContent = antiScamStickyShort();
  }
  function renderFailedChecks(trade) {
    const failed = trade.checks.filter((check) => !check.passed);
    if (failed.length === 0) {
      return "";
    }
    return `<ul class="checks">${failed.map((check) => {
      const icon = check.severity === "error" ? "\u2715" : "\u2022";
      return `<li class="${check.severity}">${icon} ${escapeHtml(check.label)}</li>`;
    }).join("")}</ul>`;
  }
  function renderCompareSection(model, options) {
    const rows = model.compareRows;
    if (rows.length === 0) {
      return "";
    }
    const hasProblem = rows.some((row) => row.tone !== "ok");
    const table = `
    <div class="compare">
      <div class="compare-head">
        <span></span>
        <span>${escapeHtml(t("shield.expectedCol"))}</span>
        <span>${escapeHtml(t("shield.observedCol"))}</span>
      </div>
      ${rows.map(
      (row) => `
        <div class="compare-row tone-${row.tone}">
          <span class="compare-label">${escapeHtml(row.label)}</span>
          <span class="compare-expected">${escapeHtml(row.expected)}</span>
          <span class="compare-observed">${escapeHtml(row.observed)}</span>
        </div>`
    ).join("")}
    </div>`;
    if (hasProblem || options.forceOpen) {
      return `
      <div class="compare-wrap">
        <p class="section-label">${escapeHtml(t("shield.compareTitle"))}</p>
        ${table}
      </div>`;
    }
    return `
    <details class="more">
      <summary>\u0421\u0432\u0435\u0440\u043A\u0430 \u0441\u043E Steam \xB7 \u0432\u0441\u0451 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442</summary>
      <div class="more-body">
        <p class="section-label">${escapeHtml(t("shield.compareTitle"))}</p>
        ${table}
      </div>
    </details>`;
  }
  function renderPartnerBlock(model, options) {
    const steamId = model.partner.steamId;
    const avatar = model.partner.avatarUrl ? `<img class="partner-avatar" src="${escapeHtml(model.partner.avatarUrl)}" alt="" />` : `<div class="partner-avatar-fallback" aria-hidden="true">${escapeHtml(
      model.partner.displayName.slice(0, 1).toUpperCase()
    )}</div>`;
    const matchTone = model.partner.match === "match" ? "ok" : model.partner.match === "mismatch" ? "error" : "warn";
    const profile = model.partner.profileUrl ? `<a class="partner-link" href="${escapeHtml(model.partner.profileUrl)}" target="_blank" rel="noreferrer">${escapeHtml(t("shield.openProfile"))}</a>` : "";
    const tools = `
      <div class="partner-row">
        <span class="partner-id" data-steamid>${steamId ? escapeHtml(steamId) : escapeHtml(t("shield.steamIdMissing"))}</span>
        ${steamId ? `<button type="button" class="copy-btn" data-action="copy-steamid">${escapeHtml(t("shield.copySteamId"))}</button>` : ""}
        ${profile}
      </div>`;
    return `
    <div class="partner">
      <div class="partner-top">
        ${avatar}
        <div class="partner-copy">
          <p class="partner-label">${escapeHtml(model.counterpartyRoleLabel)}</p>
          <p class="partner-name">${escapeHtml(model.partner.displayName)}</p>
          <p class="partner-match tone-${matchTone}">${escapeHtml(model.partner.matchLabel)}</p>
        </div>
      </div>
      ${options.expandTools ? tools : steamId ? `<details class="more partner-more">
                <summary>SteamID \u0438 \u043F\u0440\u043E\u0444\u0438\u043B\u044C</summary>
                <div class="more-body">${tools}</div>
              </details>` : tools}
    </div>`;
  }
  function renderItemHero(model) {
    const imageUrl = getItemImageUrl(model.item.iconUrl);
    return `
    <div class="hero">
      ${imageUrl ? `<img class="preview" src="${escapeHtml(imageUrl)}" alt="" />` : `<div class="preview-fallback">CS2</div>`}
      <div class="hero-copy">
        <p class="item-name">${escapeHtml(model.item.marketHashName)}</p>
        <p class="meta">${escapeHtml(
      t("shield.dealLine", {
        short: model.orderShortId,
        amount: model.amountLabel
      })
    )}</p>
      </div>
    </div>`;
  }
  function primaryCtaHtml(trade, shield, sellerGate) {
    const status = shield.effectiveStatus;
    const onOfferPage = Boolean(parseOfferIdFromPath(window.location.pathname));
    const onNewOfferPage = window.location.pathname.includes("/tradeoffer/new");
    if (status === "mismatch" || trade.orderStatus === "DISPUTE" || shield.partner.match === "mismatch") {
      const supportUrl = buildInFlowDisputeSupportUrl(trade);
      const isOpenDispute = trade.orderStatus === "DISPUTE";
      const orderHref = sanitizeTradeOrderUrl(trade.siteUrl, trade.orderId);
      if (isOpenDispute) {
        return `
      <p class="primary-hint block">${escapeHtml(t("dispute.openTitle"))}</p>
      <a class="btn primary" href="${escapeHtml(orderHref)}" target="_blank" rel="noreferrer">${escapeHtml(t("cta.openOrder"))}</a>
      <a class="btn secondary" href="${escapeHtml(supportUrl)}" target="_blank" rel="noreferrer">${escapeHtml(t("cta.openDisputeSupport"))}</a>`;
      }
      return `
      <p class="primary-hint block">${shield.partner.match === "mismatch" ? escapeHtml(t("shield.partnerMismatch")) : escapeHtml(t("guided.hintBlock"))}</p>
      <a class="btn danger" href="${escapeHtml(supportUrl)}" target="_blank" rel="noreferrer">${escapeHtml(t("cta.openDispute"))}</a>
      <a class="btn secondary" href="${escapeHtml(orderHref)}" target="_blank" rel="noreferrer">${escapeHtml(t("cta.openOrder"))}</a>`;
    }
    if (guidedBuyerEnabled && trade.role === "buyer" && onOfferPage && canShowManualAcceptAssist({
      ...trade,
      verificationStatus: status
    }) && shield.partner.match === "match") {
      const phase = acceptAssistUi?.offerId === trade.offerId ? acceptAssistUi.phase : "ready";
      const view = buildOfferAcceptAssistView({
        phase,
        errorMessage: acceptAssistUi?.errorMessage,
        lastClickedKind: acceptAssistUi?.lastClickedKind,
        locale: overlayLocale
      });
      const primaryAction = view.phase === "armed" ? "accept-steam-confirm" : "accept-steam";
      const primaryClass = view.phase === "armed" ? "btn danger" : "btn primary accept-cta";
      const secondary = view.secondaryLabel != null ? `<button type="button" class="btn secondary" data-action="accept-steam-cancel">${escapeHtml(view.secondaryLabel)}</button>` : "";
      return `
      <p class="primary-hint ${view.tone === "error" ? "block" : view.tone === "warn" ? "wait" : "accept"}">${escapeHtml(view.hint)}</p>
      <button type="button" class="${primaryClass}" data-action="${primaryAction}">${escapeHtml(view.primaryLabel)}</button>
      ${secondary}`;
    }
    if (trade.role === "buyer" && onOfferPage) {
      const hint = buyerOfferPagePrimaryHint(status, overlayLocale);
      if (hint.kind === "accept_steam") {
        return `<p class="primary-hint accept">${escapeHtml(hint.text)}</p>`;
      }
      return `<p class="primary-hint wait">${escapeHtml(hint.text)}</p>`;
    }
    if (trade.role === "buyer") {
      return `<a class="btn primary" href="${STEAM_INCOMING_OFFERS_URL}" target="_blank" rel="noreferrer">\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F</a>`;
    }
    if (trade.role === "seller" && onNewOfferPage && sellerGate) {
      return "";
    }
    if (trade.nextAction.kind === "confirm_guard") {
      return `<p class="primary-hint wait">\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443 \u0432 Steam Guard \u043D\u0430 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0435. \u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 Guard \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442 \u2014 \u0441\u0442\u0430\u0442\u0443\u0441 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0441\u0430\u043C.</p>`;
    }
    if (trade.nextAction.kind === "platform_verifying") {
      return `<p class="primary-hint wait">${escapeHtml(trade.nextAction.title)} \u2014 ${escapeHtml(trade.nextAction.description)}</p>`;
    }
    if (trade.nextAction.kind === "send_manual") {
      const tradeUrl = trade.buyerTradeUrl?.trim();
      if (tradeUrl) {
        return `<a class="btn primary" href="${escapeHtml(tradeUrl)}" target="_blank" rel="noreferrer">\u041E\u0442\u043A\u0440\u044B\u0442\u044C Trade URL \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F</a>`;
      }
      return `<a class="btn primary" href="${escapeHtml(trade.siteUrl)}" target="_blank" rel="noreferrer">\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437 \u2014 \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0432\u0440\u0443\u0447\u043D\u0443\u044E</a>`;
    }
    if (!trade.offerId) {
      return `<p class="primary-hint wait">\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442 \u043E\u0431\u043C\u0435\u043D \u0441\u0430\u043C\u043E \u2014 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0430\u0436\u0438\u043C\u0430\u0442\u044C \u043D\u0435 \u043D\u0443\u0436\u043D\u043E</p>`;
    }
    return `<p class="primary-hint wait">\u0416\u0434\u0451\u043C \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u2014 \u043E\u0431\u043C\u0435\u043D \u0443\u0436\u0435 \u0443\u0448\u0451\u043B</p>`;
  }
  var PANEL_STYLES = `
      .panel {
        --rip-bg: #0b0d12;
        --rip-elevated: rgba(24, 28, 38, 0.96);
        --rip-text: #f4f4f5;
        --rip-muted: #94a3b8;
        --rip-soft: #a8b0c0;
        --rip-border: rgba(255, 255, 255, 0.08);
        --rip-border-strong: rgba(255, 255, 255, 0.12);
        --rip-link: #7dd3fc;
        --rip-primary-from: #0284c7;
        --rip-primary-to: #2563eb;
        --rip-success: #86efac;
        --rip-success-bg: rgba(34, 197, 94, 0.14);
        --rip-warn: #fde047;
        --rip-warn-bg: rgba(234, 179, 8, 0.12);
        --rip-danger: #fecaca;
        --rip-danger-bg: rgba(239, 68, 68, 0.14);
        --rip-info-bg: rgba(56, 189, 248, 0.1);
        --rip-radius: 12px;
        --rip-radius-sm: 8px;

        position: fixed; top: 72px; right: 16px; z-index: 2147483646;
        width: min(360px, calc(100vw - 28px));
        padding: 14px;
        border-radius: var(--rip-radius);
        font-family: Inter, system-ui, -apple-system, sans-serif;
        color: var(--rip-text);
        background:
          radial-gradient(circle at top right, rgba(56, 189, 248, 0.1), transparent 42%),
          var(--rip-elevated);
        border: 1px solid var(--rip-border);
        box-shadow: 0 18px 48px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255,255,255,0.03);
        display: grid;
        gap: 8px;
      }
      .rip-verified { border-color: rgba(34, 197, 94, 0.35); }
      .rip-mismatch, .rip-scam-block { border-color: rgba(248, 113, 113, 0.4); }
      .rip-partial { border-color: rgba(234, 179, 8, 0.35); }

      .brand {
        display: flex; align-items: baseline; justify-content: space-between; gap: 8px;
      }
      .brand-mark {
        margin: 0; font-size: 12px; font-weight: 700; letter-spacing: -0.02em; color: var(--rip-text);
      }
      .brand-chip {
        margin: 0; font-size: 10px; color: var(--rip-muted); letter-spacing: 0.04em; text-transform: uppercase;
      }

      .gate-banner {
        margin: 0; padding: 11px 12px; border-radius: var(--rip-radius-sm);
        background: rgba(15, 23, 42, 0.72); border: 1px solid var(--rip-border);
      }
      .gate-banner.ok {
        background: var(--rip-success-bg); border-color: rgba(34, 197, 94, 0.35);
      }
      .gate-banner.error {
        background: var(--rip-danger-bg); border-color: rgba(248, 113, 113, 0.4);
      }
      .gate-banner.warn {
        background: var(--rip-warn-bg); border-color: rgba(234, 179, 8, 0.4);
      }
      .gate-banner.pending { background: rgba(15, 23, 42, 0.8); }
      .gate-title {
        margin: 0 0 4px; font-size: 15px; font-weight: 700; line-height: 1.25; letter-spacing: -0.01em;
      }
      .gate-banner.ok .gate-title { color: var(--rip-success); }
      .gate-banner.error .gate-title { color: var(--rip-danger); }
      .gate-banner.warn .gate-title { color: var(--rip-warn); }
      .gate-sub { margin: 0; font-size: 12px; color: var(--rip-soft); line-height: 1.4; }

      .hero {
        display: grid; grid-template-columns: 56px 1fr; gap: 10px; align-items: center;
      }
      .preview {
        width: 56px; height: 42px; border-radius: 8px; object-fit: contain;
        background: #0b0d12; border: 1px solid var(--rip-border);
      }
      .preview-fallback {
        width: 56px; height: 42px; border-radius: 8px; display: grid; place-items: center;
        background: #0b0d12; border: 1px solid var(--rip-border); color: var(--rip-muted); font-size: 10px;
      }
      .hero-copy { min-width: 0; }
      .item-name {
        font-size: 13px; font-weight: 650; margin: 0 0 2px; line-height: 1.3;
        display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
      }
      .meta { font-size: 11px; color: var(--rip-muted); margin: 0; }

      .money {
        margin: 0; padding: 8px 10px; border-radius: 8px;
        background: var(--rip-success-bg); border: 1px solid rgba(34, 197, 94, 0.28);
        font-size: 12px; color: var(--rip-success); line-height: 1.35;
      }
      .money strong { color: #b8f5c6; font-weight: 650; }

      .partner {
        display: grid; gap: 6px; margin: 0; padding: 10px;
        border-radius: var(--rip-radius-sm);
        background: rgba(15, 23, 42, 0.55); border: 1px solid var(--rip-border);
      }
      .partner-top { display: flex; gap: 10px; align-items: center; }
      .partner-avatar {
        width: 36px; height: 36px; border-radius: 50%; object-fit: cover;
        border: 1px solid var(--rip-border); background: #0b0d12; flex-shrink: 0;
      }
      .partner-avatar-fallback {
        width: 36px; height: 36px; border-radius: 50%; display: grid; place-items: center;
        background: #0b0d12; border: 1px solid var(--rip-border); color: var(--rip-soft);
        font-size: 13px; font-weight: 700; flex-shrink: 0;
      }
      .partner-copy { min-width: 0; flex: 1; }
      .partner-label {
        font-size: 10px; color: var(--rip-muted); margin: 0;
        text-transform: uppercase; letter-spacing: 0.04em;
      }
      .partner-name { font-size: 13px; font-weight: 650; margin: 2px 0; color: var(--rip-text); }
      .partner-match { font-size: 11px; margin: 0; }
      .partner-match.tone-ok { color: var(--rip-success); }
      .partner-match.tone-warn { color: var(--rip-warn); }
      .partner-match.tone-error { color: var(--rip-danger); font-weight: 700; }
      .partner-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
      .partner-id {
        flex: 1; font-size: 11px; font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        color: var(--rip-soft); word-break: break-all; min-width: 100px;
      }
      .partner-link {
        font-size: 11px; color: var(--rip-link); text-decoration: none;
        border: 1px solid rgba(125, 211, 252, 0.28); border-radius: 7px; padding: 5px 8px;
      }
      .partner-link:hover { background: rgba(56, 189, 248, 0.1); }
      .copy-btn {
        flex-shrink: 0; border: 1px solid var(--rip-border); border-radius: 7px; padding: 5px 8px;
        background: rgba(255,255,255,0.04); color: var(--rip-text); font-size: 11px; cursor: pointer;
      }
      .copy-btn:hover { background: rgba(255,255,255,0.08); }

      .section-label {
        margin: 0 0 6px; font-size: 10px; letter-spacing: 0.05em;
        text-transform: uppercase; color: var(--rip-muted);
      }
      .compare-wrap { margin: 0; }
      .compare {
        display: grid; gap: 4px; margin: 0;
        padding: 8px; border-radius: 8px;
        background: rgba(11, 13, 18, 0.7); border: 1px solid var(--rip-border);
      }
      .compare-head, .compare-row {
        display: grid; grid-template-columns: 68px 1fr 1fr; gap: 6px; align-items: start;
      }
      .compare-head { font-size: 10px; color: var(--rip-muted); text-transform: uppercase; letter-spacing: 0.04em; }
      .compare-label { font-size: 11px; color: var(--rip-muted); }
      .compare-expected, .compare-observed {
        font-size: 11px; color: var(--rip-soft); word-break: break-word; line-height: 1.35;
      }
      .tone-ok .compare-observed { color: var(--rip-success); }
      .tone-error .compare-observed { color: var(--rip-danger); font-weight: 700; }
      .tone-warn .compare-observed { color: var(--rip-warn); }

      .checks { margin: 0; padding: 0; list-style: none; display: grid; gap: 4px; }
      .checks li { font-size: 12px; margin: 0; color: var(--rip-soft); }
      .checks li.error { color: var(--rip-danger); }
      .checks li.warn { color: var(--rip-warn); }

      .scam-rules { display: grid; gap: 8px; margin: 0; }
      .scam-rule {
        padding: 8px 10px; border-radius: 8px;
        border: 1px solid var(--rip-border); background: rgba(11, 13, 18, 0.65);
      }
      .scam-rule.severity-block {
        background: var(--rip-danger-bg); border-color: rgba(248, 113, 113, 0.4);
      }
      .scam-rule.severity-warn {
        background: var(--rip-warn-bg); border-color: rgba(234, 179, 8, 0.35);
      }
      .scam-rule-title { margin: 0 0 3px; font-size: 12px; font-weight: 650; color: var(--rip-text); }
      .severity-block .scam-rule-title { color: var(--rip-danger); }
      .severity-warn .scam-rule-title { color: var(--rip-warn); }
      .scam-rule-body { margin: 0; font-size: 11px; color: var(--rip-soft); line-height: 1.4; }

      .pre-send {
        margin: 0; padding: 8px 10px; border-radius: 8px;
        background: var(--rip-info-bg); border: 1px solid rgba(125, 211, 252, 0.28);
      }
      .pre-send-title { margin: 0 0 3px; font-size: 12px; font-weight: 650; color: #d7e4ff; }
      .pre-send-body { margin: 0; font-size: 11px; color: var(--rip-muted); line-height: 1.4; }

      .primary-hint {
        margin: 0; padding: 10px 12px; border-radius: 8px;
        font-size: 13px; font-weight: 650; text-align: center; line-height: 1.35;
      }
      .primary-hint.accept {
        background: var(--rip-success-bg); border: 1px solid rgba(34, 197, 94, 0.35); color: var(--rip-success);
      }
      .primary-hint.wait {
        background: var(--rip-info-bg); border: 1px solid rgba(125, 211, 252, 0.28); color: #d7e4ff;
      }
      .primary-hint.block {
        background: var(--rip-danger-bg); border: 1px solid rgba(248, 113, 113, 0.4); color: var(--rip-danger);
      }

      .actions { display: grid; gap: 8px; margin: 0; }
      button, a.btn {
        display: block; text-align: center; text-decoration: none; border: none;
        border-radius: var(--rip-radius-sm); padding: 10px 12px; font-size: 13px; font-weight: 600; cursor: pointer;
      }
      .primary {
        background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
        color: #fff;
      }
      .primary.accept-cta {
        background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
        box-shadow: inset 0 0 0 1px rgba(134, 239, 172, 0.35);
      }
      .primary.accept-cta:hover { filter: brightness(1.06); }
      .secondary {
        background: rgba(255,255,255,0.04); color: var(--rip-text);
        border: 1px solid var(--rip-border);
      }
      .linkish {
        display: block; text-align: center; font-size: 12px; color: var(--rip-link);
        text-decoration: none; padding: 2px 0;
      }
      .linkish:hover { text-decoration: underline; }
      .danger { background: #b91c1c; color: #fff; }
      .primary:disabled, .secondary:disabled { opacity: .55; cursor: not-allowed; }

      details.more, details.ack {
        margin: 0; border-top: 1px solid var(--rip-border); padding-top: 8px;
      }
      details.partner-more { border-top: none; padding-top: 0; }
      details.more summary, details.ack summary {
        cursor: pointer; font-size: 12px; color: var(--rip-muted); user-select: none;
        list-style: none;
      }
      details.more summary::-webkit-details-marker,
      details.ack summary::-webkit-details-marker { display: none; }
      details.more summary::before,
      details.ack summary::before {
        content: "\u25B8"; display: inline-block; margin-right: 6px; color: var(--rip-muted);
      }
      details.more[open] summary::before,
      details.ack[open] summary::before { content: "\u25BE"; }
      .more-body, .ack-body { display: grid; gap: 8px; margin-top: 8px; }
      .ack-note { margin: 0; font-size: 11px; color: var(--rip-muted); }

      .never-auto {
        margin: 0; font-size: 10px; color: var(--rip-muted); text-align: center; line-height: 1.35;
      }
      .deal-confirm {
        margin: 0; padding: 8px 10px; border-radius: 8px;
        background: rgba(15, 23, 42, 0.55); border: 1px solid var(--rip-border);
      }
      .deal-confirm.tone-ok {
        background: var(--rip-success-bg); border-color: rgba(34, 197, 94, 0.28);
      }
      .deal-confirm.tone-warn {
        background: var(--rip-warn-bg); border-color: rgba(234, 179, 8, 0.28);
      }
      .deal-confirm.tone-info {
        background: var(--rip-info-bg); border-color: rgba(56, 189, 248, 0.22);
      }
      .deal-confirm-title {
        margin: 0 0 2px; font-size: 13px; font-weight: 650; line-height: 1.3; color: var(--rip-text);
      }
      .deal-confirm.tone-ok .deal-confirm-title { color: var(--rip-success); }
      .deal-confirm.tone-warn .deal-confirm-title { color: var(--rip-warn); }
      .deal-confirm-body {
        margin: 0; font-size: 11px; color: var(--rip-soft); line-height: 1.35;
      }
`;
  function buildUnlinkedPanel(context) {
    const host = document.createElement("div");
    host.id = PANEL_ID;
    const shadow = host.attachShadow({ mode: "open" });
    const warnings = collectAntiScamWarnings(context);
    const offerLabel = context.offerId ? `#${context.offerId}` : "\u044D\u0442\u043E\u0442 offer";
    shadow.innerHTML = `
    <style>${PANEL_STYLES}</style>
    <div class="panel rip-scam-block">
      <div class="brand">
        <p class="brand-mark">R.I.P Market</p>
        <p class="brand-chip">Steam</p>
      </div>
      <div class="gate-banner error">
        <p class="gate-title">\u041D\u0435 \u043D\u0430\u0448\u0430 \u0441\u0434\u0435\u043B\u043A\u0430</p>
        <p class="gate-sub">Offer ${escapeHtml(offerLabel)} \u043D\u0435 \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D \u043A \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u043C\u0443 \u0437\u0430\u043A\u0430\u0437\u0443. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435.</p>
      </div>
      ${renderAntiScamWarnings(warnings, { compact: false })}
      <div class="actions">
        <p class="primary-hint block">\u041D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435 Accept \u0432 Steam</p>
        <a class="btn secondary" href="${STEAM_INCOMING_OFFERS_URL}" target="_blank" rel="noreferrer">\u041A \u0441\u043F\u0438\u0441\u043A\u0443 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0439</a>
      </div>
      <p class="never-auto">R.I.P Market \u043D\u0438\u043A\u043E\u0433\u0434\u0430 \u043D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0435\u0442 Accept \u0437\u0430 \u0432\u0430\u0441</p>
    </div>
  `;
    return host;
  }
  function buildPanel(context) {
    if (!context.trade) {
      return buildUnlinkedPanel(context);
    }
    const { trade: rawTrade, observed } = context;
    const host = document.createElement("div");
    host.id = PANEL_ID;
    const shadow = host.attachShadow({ mode: "open" });
    const isPreSendPage = window.location.pathname.includes("/tradeoffer/new");
    const sellerGate = isPreSendPage && rawTrade.role === "seller" ? resolveSellerTradeOfferGate({
      expectedAssetId: rawTrade.item.assetExternalId
    }) : null;
    const shield = buildDealShieldModel({
      trade: rawTrade,
      observed,
      locale: overlayLocale,
      isPreSend: isPreSendPage && rawTrade.role === "seller"
    });
    const trade = applyPartnerObservation(
      rawTrade,
      observed?.partnerSteamId,
      overlayLocale
    );
    const status = shield.effectiveStatus;
    const steamId = shield.partner.steamId;
    const onOfferPage = Boolean(parseOfferIdFromPath(window.location.pathname));
    const warnings = collectAntiScamWarnings(context);
    const scamBlocks = antiScamHasBlocking(warnings);
    let headline = sellerGate && status !== "mismatch" && !scamBlocks ? {
      need_cs2: {
        title: t("offerGate.needCs2Title"),
        subtitle: t("offerGate.needCs2Body"),
        tone: "warn"
      },
      need_item: {
        title: t("offerGate.needItemTitle"),
        subtitle: t("offerGate.needItemBody", {
          name: trade.item.marketHashName
        }),
        tone: "warn"
      },
      item_ready: {
        title: t("offerGate.itemReadyTitle"),
        subtitle: t("offerGate.itemReadyBody"),
        tone: "ok"
      }
    }[sellerGate] : shield.headline;
    const steamPage = detectSteamOfferPageLifecycle(document);
    const steamPostAccept = isPostAcceptSteamLifecycle(steamPage.lifecycle);
    if (steamPostAccept) {
      maybeReportSteamOfferPage(trade);
      if (status !== "mismatch" && !scamBlocks) {
        headline = {
          title: steamPage.lifecycle === "accepted" ? "\u041E\u0431\u043C\u0435\u043D \u0432 Steam \u043F\u0440\u0438\u043D\u044F\u0442" : "\u041E\u0431\u043C\u0435\u043D \u0432 Steam \u0443\u0436\u0435 \u0437\u0430\u043A\u0440\u044B\u0442",
          subtitle: trade.role === "buyer" ? "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \xAB\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u043C\u0435\u043D\u044F\xBB \u0437\u0434\u0435\u0441\u044C \u2014 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u0437\u0430\u043A\u0440\u043E\u0435\u0442 \u0441\u0434\u0435\u043B\u043A\u0443. Accept \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0435 \u043D\u0443\u0436\u0435\u043D." : "\u041F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044C \u043F\u0440\u0438\u043D\u044F\u043B \u043E\u0431\u043C\u0435\u043D. \u0421\u0442\u0430\u0442\u0443\u0441 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u043F\u043E\u0441\u043B\u0435 \u0441\u0432\u0435\u0440\u043A\u0438 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438.",
          tone: "ok"
        };
      }
    }
    const acceptAllowed = !steamPostAccept && canShowManualAcceptAssist({
      ...trade,
      verificationStatus: status
    }) && shield.partner.match === "match" && !scamBlocks;
    const acceptAssistDone = steamPostAccept || acceptAssistUi?.offerId === trade.offerId && acceptAssistUi.phase === "done";
    const confirmPhase = resolveDealConfirmPhase(trade, {
      acceptAssistDone
    });
    const confirmBanner = buildDealConfirmBanner(trade, overlayLocale, {
      acceptAssistDone
    });
    const showConfirmReceived = needsBuyerReceivedConfirm(trade, { acceptAssistDone }) && status !== "mismatch" && !scamBlocks;
    const showPrimaryReceived = showConfirmReceived && !(acceptAllowed && acceptAssistUi?.phase !== "done" && trade.orderStatus === "WAITING_TRADE");
    if (trade.role === "buyer" && !showConfirmReceived && isDeliveryDualSignalOk(trade.deliveryProgress) && !trade.acknowledgments.buyerReceived) {
      bumpMetricOnce(
        `skip-dual:${trade.orderId}`,
        "received_ack_skipped_dual_signal"
      );
    }
    if (showPrimaryReceived) {
      bumpMetricOnce(`shown:${trade.orderId}`, "received_ack_shown");
    }
    bumpMetricOnce(
      `panel:${trade.orderId}:${trade.offerId ?? "none"}`,
      "steam_panel_views"
    );
    const buyerCtaOverride = trade.role === "buyer" && onOfferPage && scamBlocks && status !== "mismatch" ? `<p class="primary-hint block">\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0443\u0441\u0442\u0440\u0430\u043D\u0438\u0442\u0435 anti-scam \u043F\u0440\u0435\u0434\u0443\u043F\u0440\u0435\u0436\u0434\u0435\u043D\u0438\u044F \u2014 Accept \u043F\u043E\u043A\u0430 \u043D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435</p>` : showPrimaryReceived ? `<button type="button" class="btn primary accept-cta" data-action="confirm-received">${escapeHtml(t("cta.confirmReceived"))}</button>` : primaryCtaHtml(trade, shield, sellerGate);
    const dealConfirmHtml = confirmBanner && trade.role === "buyer" && !scamBlocks && status !== "mismatch" && !showPrimaryReceived && !(acceptAllowed && !acceptAssistDone) ? dealConfirmBannerHtml(confirmBanner, escapeHtml) : "";
    const preSendBanner = shield.isPreSend && !sellerGate ? `<div class="pre-send">
        <p class="pre-send-title">${escapeHtml(t("shield.preSendTitle"))}</p>
        <p class="pre-send-body">${escapeHtml(t("shield.preSendBody"))}</p>
      </div>` : "";
    const showOrderLink = status !== "mismatch" && shield.partner.match !== "mismatch" && (trade.role === "seller" || confirmPhase === "verifying" || confirmPhase === "done" || trade.orderStatus === "DISPUTE");
    const partnerToolsOpen = status === "mismatch" || shield.partner.match === "mismatch";
    const compareForceOpen = status === "mismatch" || status === "partial" || scamBlocks;
    const quietAntiScam = status !== "mismatch" && !scamBlocks && shield.partner.match !== "mismatch";
    const moneyLine = trade.escrow.status === "active" ? `<p class="money"><strong>Hold ${formatMoneyMinor2(trade.escrow.holdAmountMinor)}</strong> \xB7 \u043D\u0435 \u043F\u043B\u0430\u0442\u0438\u0442\u0435 \u0432 \u0447\u0430\u0442 Steam</p>` : `<p class="money"><strong>\u041E\u043F\u043B\u0430\u0442\u0430 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435</strong> \xB7 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442\u0435 \u0434\u0435\u043D\u044C\u0433\u0438 \u0432 \u0447\u0430\u0442 Steam</p>`;
    shadow.innerHTML = `
    <style>${PANEL_STYLES}</style>
    <div class="panel ${statusClass(status)}${scamBlocks ? " rip-scam-block" : ""}">
      <div class="brand">
        <p class="brand-mark">R.I.P Market</p>
        <p class="brand-chip">${trade.role === "seller" ? "\u041F\u0440\u043E\u0434\u0430\u0436\u0430" : "\u041F\u043E\u043A\u0443\u043F\u043A\u0430"}</p>
      </div>
      <div class="gate-banner ${scamBlocks && status !== "mismatch" ? "error" : headline.tone}">
        <p class="gate-title">${escapeHtml(
      scamBlocks && status !== "mismatch" ? "\u0421\u0442\u043E\u043F \u2014 \u0440\u0438\u0441\u043A \u0441\u043A\u0430\u043C\u0430" : headline.title
    )}</p>
        <p class="gate-sub">${escapeHtml(
      scamBlocks && status !== "mismatch" ? "\u0412 \u043E\u0444\u0444\u0435\u0440\u0435 \u0435\u0441\u0442\u044C \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0438 \u043E\u043F\u0430\u0441\u043D\u043E\u0439 \u043F\u043E\u0434\u043C\u0435\u043D\u044B. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435, \u043F\u043E\u043A\u0430 \u043F\u0440\u0435\u0434\u0443\u043F\u0440\u0435\u0436\u0434\u0435\u043D\u0438\u044F \u043D\u0435 \u0441\u043D\u044F\u0442\u044B." : headline.subtitle
    )}</p>
      </div>
      ${dealConfirmHtml}
      ${preSendBanner}
      ${renderItemHero(shield)}
      ${renderPartnerBlock(shield, { expandTools: partnerToolsOpen })}
      ${moneyLine}
      <div class="actions">
        ${buyerCtaOverride}
        ${showOrderLink ? `<a class="linkish" href="${escapeHtml(trade.siteUrl)}" target="_blank" rel="noreferrer" data-action="open-order">${escapeHtml(t("cta.openOrder"))}</a>` : ""}
      </div>
      ${renderAntiScamWarnings(warnings, { compact: quietAntiScam })}
      ${onOfferPage || isPreSendPage ? renderCompareSection(shield, { forceOpen: compareForceOpen }) : ""}
      ${renderFailedChecks(trade)}
      <p class="never-auto">${trade.role === "buyer" && onOfferPage && acceptAllowed && !showPrimaryReceived ? "Accept \u0432 Steam \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0441\u043B\u0435 \u0432\u0430\u0448\u0435\u0433\u043E \u0434\u0432\u043E\u0439\u043D\u043E\u0433\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F." : "R.I.P Market \u043D\u0438\u043A\u043E\u0433\u0434\u0430 \u043D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0435\u0442 Accept \u0437\u0430 \u0432\u0430\u0441"}</p>
    </div>
  `;
    shadow.querySelector('button[data-action="copy-steamid"]')?.addEventListener("click", (event) => {
      const button = event.currentTarget;
      if (!steamId) {
        return;
      }
      void navigator.clipboard.writeText(steamId).then(
        () => {
          button.textContent = t("shield.copied");
          window.setTimeout(() => {
            button.textContent = t("shield.copySteamId");
          }, 1600);
        },
        () => {
          button.textContent = "\u041E\u0448\u0438\u0431\u043A\u0430";
        }
      );
    });
    shadow.querySelector('button[data-action="seller-sent"]')?.addEventListener("click", (event) => {
      void acknowledgeSellerSent(
        trade,
        event.currentTarget
      );
    });
    shadow.querySelector('button[data-action="pre-accept"]')?.addEventListener("click", (event) => {
      void acknowledgePreAccept(
        trade,
        event.currentTarget
      );
    });
    shadow.querySelector('button[data-action="confirm-received"]')?.addEventListener("click", (event) => {
      void acknowledgeReceived(trade, event.currentTarget);
    });
    shadow.querySelector('a[data-action="open-order"]')?.addEventListener("click", () => {
      void bumpDealFlowMetric("order_link_clicks");
    });
    shadow.querySelector('button[data-action="accept-steam"]')?.addEventListener("click", (event) => {
      event.preventDefault();
      armManualAcceptAssist(trade);
    });
    shadow.querySelector(
      'button[data-action="accept-steam-confirm"]'
    )?.addEventListener("click", (event) => {
      event.preventDefault();
      confirmManualAcceptAssist(trade);
    });
    shadow.querySelector(
      'button[data-action="accept-steam-cancel"]'
    )?.addEventListener("click", (event) => {
      event.preventDefault();
      cancelManualAcceptAssist(trade);
    });
    return host;
  }
  async function acknowledgeSellerSent(trade, button) {
    button.disabled = true;
    button.textContent = "\u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u043C\u2026";
    const response = await runtimeRequest({
      type: TRADE_VERIFICATION_RUNTIME.ACK_TRADE,
      orderId: trade.orderId,
      ackType: "SELLER_ACK_SENT",
      offerId: trade.offerId ?? void 0,
      idempotencyKey: `ack:${trade.orderId}:SELLER_ACK_SENT`
    });
    button.textContent = response.ok ? "\u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430 \u2713" : response.error ?? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C";
    button.disabled = response.ok;
  }
  async function acknowledgeReceived(trade, button) {
    button.disabled = true;
    button.textContent = "\u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u043C\u2026";
    void bumpDealFlowMetric("received_ack_clicked");
    const response = await runtimeRequest({
      type: TRADE_VERIFICATION_RUNTIME.ACK_TRADE,
      orderId: trade.orderId,
      ackType: "BUYER_ACK_RECEIVED",
      offerId: trade.offerId ?? void 0,
      idempotencyKey: `ack:${trade.orderId}:BUYER_ACK_RECEIVED`
    });
    button.textContent = response.ok ? "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D \u2713" : response.error ?? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C";
    button.disabled = response.ok;
  }
  async function acknowledgePreAccept(trade, button) {
    if (trade.verificationStatus === "mismatch") {
      button.textContent = "\u041E\u0431\u043C\u0435\u043D \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442";
      return;
    }
    button.disabled = true;
    button.textContent = "\u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u043C\u2026";
    const response = await runtimeRequest({
      type: TRADE_VERIFICATION_RUNTIME.ACK_TRADE,
      orderId: trade.orderId,
      ackType: "BUYER_ACK_PRE_ACCEPT",
      offerId: trade.offerId ?? void 0,
      idempotencyKey: `ack:${trade.orderId}:BUYER_ACK_PRE_ACCEPT`
    });
    button.textContent = response.ok ? "\u0412\u0438\u0436\u0443 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u2713" : response.error ?? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C";
    button.disabled = response.ok;
  }
  function replacePanel(context) {
    lastPanelContext = context;
    document.getElementById(PANEL_ID)?.remove();
    document.documentElement.appendChild(buildPanel(context));
  }
  var refreshInFlight = false;
  var offerPanelContextInvalidated = false;
  var offerPanelObserver = null;
  async function refreshPanel() {
    if (refreshInFlight || offerPanelContextInvalidated) {
      return;
    }
    if (!isExtensionContextValid()) {
      offerPanelContextInvalidated = true;
      offerPanelObserver?.disconnect();
      document.getElementById(PANEL_ID)?.remove();
      return;
    }
    refreshInFlight = true;
    try {
      await ensureOverlayLocale();
      await refreshGuidedBuyerFlag();
      const context = await loadTradeForPage();
      if (!context) {
        document.getElementById(PANEL_ID)?.remove();
        return;
      }
      ensureStickyHint();
      replacePanel(context);
    } catch (error) {
      if (isExtensionContextInvalidatedError(error) || !isExtensionContextValid()) {
        offerPanelContextInvalidated = true;
        offerPanelObserver?.disconnect();
        document.getElementById(PANEL_ID)?.remove();
        return;
      }
      throw error;
    } finally {
      refreshInFlight = false;
    }
  }
  function watchTradeOfferDom() {
    const root = document.querySelector("#trade_slots") ?? document.querySelector(".tradeoffer") ?? document.body;
    offerPanelObserver?.disconnect();
    offerPanelObserver = new MutationObserver(() => {
      void refreshPanel();
    });
    offerPanelObserver.observe(root, { childList: true, subtree: true });
  }
  async function mountPanel() {
    if (/\/tradeoffers\/?/i.test(window.location.pathname)) {
      return;
    }
    try {
      await ensureOverlayLocale();
      await refreshGuidedBuyerFlag();
      const context = await loadTradeForPage();
      if (!context) {
        return;
      }
      ensureStickyHint();
      replacePanel(context);
      watchTradeOfferDom();
    } catch (error) {
      if (isExtensionContextInvalidatedError(error) || !isExtensionContextValid()) {
        offerPanelContextInvalidated = true;
        document.getElementById(PANEL_ID)?.remove();
        return;
      }
      console.warn("[rip-market] trade verification panel failed", error);
    }
  }
  void mountPanel();
})();
//# sourceMappingURL=trade-verification-bridge.js.map
