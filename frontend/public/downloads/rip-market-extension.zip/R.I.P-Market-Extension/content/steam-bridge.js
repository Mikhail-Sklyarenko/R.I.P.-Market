"use strict";
(() => {
  // src/shared/trade-offer-messages.ts
  var TRADE_OFFER_BRIDGE_SOURCE = "rip-market-trade-offer-bridge";
  var TRADE_OFFER_PAGE_SOURCE = "rip-market-trade-offer-page";
  var STEAM_BRIDGE_MESSAGE = {
    RUN_AUTOFILL_FLOW: "RUN_AUTOFILL_FLOW"
  };

  // ../extension/src/steam-offer-id.util.ts
  var STEAM_OFFER_ID_PATTERN = /^\d{6,20}$/;
  function isValidSteamOfferId(offerId) {
    return STEAM_OFFER_ID_PATTERN.test(offerId.trim());
  }
  function normalizeSteamOfferId(offerId) {
    if (offerId === null || offerId === void 0) {
      return null;
    }
    const normalized = String(offerId).trim();
    return isValidSteamOfferId(normalized) ? normalized : null;
  }

  // src/shared/trade-offer-sent-cache.ts
  var TRADE_OFFER_INTERCEPTED_MESSAGE = "TRADE_OFFER_INTERCEPTED";
  function sentOfferStorageKey(draftId) {
    return `rip:sent-offer:${draftId}`;
  }
  function interceptedOfferStorageKey(assetId) {
    return `rip:intercepted-offer:${assetId}`;
  }
  function sendInflightStorageKey(draftId) {
    return `rip:send-inflight:${draftId}`;
  }
  async function removeStorageKeys(area, keys) {
    if (keys.length === 0) {
      return;
    }
    await chrome.storage[area].remove(keys);
  }
  async function recordInterceptedOffer(params) {
    const offerId = normalizeSteamOfferId(params.offerId);
    if (!offerId) {
      return null;
    }
    const entry = {
      offerId,
      confirmPending: Boolean(params.confirmPending),
      assetId: params.assetId,
      buyerTradeUrl: params.buyerTradeUrl,
      capturedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const patch = {
      "rip:last-intercepted-offer": entry
    };
    if (params.assetId) {
      patch[interceptedOfferStorageKey(params.assetId)] = entry;
    }
    const cached = {
      ok: true,
      offerId,
      confirmPending: entry.confirmPending,
      assetId: params.assetId,
      marketHashName: null,
      floatValue: null
    };
    if (params.draftId) {
      patch[sentOfferStorageKey(params.draftId)] = cached;
    }
    await chrome.storage.local.set(patch);
    await chrome.storage.session.set(patch);
    if (params.draftId) {
      await clearSendInflight(params.draftId);
    }
    return cached;
  }
  async function clearSendInflight(draftId) {
    const key = sendInflightStorageKey(draftId);
    await removeStorageKeys("session", [key]);
    await removeStorageKeys("local", [key]);
  }

  // src/content/trade-offer-content-bridge.ts
  var PAGE_SCRIPT_PATH = "page-scripts/trade-offer-ui.js";
  var PAGE_SCRIPT_READY_ATTR = "data-rip-market-trade-offer-ui";
  var pageScriptInjection = null;
  async function waitForPageScriptReady(timeoutMs = 15e3) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (document.documentElement.getAttribute(PAGE_SCRIPT_READY_ATTR) === "ready") {
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    throw new Error("Page script not ready");
  }
  function injectPageScript() {
    if (pageScriptInjection) {
      return pageScriptInjection;
    }
    if (document.documentElement.getAttribute(PAGE_SCRIPT_READY_ATTR) === "ready") {
      return Promise.resolve();
    }
    pageScriptInjection = new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL(PAGE_SCRIPT_PATH);
      script.onload = () => {
        void waitForPageScriptReady().then(resolve).catch(reject).finally(() => {
          pageScriptInjection = null;
        });
      };
      script.onerror = () => {
        pageScriptInjection = null;
        reject(new Error("Failed to load trade page script"));
      };
      document.documentElement.appendChild(script);
    });
    return pageScriptInjection;
  }
  function notifyInterceptedOffer(payload, result) {
    if (!result.ok || !result.offerId) {
      return;
    }
    void chrome.runtime.sendMessage({
      type: TRADE_OFFER_INTERCEPTED_MESSAGE,
      offerId: result.offerId,
      confirmPending: result.confirmPending,
      assetId: payload.item.assetId,
      buyerTradeUrl: payload.buyerTradeUrl
    }).catch(() => {
    });
    void recordInterceptedOffer({
      offerId: result.offerId,
      confirmPending: result.confirmPending,
      assetId: payload.item.assetId,
      buyerTradeUrl: payload.buyerTradeUrl
    });
  }
  function runAutofillViaPageScript(payload, timeoutMs = 45e3) {
    return new Promise((resolve) => {
      const requestId = crypto.randomUUID();
      const timeout = window.setTimeout(() => {
        window.removeEventListener("message", onPageMessage);
        resolve({
          ok: false,
          message: "Page script autofill timed out"
        });
      }, timeoutMs);
      function onPageMessage(event) {
        if (event.source !== window) {
          return;
        }
        const data = event.data;
        if (!data || data.source !== TRADE_OFFER_PAGE_SOURCE || data.requestId !== requestId) {
          return;
        }
        window.clearTimeout(timeout);
        window.removeEventListener("message", onPageMessage);
        if (data.result.ok) {
          notifyInterceptedOffer(payload, data.result);
        }
        resolve({ ok: true, data: data.result });
      }
      window.addEventListener("message", onPageMessage);
      window.postMessage(
        {
          source: TRADE_OFFER_BRIDGE_SOURCE,
          type: STEAM_BRIDGE_MESSAGE.RUN_AUTOFILL_FLOW,
          requestId,
          payload
        },
        "*"
      );
    });
  }
  async function handleSteamBridgeRuntimeMessage(message) {
    if (message.type === STEAM_BRIDGE_MESSAGE.RUN_AUTOFILL_FLOW) {
      await injectPageScript();
      return runAutofillViaPageScript(message.payload);
    }
    return { ok: false, message: "Unknown command" };
  }
  if (window.location.pathname.includes("/tradeoffer/")) {
    void injectPageScript().catch(() => void 0);
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== "https://steamcommunity.com")
      return;
    const message = event.data;
    if (message?.source !== TRADE_OFFER_PAGE_SOURCE || message.type !== "SEND_RESULT" || typeof message.draftId !== "string" || !message.result?.ok)
      return;
    void (async () => {
      const stored = await chrome.storage.local.get(
        `rip:draft:${message.draftId}`
      );
      const draft = stored[`rip:draft:${message.draftId}`];
      if (!draft || draft.item.assetId !== message.assetId || draft.buyerTradeUrl !== message.buyerTradeUrl)
        return;
      await recordInterceptedOffer({
        draftId: message.draftId,
        assetId: draft.item.assetId,
        buyerTradeUrl: draft.buyerTradeUrl,
        offerId: message.result.offerId,
        confirmPending: message.result.confirmPending
      });
    })().catch(() => void 0);
  });

  // src/content/steam-bridge.ts
  var CS2_APP_ID = 730;
  var CS2_CONTEXT = 2;
  var OfferErrorCode2 = {
    ITEM_MISSING: "ITEM_MISSING",
    OFFER_DRAFT_FAILED: "OFFER_DRAFT_FAILED",
    STEAM_UNAVAILABLE: "STEAM_UNAVAILABLE"
  };
  var draftStore = /* @__PURE__ */ new Map();
  function getSessionId() {
    const match = document.cookie.match(/sessionid=([^;]+)/);
    return match?.[1] ?? null;
  }
  function getSteamIdFromPage() {
    const win = window;
    const candidates = [
      win.g_steamID,
      win.g_ActiveUser?.steamid,
      win.g_rgWalletInfo?.steamid
    ];
    for (const candidate of candidates) {
      if (typeof candidate === "string" && /^\d{17}$/.test(candidate)) {
        return candidate;
      }
    }
    const profileMatch = window.location.href.match(/profiles\/(\d{17})/);
    if (profileMatch) {
      return profileMatch[1];
    }
    const miniProfile = document.querySelector("[data-miniprofile]");
    const miniProfileId = miniProfile?.getAttribute("data-miniprofile");
    if (miniProfileId && /^\d{17}$/.test(miniProfileId)) {
      return miniProfileId;
    }
    return null;
  }
  async function resolveSteamId() {
    const fromPage = getSteamIdFromPage();
    if (fromPage) {
      return fromPage;
    }
    try {
      const response = await fetch("https://steamcommunity.com/my/profile/", {
        credentials: "include",
        redirect: "follow"
      });
      const profileMatch = response.url.match(/profiles\/(\d{17})/);
      if (profileMatch) {
        return profileMatch[1];
      }
    } catch {
    }
    return null;
  }
  function parseTradeUrl(tradeUrl) {
    try {
      const url = new URL(tradeUrl);
      const partner = url.searchParams.get("partner");
      const token = url.searchParams.get("token");
      if (!partner || !token) {
        return null;
      }
      return { partner, token };
    } catch {
      return null;
    }
  }
  function parseInventoryBody(body) {
    if (body.success === 0) {
      throw new Error(body.error ?? "Steam inventory unavailable");
    }
    const descriptions = /* @__PURE__ */ new Map();
    for (const description of body.descriptions ?? []) {
      descriptions.set(`${description.classid}_${description.instanceid}`, {
        marketHashName: description.market_hash_name,
        tradable: description.tradable
      });
    }
    return (body.assets ?? []).map((asset) => {
      const meta = descriptions.get(`${asset.classid}_${asset.instanceid}`);
      return {
        assetId: asset.assetid,
        classId: asset.classid,
        instanceId: asset.instanceid,
        marketHashName: meta?.marketHashName
      };
    });
  }
  async function fetchInventory(steamId) {
    const merged = /* @__PURE__ */ new Map();
    let startAssetId;
    for (let page = 0; page < 20; page += 1) {
      const url = new URL(
        `https://steamcommunity.com/inventory/${steamId}/${CS2_APP_ID}/${CS2_CONTEXT}`
      );
      url.searchParams.set("l", "english");
      url.searchParams.set("count", "500");
      if (startAssetId) {
        url.searchParams.set("start_assetid", startAssetId);
      }
      const response = await fetch(url.toString(), { credentials: "include" });
      if (!response.ok) {
        throw new Error(`Inventory HTTP ${response.status}`);
      }
      const body = await response.json();
      for (const item of parseInventoryBody(body)) {
        merged.set(String(item.assetId), { ...item, assetId: String(item.assetId) });
      }
      if (!body.more_items || !body.last_assetid) {
        break;
      }
      startAssetId = body.last_assetid;
    }
    return [...merged.values()];
  }
  async function loadInventory() {
    const steamId = await resolveSteamId();
    if (!steamId) {
      throw new Error("Steam ID not found \u2014 log in at steamcommunity.com");
    }
    return fetchInventory(steamId);
  }
  async function sendTradeOffer(draft) {
    const sessionid = getSessionId();
    if (!sessionid) {
      throw new Error("Steam session missing");
    }
    const tradeParams = parseTradeUrl(draft.buyerTradeUrl);
    if (!tradeParams) {
      throw new Error("Invalid buyer trade URL");
    }
    const tradeOffer = {
      newversion: true,
      version: 2,
      me: {
        assets: [
          {
            appid: CS2_APP_ID,
            contextid: String(CS2_CONTEXT),
            amount: 1,
            assetid: draft.item.assetId
          }
        ],
        currency: [],
        ready: false
      },
      them: { assets: [], currency: [], ready: false }
    };
    const form = new URLSearchParams();
    form.set("sessionid", sessionid);
    form.set("serverid", "1");
    form.set("partner", tradeParams.partner);
    form.set("tradeoffermessage", "R.I.P Market trade");
    form.set("json_tradeoffer", JSON.stringify(tradeOffer));
    form.set(
      "trade_offer_create_params",
      JSON.stringify({ trade_offer_access_token: tradeParams.token })
    );
    const response = await fetch("https://steamcommunity.com/tradeoffer/new/send", {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
      },
      body: form.toString()
    });
    const text = await response.text();
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new Error("Steam returned invalid response");
    }
    if (!parsed.tradeofferid) {
      const errorText = parsed.strError ?? text.slice(0, 200);
      if (/confirm/i.test(errorText)) {
        return { offerId: "pending-confirm", confirmPending: true };
      }
      throw new Error(errorText || "Offer send failed");
    }
    return {
      offerId: String(parsed.tradeofferid),
      confirmPending: Boolean(parsed.needs_mobile_confirmation)
    };
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    void (async () => {
      try {
        if (message.type === "RUN_AUTOFILL_FLOW") {
          const response = await handleSteamBridgeRuntimeMessage(message);
          sendResponse(response);
          return;
        }
        if (message.type === "STEAM_LOAD_INVENTORY") {
          const inventory = await loadInventory();
          sendResponse({ ok: true, data: inventory });
          return;
        }
        if (message.type === "STEAM_DRAFT_OFFER") {
          const payload = message.payload;
          const inventory = await loadInventory();
          const item = inventory.find(
            (entry) => String(entry.assetId) === String(payload.item.assetId)
          );
          if (!item) {
            sendResponse({
              ok: false,
              code: OfferErrorCode2.ITEM_MISSING,
              message: "Item not in inventory"
            });
            return;
          }
          const draftId = `draft-${item.assetId}`;
          draftStore.set(draftId, {
            buyerTradeUrl: payload.buyerTradeUrl,
            item
          });
          sendResponse({ ok: true, data: { draftId } });
          return;
        }
        if (message.type === "STEAM_SEND_OFFER") {
          const draftId = String(message.payload.draftId);
          const draft = draftStore.get(draftId);
          if (!draft) {
            sendResponse({
              ok: false,
              code: OfferErrorCode2.OFFER_DRAFT_FAILED,
              message: "Draft not found"
            });
            return;
          }
          const result = await sendTradeOffer(draft);
          draftStore.delete(draftId);
          sendResponse({ ok: true, data: result });
          return;
        }
        sendResponse({ ok: false, code: OfferErrorCode2.STEAM_UNAVAILABLE, message: "Unknown command" });
      } catch (error) {
        sendResponse({
          ok: false,
          code: OfferErrorCode2.STEAM_UNAVAILABLE,
          message: error instanceof Error ? error.message : "Steam error"
        });
      }
    })();
    return true;
  });
})();
//# sourceMappingURL=steam-bridge.js.map
