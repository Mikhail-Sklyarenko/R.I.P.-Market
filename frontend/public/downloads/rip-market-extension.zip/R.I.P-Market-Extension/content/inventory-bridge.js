"use strict";
(() => {
  // src/shared/inventory-price-intel.ts
  var STEAM_LIST_DISCOUNT = 0.95;
  var PLATFORM_COMMISSION_RATE = 0.05;
  function calculateCommissionMinor(priceMinor) {
    return Math.floor(priceMinor * PLATFORM_COMMISSION_RATE);
  }
  function calculateSellerReceiveMinor(priceMinor) {
    return priceMinor - calculateCommissionMinor(priceMinor);
  }
  function getRecommendedListPriceMinor(hint) {
    const steam = hint?.steamPriceMinor;
    if (!steam || steam <= 0) {
      return null;
    }
    return Math.round(steam * STEAM_LIST_DISCOUNT);
  }
  function parseMinor(value) {
    if (value == null || value === "") {
      return null;
    }
    const numeric = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(numeric) || numeric <= 0) {
      return null;
    }
    return Math.round(numeric);
  }
  function formatUsdFromMinor(minor) {
    return `$${(minor / 100).toFixed(2)}`;
  }
  function getDefaultListPriceMinor(hint) {
    const serverSuggested = parseMinor(hint?.suggestedListMinor);
    if (serverSuggested != null) {
      return serverSuggested;
    }
    const bid = parseMinor(hint?.bestBidMinor);
    if (bid != null) {
      return bid;
    }
    return getRecommendedListPriceMinor(hint);
  }
  function resolveInventoryPriceIntel(params) {
    const steamGuideMinor = parseMinor(params.hint?.steamPriceMinor);
    const ripMinAskMinor = parseMinor(params.hint?.minMarketplacePriceMinor);
    const listedMinor = parseMinor(params.listedPriceMinor);
    const bestBidMinor = parseMinor(params.hint?.bestBidMinor);
    const bestBidQuantity = params.hint?.bestBidQuantity != null && Number.isFinite(params.hint.bestBidQuantity) && params.hint.bestBidQuantity > 0 ? Math.floor(params.hint.bestBidQuantity) : bestBidMinor != null ? 1 : null;
    const recommendedListMinor = getRecommendedListPriceMinor(params.hint);
    const defaultListMinor = getDefaultListPriceMinor(params.hint);
    const listMinor = listedMinor ?? defaultListMinor;
    const sellerReceiveMinor = listMinor != null ? calculateSellerReceiveMinor(listMinor) : null;
    let primaryLine = null;
    let compactPrimaryLine = null;
    if (listedMinor != null) {
      primaryLine = `R.I.P ${formatUsdFromMinor(listedMinor)}`;
      compactPrimaryLine = formatUsdFromMinor(listedMinor);
    } else if (bestBidMinor != null) {
      primaryLine = `Bid ${formatUsdFromMinor(bestBidMinor)}`;
      compactPrimaryLine = `Bid ${formatUsdFromMinor(bestBidMinor)}`;
    } else if (recommendedListMinor != null) {
      primaryLine = `R.I.P ~${formatUsdFromMinor(recommendedListMinor)}`;
      compactPrimaryLine = `~${formatUsdFromMinor(recommendedListMinor)}`;
    } else if (ripMinAskMinor != null) {
      primaryLine = `R.I.P \u043E\u0442 ${formatUsdFromMinor(ripMinAskMinor)}`;
      compactPrimaryLine = `\u043E\u0442 ${formatUsdFromMinor(ripMinAskMinor)}`;
    }
    const secondaryParts = [];
    if (steamGuideMinor != null) {
      secondaryParts.push(`Steam ${formatUsdFromMinor(steamGuideMinor)}`);
    }
    if (ripMinAskMinor != null && (listedMinor != null || recommendedListMinor != null || bestBidMinor != null)) {
      secondaryParts.push(`\u043D\u0430 R.I.P \u043E\u0442 ${formatUsdFromMinor(ripMinAskMinor)}`);
    }
    const secondaryLine = secondaryParts.length > 0 ? secondaryParts.join(" \xB7 ") : null;
    const netLine = sellerReceiveMinor != null ? `\u0432\u0430\u043C ~${formatUsdFromMinor(sellerReceiveMinor)}` : null;
    const bidLine = listedMinor == null && bestBidMinor != null ? bestBidQuantity != null && bestBidQuantity > 1 ? `bid ${formatUsdFromMinor(bestBidMinor)} \xB7 \xD7${bestBidQuantity}` : `bid ${formatUsdFromMinor(bestBidMinor)}` : null;
    return {
      recommendedListMinor,
      ripMinAskMinor,
      steamGuideMinor,
      bestBidMinor,
      bestBidQuantity,
      sellerReceiveMinor,
      primaryLine,
      compactPrimaryLine,
      secondaryLine,
      netLine,
      bidLine
    };
  }

  // src/shared/inventory-item-enrichment.ts
  var WEAR_SUFFIX_MAP = {
    "factory new": "FN",
    "minimal wear": "MW",
    "field-tested": "FT",
    "well-worn": "WW",
    "battle-scarred": "BS"
  };
  function parseWearFromMarketHashName(marketHashName) {
    if (!marketHashName) {
      return null;
    }
    const match = marketHashName.match(/\(([^)]+)\)\s*$/);
    if (!match?.[1]) {
      return null;
    }
    return WEAR_SUFFIX_MAP[match[1].toLowerCase()] ?? match[1];
  }
  function parseFloatNumber(value) {
    if (value == null || value === "") {
      return null;
    }
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric < 0 || numeric > 1) {
      return null;
    }
    return numeric;
  }
  function formatFloatDisplay(value) {
    const fixed = value.toFixed(8);
    return fixed.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, ".0");
  }
  function wearPointerPercent(value) {
    return Math.min(100, Math.max(0, value * 100));
  }
  function formatTradeLockLabel(tradeLockUntil, nowMs = Date.now()) {
    if (!tradeLockUntil) {
      return null;
    }
    const until = Date.parse(tradeLockUntil);
    if (!Number.isFinite(until)) {
      return null;
    }
    if (until <= nowMs) {
      return null;
    }
    const remainingMs = until - nowMs;
    const days = Math.ceil(remainingMs / 864e5);
    if (days <= 1) {
      const hours = Math.max(1, Math.ceil(remainingMs / 36e5));
      return `Hold \xB7 ${hours} \u0447`;
    }
    return `Hold \xB7 ${days} \u0434\u043D`;
  }
  function formatMoneyMinor(amountMinor) {
    if (!amountMinor) {
      return null;
    }
    const value = Number(amountMinor) / 100;
    if (!Number.isFinite(value)) {
      return null;
    }
    return `$${value.toFixed(2)}`;
  }
  function resolveInventoryBadges(params) {
    const badges = [];
    const platform = params.platform;
    const lockLabel = formatTradeLockLabel(
      params.steam.tradeLockUntil,
      params.nowMs
    );
    if (platform?.listed) {
      const price = formatMoneyMinor(platform.listedPriceMinor);
      badges.push({
        kind: "listed",
        label: price ? `\u041D\u0430 R.I.P ${price}` : "\u041D\u0430 R.I.P",
        tone: "accent"
      });
    }
    if (platform?.inActiveDeal) {
      badges.push({
        kind: "in_deal",
        label: "\u0412 \u0441\u0434\u0435\u043B\u043A\u0435",
        tone: "warn"
      });
    } else if (platform?.hasActiveTradeTask) {
      badges.push({
        kind: "in_deal",
        label: "\u041E\u0431\u043C\u0435\u043D \u0438\u0434\u0451\u0442",
        tone: "warn"
      });
    }
    if (lockLabel) {
      badges.push({
        kind: "trade_locked",
        label: lockLabel,
        tone: "warn"
      });
    } else if (!params.steam.tradable) {
      badges.push({
        kind: "not_tradable",
        label: "\u041D\u0435\u043B\u044C\u0437\u044F \u043E\u0431\u043C\u0435\u043D\u044F\u0442\u044C",
        tone: "muted"
      });
    }
    if (!params.steam.marketable && !lockLabel) {
      badges.push({
        kind: "marketable",
        label: "\u041D\u0435\u043B\u044C\u0437\u044F \u043D\u0430 Steam Market",
        tone: "muted"
      });
    }
    return badges;
  }
  function buildInventoryItemEnrichmentView(params) {
    const floatNum = parseFloatNumber(params.steam.floatValue);
    const wearCode = params.steam.wear ?? parseWearFromMarketHashName(params.steam.marketHashName);
    const badges = resolveInventoryBadges({
      steam: params.steam,
      platform: params.platform,
      nowMs: params.nowMs
    });
    const floatDisplay = floatNum !== null ? formatFloatDisplay(floatNum) : null;
    const paintSeedDisplay = params.steam.paintSeed != null && Number.isFinite(params.steam.paintSeed) ? `seed ${params.steam.paintSeed}` : null;
    const metaParts = [
      floatDisplay,
      wearCode,
      paintSeedDisplay
    ].filter(Boolean);
    const price = resolveInventoryPriceIntel({
      hint: params.priceHint,
      listedPriceMinor: params.platform?.listedPriceMinor
    });
    return {
      assetId: params.steam.assetId,
      floatDisplay,
      wearCode,
      paintSeedDisplay,
      wearPointerPercent: floatNum !== null ? wearPointerPercent(floatNum) : null,
      tradeLockLabel: formatTradeLockLabel(
        params.steam.tradeLockUntil,
        params.nowMs
      ),
      badges,
      metaLine: metaParts.length > 0 ? metaParts.join(" \xB7 ") : null,
      pricePrimary: price.primaryLine,
      priceCompact: price.compactPrimaryLine,
      priceSecondary: price.secondaryLine,
      priceNet: price.netLine,
      priceBid: price.bidLine
    };
  }
  var CS2_INVENTORY_APP_ID = 730;
  var CS2_TRADE_PROTECTED_CONTEXT_ID = 16;
  var CS2_INVENTORY_ITEM_SELECTOR = '.item[id^="item730_"], .item[id^="730_"]';
  function parseCs2InventoryItemElementId(elementId) {
    if (!elementId) {
      return null;
    }
    const legacy = elementId.match(/^item(730)_(\d+)_(\d+)$/i);
    if (legacy?.[2] && legacy[3]) {
      return {
        appId: CS2_INVENTORY_APP_ID,
        contextId: Number(legacy[2]),
        assetId: legacy[3]
      };
    }
    const modern = elementId.match(/^(730)_(\d+)_(\d+)$/i);
    if (modern?.[2] && modern[3]) {
      return {
        appId: CS2_INVENTORY_APP_ID,
        contextId: Number(modern[2]),
        assetId: modern[3]
      };
    }
    return null;
  }
  function parseAssetIdFromItemElementId(elementId) {
    return parseCs2InventoryItemElementId(elementId)?.assetId ?? null;
  }
  function isTradeProtectedCs2Context(contextId) {
    return contextId === CS2_TRADE_PROTECTED_CONTEXT_ID;
  }
  function queryCs2InventoryItemByAssetId(root, assetId) {
    const trimmed = assetId.trim();
    if (!trimmed) {
      return null;
    }
    return root.querySelector(
      `.item[id="item730_2_${trimmed}"], .item[id="item730_16_${trimmed}"], .item[id="730_2_${trimmed}"], .item[id="730_16_${trimmed}"]`
    );
  }
  function readSteamIdFromDocumentHtml(html) {
    const patterns = [
      /g_steamID\s*=\s*"(\d{17})"/,
      /"steamid"\s*:\s*"(\d{17})"/,
      /UserYou\.SetSteamId\(\s*"(\d{17})"\s*\)/
    ];
    for (const pattern of patterns) {
      const match = html.match(pattern);
      if (match?.[1]) {
        return match[1];
      }
    }
    return null;
  }
  function delayMs(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function waitForSteamIdInDocument(params) {
    const timeoutMs = params.timeoutMs ?? 2500;
    const intervalMs = params.intervalMs ?? 100;
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const id = readSteamIdFromDocumentHtml(params.getHtml());
      if (id) {
        return id;
      }
      await delayMs(intervalMs);
    }
    return readSteamIdFromDocumentHtml(params.getHtml());
  }
  async function resolveInventoryPageSteamId(params) {
    const fromPath = params.pathname.match(/\/profiles\/(\d{17})/);
    if (fromPath?.[1]) {
      return fromPath[1];
    }
    const immediate = readSteamIdFromDocumentHtml(params.getHtml());
    if (immediate) {
      return immediate;
    }
    const waited = await waitForSteamIdInDocument({
      getHtml: params.getHtml,
      timeoutMs: params.waitTimeoutMs ?? 2500,
      intervalMs: params.waitIntervalMs ?? 100
    });
    if (waited) {
      return waited;
    }
    const fetchImpl = params.fetchImpl ?? fetch;
    try {
      const response = await fetchImpl("https://steamcommunity.com/my/profile/", {
        credentials: "include",
        redirect: "follow"
      });
      return response.url.match(/profiles\/(\d{17})/)?.[1] ?? null;
    } catch {
      return null;
    }
  }

  // src/shared/steam-inventory-loader.ts
  var CS2_APP_ID = 730;
  var CS2_CONTEXT = 2;
  function buildInventoryUrl(steamId, startAssetId) {
    const url = new URL(
      `https://steamcommunity.com/inventory/${steamId}/${CS2_APP_ID}/${CS2_CONTEXT}`
    );
    url.searchParams.set("l", "english");
    url.searchParams.set("count", "500");
    if (startAssetId) {
      url.searchParams.set("start_assetid", startAssetId);
    }
    return url.toString();
  }

  // src/shared/rate-limit-backoff.ts
  var RATE_LIMIT_BASE_BACKOFF_MS = 3e4;
  var RATE_LIMIT_MAX_BACKOFF_MS = 5 * 6e4;
  function defaultRateLimitBackoffState() {
    return {
      consecutiveHits: 0,
      blockedUntilMs: null,
      lastHitAtMs: null
    };
  }
  function parseRetryAfterMs(headerValue, nowMs = Date.now()) {
    const raw = headerValue?.trim();
    if (!raw) {
      return null;
    }
    if (/^\d+$/.test(raw)) {
      return Math.max(0, Number(raw) * 1e3);
    }
    const asDate = Date.parse(raw);
    if (Number.isFinite(asDate)) {
      return Math.max(0, asDate - nowMs);
    }
    return null;
  }
  function computeRateLimitBackoffMs(consecutiveHits, retryAfterMs) {
    if (retryAfterMs != null && retryAfterMs > 0) {
      return Math.min(RATE_LIMIT_MAX_BACKOFF_MS, retryAfterMs);
    }
    const hits = Math.max(1, consecutiveHits);
    const exp = Math.min(
      RATE_LIMIT_MAX_BACKOFF_MS,
      RATE_LIMIT_BASE_BACKOFF_MS * 2 ** (hits - 1)
    );
    return exp;
  }
  function markRateLimitHit(state, opts) {
    const nowMs = opts?.nowMs ?? Date.now();
    const consecutiveHits = Math.max(0, state.consecutiveHits) + 1;
    const backoffMs = computeRateLimitBackoffMs(
      consecutiveHits,
      opts?.retryAfterMs
    );
    return {
      consecutiveHits,
      lastHitAtMs: nowMs,
      blockedUntilMs: nowMs + backoffMs
    };
  }
  function isRateLimitBlocked(state, nowMs = Date.now()) {
    return state.blockedUntilMs != null && Number.isFinite(state.blockedUntilMs) && state.blockedUntilMs > nowMs;
  }
  function resolveFetchRetryDelayMs(params) {
    const { attempt, baseDelayMs, response, nowMs = Date.now() } = params;
    if (response?.status === 429) {
      const retryAfter = parseRetryAfterMs(
        response.headers?.get("retry-after") ?? null,
        nowMs
      );
      if (retryAfter != null) {
        return Math.min(RATE_LIMIT_MAX_BACKOFF_MS, Math.max(baseDelayMs, retryAfter));
      }
    }
    const exp = baseDelayMs * 2 ** Math.max(0, attempt - 1);
    const jitter = Math.floor(exp * 0.1 * Math.random());
    return Math.min(RATE_LIMIT_MAX_BACKOFF_MS, exp + jitter);
  }

  // src/shared/steam-fetch-retry.ts
  var RETRYABLE_STATUSES = /* @__PURE__ */ new Set([429, 500, 502, 503, 504]);
  var DEFAULT_ATTEMPTS = 3;
  var BASE_DELAY_MS = 800;
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function fetchWithRetry(fetchFn, options) {
    const attempts = options?.attempts ?? DEFAULT_ATTEMPTS;
    const baseDelayMs = options?.baseDelayMs ?? BASE_DELAY_MS;
    let lastError = null;
    let lastResponse = null;
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      try {
        const response = await fetchFn();
        lastResponse = response;
        if (response.ok || !RETRYABLE_STATUSES.has(response.status)) {
          return response;
        }
        lastError = new Error(`Inventory HTTP ${response.status}`);
      } catch (error) {
        lastError = error instanceof Error ? error : new Error("Inventory fetch failed");
        lastResponse = null;
      }
      if (attempt < attempts) {
        await delay(
          resolveFetchRetryDelayMs({
            attempt,
            baseDelayMs,
            response: lastResponse ?? void 0
          })
        );
      }
    }
    throw lastError ?? new Error("Inventory fetch failed");
  }

  // src/shared/inventory-enrichment-data.ts
  function readPaintSeed(assetId, assetProperties) {
    const entry = assetProperties?.find((item) => String(item.assetid) === assetId);
    const seedProp = entry?.asset_properties?.find((prop) => prop.propertyid === 2);
    if (!seedProp?.int_value) {
      return null;
    }
    const seed = Number(seedProp.int_value);
    return Number.isFinite(seed) ? seed : null;
  }
  function readFloatValue(assetId, assetProperties) {
    const entry = assetProperties?.find((item) => String(item.assetid) === assetId);
    const floatProp = entry?.asset_properties?.find((prop) => prop.propertyid === 1);
    return floatProp?.float_value ?? null;
  }
  function parseInventoryEnrichmentPage(body) {
    if (body.success === 0 || body.success === 15) {
      return [];
    }
    const descriptions = /* @__PURE__ */ new Map();
    for (const description of body.descriptions ?? []) {
      descriptions.set(`${description.classid}_${description.instanceid}`, description);
    }
    return (body.assets ?? []).map((asset) => {
      const assetId = String(asset.assetid);
      const meta = descriptions.get(`${asset.classid}_${asset.instanceid}`);
      const marketHashName = meta?.market_hash_name ?? meta?.market_name ?? null;
      return {
        assetId,
        marketHashName,
        floatValue: readFloatValue(assetId, body.asset_properties),
        paintSeed: readPaintSeed(assetId, body.asset_properties),
        wear: parseWearFromMarketHashName(marketHashName),
        tradable: meta?.tradable === 1,
        marketable: meta?.marketable === void 0 ? meta?.tradable === 1 : meta.marketable === 1,
        tradeLockUntil: meta?.cache_expiration ?? null
      };
    });
  }
  async function fetchCs2InventoryEnrichmentFacts(steamId, fetchImpl = fetch) {
    if (!/^\d{17}$/.test(steamId)) {
      throw new Error("Invalid SteamID64 for inventory enrichment");
    }
    const merged = /* @__PURE__ */ new Map();
    let startAssetId;
    for (let page = 0; page < 20; page += 1) {
      const response = await fetchWithRetry(
        () => fetchImpl(buildInventoryUrl(steamId, startAssetId), {
          credentials: "include",
          headers: {
            Accept: "application/json",
            Referer: `https://steamcommunity.com/profiles/${steamId}/inventory/`
          }
        }),
        { attempts: 3, baseDelayMs: 900 }
      );
      if (!response.ok) {
        throw new Error(`Inventory HTTP ${response.status}`);
      }
      const body = await response.json();
      if (body.success === 15) {
        throw new Error("Steam inventory is private");
      }
      if (body.success === 0) {
        throw new Error(body.error?.trim() || "Steam inventory unavailable");
      }
      for (const item of parseInventoryEnrichmentPage(body)) {
        merged.set(item.assetId, item);
      }
      if (!body.more_items || !body.last_assetid) {
        break;
      }
      startAssetId = body.last_assetid;
    }
    return merged;
  }

  // src/shared/inventory-dom-facts.ts
  function createBaselineSteamFact(assetId, overrides) {
    const marketHashName = overrides?.marketHashName?.trim() ? overrides.marketHashName.trim() : null;
    return {
      assetId,
      marketHashName,
      floatValue: overrides?.floatValue ?? null,
      paintSeed: overrides?.paintSeed ?? null,
      wear: overrides?.wear ?? parseWearFromMarketHashName(marketHashName) ?? null,
      tradable: overrides?.tradable ?? true,
      marketable: overrides?.marketable ?? true,
      tradeLockUntil: overrides?.tradeLockUntil ?? null
    };
  }
  function mergeSteamFact(base, enrich) {
    const hasEnrichIdentity = Boolean(
      enrich.marketHashName?.trim() || enrich.floatValue != null || enrich.paintSeed != null || enrich.tradeLockUntil != null
    );
    const marketHashName = enrich.marketHashName?.trim() || base.marketHashName || null;
    return {
      assetId: base.assetId,
      marketHashName,
      floatValue: enrich.floatValue ?? base.floatValue,
      paintSeed: enrich.paintSeed ?? base.paintSeed,
      wear: enrich.wear ?? base.wear ?? parseWearFromMarketHashName(marketHashName) ?? null,
      tradable: hasEnrichIdentity ? enrich.tradable : base.tradable,
      marketable: hasEnrichIdentity ? enrich.marketable : base.marketable,
      tradeLockUntil: enrich.tradeLockUntil ?? base.tradeLockUntil
    };
  }
  function mergeSteamFactsMaps(...layers) {
    const out = /* @__PURE__ */ new Map();
    for (const layer of layers) {
      if (!layer) {
        continue;
      }
      for (const [assetId, fact] of layer) {
        const prev = out.get(assetId);
        out.set(assetId, prev ? mergeSteamFact(prev, fact) : fact);
      }
    }
    return out;
  }
  function readMarketHashHintFromItemElement(item) {
    const titled = item.getAttribute("data-market-hash-name")?.trim() || item.getAttribute("data-hash-name")?.trim() || null;
    if (titled) {
      return titled;
    }
    const img = item.querySelector("img[title], img[alt]");
    const title = img?.getAttribute("title")?.trim() || img?.getAttribute("alt")?.trim();
    if (title && title.length > 2 && !/^https?:/i.test(title)) {
      return title;
    }
    return null;
  }
  function buildDomBaselineSteamFacts(root) {
    const map = /* @__PURE__ */ new Map();
    const items = root.querySelectorAll(CS2_INVENTORY_ITEM_SELECTOR);
    for (const item of Array.from(items)) {
      const parsed = parseCs2InventoryItemElementId(item.id);
      if (!parsed) {
        continue;
      }
      const marketHashName = readMarketHashHintFromItemElement(item);
      const tradeProtected = isTradeProtectedCs2Context(parsed.contextId);
      map.set(
        parsed.assetId,
        createBaselineSteamFact(parsed.assetId, {
          marketHashName,
          // Context 16 = Trade Protected — do not pretend tradable.
          tradable: !tradeProtected,
          marketable: !tradeProtected,
          tradeLockUntil: tradeProtected ? (
            // Soft signal until Steam enrichment supplies a real unlock time.
            new Date(Date.now() + 7 * 864e5).toISOString()
          ) : null
        })
      );
    }
    return map;
  }
  function applyPlatformNamesToSteamFacts(steamFacts, platformFacts) {
    const out = new Map(steamFacts);
    for (const [assetId, platform] of Object.entries(platformFacts)) {
      const name = platform.marketHashName?.trim();
      if (!name) {
        continue;
      }
      const existing = out.get(assetId);
      if (existing) {
        if (!existing.marketHashName) {
          out.set(
            assetId,
            mergeSteamFact(existing, {
              ...existing,
              marketHashName: name,
              wear: parseWearFromMarketHashName(name)
            })
          );
        }
        continue;
      }
      out.set(
        assetId,
        createBaselineSteamFact(assetId, { marketHashName: name })
      );
    }
    return out;
  }

  // src/shared/steam-inventory-page-enrichment.ts
  function inventoryItemSteamFactsToMap(facts) {
    const map = /* @__PURE__ */ new Map();
    for (const fact of facts) {
      map.set(fact.assetId, fact);
    }
    return map;
  }

  // src/shared/trade-verification-runtime.ts
  var TRADE_VERIFICATION_RUNTIME = {
    GET_ACTIVE_TRADES: "RIP_MARKET_GET_ACTIVE_TRADES",
    VERIFY_TRADE: "RIP_MARKET_VERIFY_TRADE",
    ACK_TRADE: "RIP_MARKET_ACK_TRADE",
    REFRESH_ACTIVE_TRADES: "RIP_MARKET_REFRESH_ACTIVE_TRADES",
    REPORT_STEAM_OFFER_PAGE: "RIP_MARKET_REPORT_STEAM_OFFER_PAGE",
    RESOLVE_ASSET_FLOAT: "RIP_MARKET_RESOLVE_ASSET_FLOAT",
    GET_INVENTORY_PLATFORM_STATUS: "RIP_MARKET_GET_INVENTORY_PLATFORM_STATUS",
    GET_INVENTORY_PRICE_HINTS: "RIP_MARKET_GET_INVENTORY_PRICE_HINTS",
    /** Load CS2 enrichment facts from the Steam inventory tab MAIN world. */
    GET_INVENTORY_PAGE_FACTS: "RIP_MARKET_GET_INVENTORY_PAGE_FACTS",
    BROWSER_ASSIST_INVENTORY_SYNC: "RIP_MARKET_BROWSER_ASSIST_INVENTORY_SYNC",
    CREATE_INVENTORY_LOT: "RIP_MARKET_CREATE_INVENTORY_LOT",
    CREATE_INVENTORY_LOTS_BATCH: "RIP_MARKET_CREATE_INVENTORY_LOTS_BATCH",
    UPDATE_INVENTORY_LOT_PRICE: "RIP_MARKET_UPDATE_INVENTORY_LOT_PRICE",
    CANCEL_INVENTORY_LOT: "RIP_MARKET_CANCEL_INVENTORY_LOT",
    GET_SELLER_ONBOARDING_STATUS: "RIP_MARKET_GET_SELLER_ONBOARDING_STATUS",
    MANUAL_CREATE_OFFER: "RIP_MARKET_MANUAL_CREATE_OFFER"
  };

  // src/shared/inventory-prelist-safety.ts
  var NON_LISTABLE_NAME_RE = /(?:Service Medal|Veteran Coin|Birthday Coin|Global Offensive Badge|Loyalty Badge|Premier Season|Operation Coin|Ten Year Veteran)/i;
  var PRELIST_SOFT_GATE_MESSAGE = "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 (Account \u2192 \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C) \u2014 \u0438\u043D\u0430\u0447\u0435 \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u0440\u0435\u0434\u043C\u0435\u0442 \u043D\u0435\u043B\u044C\u0437\u044F.";
  var PRELIST_SITE_OFFLINE_MESSAGE = "\u0421\u0430\u0439\u0442 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0438\u043B\u0438 \u0441\u0432\u044F\u0437\u044C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430 \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u0430 (\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C).";
  function isListableMarketHashName(marketHashName) {
    const normalized = marketHashName?.trim() ?? "";
    if (!normalized) {
      return false;
    }
    return !NON_LISTABLE_NAME_RE.test(normalized);
  }
  function isTradeLocked(tradeLockUntil, nowMs = Date.now()) {
    if (!tradeLockUntil) {
      return false;
    }
    const until = Date.parse(tradeLockUntil);
    return Number.isFinite(until) && until > nowMs;
  }
  function evaluatePrelistSafety(params) {
    if (!params.connected) {
      return {
        canList: false,
        softGate: true,
        reason: "disconnected",
        label: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
        message: PRELIST_SOFT_GATE_MESSAGE,
        orderUrl: null
      };
    }
    if (params.siteSafeMode) {
      return {
        canList: false,
        softGate: true,
        reason: "site_offline",
        label: "\u0421\u0430\u0439\u0442 offline",
        message: PRELIST_SITE_OFFLINE_MESSAGE,
        orderUrl: null
      };
    }
    const platform = params.platform;
    if (platform?.hasActiveTradeTask) {
      return {
        canList: false,
        softGate: false,
        reason: "active_trade_task",
        label: "\u041E\u0431\u043C\u0435\u043D \u0438\u0434\u0451\u0442",
        message: "\u041F\u043E \u044D\u0442\u043E\u043C\u0443 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u0443 \u0443\u0436\u0435 \u0438\u0434\u0451\u0442 \u0437\u0430\u0434\u0430\u0447\u0430 \u043E\u0431\u043C\u0435\u043D\u0430 R.I.P \u2014 \u0434\u043E\u0436\u0434\u0438\u0442\u0435\u0441\u044C \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F, \u0437\u0430\u0442\u0435\u043C \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430.",
        orderUrl: platform.orderUrl ?? null
      };
    }
    if (platform?.inActiveDeal || platform?.assetStatus === "RESERVED") {
      return {
        canList: false,
        softGate: false,
        reason: "in_deal",
        label: "\u0412 \u0441\u0434\u0435\u043B\u043A\u0435",
        message: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0432 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0439 \u0441\u0434\u0435\u043B\u043A\u0435 \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0435\u043B\u044C\u0437\u044F.",
        orderUrl: platform.orderUrl ?? platform.lotUrl ?? null
      };
    }
    if (platform?.listed || platform?.assetStatus === "LISTED") {
      return {
        canList: false,
        softGate: false,
        reason: "listed",
        label: "\u0423\u0436\u0435 \u043D\u0430 R.I.P",
        message: "\u042D\u0442\u043E\u0442 \u043F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443\u0436\u0435 \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435.",
        orderUrl: platform.lotUrl ?? null
      };
    }
    if (platform?.assetStatus && platform.assetStatus !== "AVAILABLE" && platform.assetStatus !== "LISTED" && platform.assetStatus !== "RESERVED") {
      return {
        canList: false,
        softGate: false,
        reason: "not_available",
        label: "\u041D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D",
        message: `\u0421\u0442\u0430\u0442\u0443\u0441 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435: ${platform.assetStatus} \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0435\u043B\u044C\u0437\u044F.`,
        orderUrl: null
      };
    }
    const nowMs = params.nowMs ?? Date.now();
    if (isTradeLocked(params.steam.tradeLockUntil, nowMs)) {
      return {
        canList: false,
        softGate: false,
        reason: "trade_locked",
        label: "Trade-lock",
        message: "\u0414\u043E\u0436\u0434\u0438\u0442\u0435\u0441\u044C \u0441\u043D\u044F\u0442\u0438\u044F trade-lock, \u0437\u0430\u0442\u0435\u043C \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435.",
        orderUrl: null
      };
    }
    if (!params.steam.tradable) {
      return {
        canList: false,
        softGate: false,
        reason: "not_tradable",
        label: "\u041D\u0435 tradable",
        message: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u043D\u0435\u043B\u044C\u0437\u044F \u043E\u0431\u043C\u0435\u043D\u044F\u0442\u044C \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0430 R.I.P \u043D\u0435\u043B\u044C\u0437\u044F.",
        orderUrl: null
      };
    }
    if (!params.steam.marketable) {
      return {
        canList: false,
        softGate: false,
        reason: "not_marketable",
        label: "\u041D\u0435 marketable",
        message: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u043D\u0435 marketable \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0430 R.I.P \u043D\u0435\u043B\u044C\u0437\u044F.",
        orderUrl: null
      };
    }
    if (params.steam.marketHashName != null && !isListableMarketHashName(params.steam.marketHashName)) {
      return {
        canList: false,
        softGate: false,
        reason: "not_listable_type",
        label: "\u041D\u0435\u043B\u044C\u0437\u044F list",
        message: "\u042D\u0442\u043E\u0442 \u0442\u0438\u043F \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u0430 \u043D\u0435\u043B\u044C\u0437\u044F \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0430 R.I.P (\u043C\u0435\u0434\u0430\u043B\u044C/\u0437\u043D\u0430\u0447\u043E\u043A \u0438 \u0442.\u043F.).",
        orderUrl: null
      };
    }
    return {
      canList: true,
      softGate: false,
      reason: null,
      label: null,
      message: null,
      orderUrl: null
    };
  }

  // src/shared/inventory-one-click-sell.ts
  var MIN_LIST_PRICE_MINOR = 1;
  function resolveInventorySellAction(params) {
    const emptyLot = {
      lotId: null,
      listedPriceMinor: null
    };
    if (!params.connected) {
      return {
        kind: "pair",
        label: "\u041F\u0440\u043E\u0434\u0430\u0442\u044C",
        blockReason: null,
        blockMessage: PRELIST_SOFT_GATE_MESSAGE,
        lotUrl: null,
        ...emptyLot
      };
    }
    if (params.siteSafeMode) {
      return {
        kind: "blocked",
        label: "\u0421\u0430\u0439\u0442 offline",
        blockReason: "site_offline",
        blockMessage: "API \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0438\u043B\u0438 \u0441\u0432\u044F\u0437\u044C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430 \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0438 \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043B\u043E\u0442\u043E\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B.",
        lotUrl: params.platform?.lotUrl ?? params.platform?.orderUrl ?? null,
        lotId: params.platform?.lotId ?? null,
        listedPriceMinor: params.platform?.listedPriceMinor ?? null
      };
    }
    if (params.platform?.listed && params.platform.lotId && !params.platform.inActiveDeal && !params.platform.hasActiveTradeTask) {
      return {
        kind: "manage",
        label: "\u0423\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C",
        blockReason: null,
        blockMessage: null,
        lotUrl: params.platform.lotUrl,
        lotId: params.platform.lotId,
        listedPriceMinor: params.platform.listedPriceMinor
      };
    }
    if (params.platform?.listed && params.platform.inActiveDeal) {
      return {
        kind: "blocked",
        label: "\u0412 \u0441\u0434\u0435\u043B\u043A\u0435",
        blockReason: "in_deal",
        blockMessage: "\u041B\u043E\u0442 \u0432 \u0441\u0434\u0435\u043B\u043A\u0435 \u2014 \u0446\u0435\u043D\u0443 \u0438 \u043E\u0442\u043C\u0435\u043D\u0443 \u043C\u0435\u043D\u044F\u0442\u044C \u043D\u0435\u043B\u044C\u0437\u044F. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437.",
        lotUrl: params.platform.orderUrl ?? params.platform.lotUrl,
        lotId: params.platform.lotId,
        listedPriceMinor: params.platform.listedPriceMinor
      };
    }
    const safety = evaluatePrelistSafety({
      connected: true,
      siteSafeMode: params.siteSafeMode,
      steam: params.steam,
      platform: params.platform,
      nowMs: params.nowMs
    });
    if (!safety.canList) {
      const blockReason = safety.reason === "disconnected" || safety.reason === "listed" ? null : safety.reason;
      return {
        kind: "blocked",
        label: safety.label ?? "\u041D\u0435\u043B\u044C\u0437\u044F",
        blockReason,
        blockMessage: safety.message,
        lotUrl: safety.orderUrl,
        lotId: params.platform?.lotId ?? null,
        listedPriceMinor: params.platform?.listedPriceMinor ?? null
      };
    }
    return {
      kind: "list",
      label: "\u041F\u0440\u043E\u0434\u0430\u0442\u044C",
      blockReason: null,
      blockMessage: null,
      lotUrl: null,
      ...emptyLot
    };
  }
  function resolveDefaultListPriceMinor(hint) {
    return getDefaultListPriceMinor(hint);
  }
  function resolveBidListOffer(hint) {
    const honestyLine = "\u042D\u0442\u043E \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0432 \u0441\u0442\u0430\u043A\u0430\u043D \u043F\u043E bid: \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u0442 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0435. \u041D\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0432\u044B\u043F\u043B\u0430\u0442\u0430.";
    const priceMinor = parseMinor(hint?.bestBidMinor);
    if (priceMinor == null) {
      return {
        available: false,
        priceMinor: null,
        quantity: null,
        buttonLabel: null,
        hintLine: null,
        honestyLine
      };
    }
    const quantity = hint?.bestBidQuantity != null && Number.isFinite(hint.bestBidQuantity) && hint.bestBidQuantity > 0 ? Math.floor(hint.bestBidQuantity) : 1;
    const money = formatUsdFromMinor(priceMinor);
    return {
      available: true,
      priceMinor,
      quantity,
      buttonLabel: `\u041F\u043E bid ${money}`,
      hintLine: quantity > 1 ? `\u041B\u0443\u0447\u0448\u0438\u0439 bid ${money} \xB7 ${quantity} \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u0433\u043E\u0442\u043E\u0432\u044B \u0434\u043E \u044D\u0442\u043E\u0439 \u0446\u0435\u043D\u044B` : `\u041B\u0443\u0447\u0448\u0438\u0439 bid ${money} \u2014 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044C \u0433\u043E\u0442\u043E\u0432 \u043A\u0443\u043F\u0438\u0442\u044C \u0434\u043E \u044D\u0442\u043E\u0439 \u0446\u0435\u043D\u044B`,
      honestyLine
    };
  }
  function parseUsdInputToMinor(input) {
    const trimmed = input.trim();
    if (!trimmed) {
      return null;
    }
    let normalized = trimmed.replace(/[^\d.,]/g, "");
    if (!normalized) {
      return null;
    }
    const lastComma = normalized.lastIndexOf(",");
    const lastDot = normalized.lastIndexOf(".");
    if (lastComma >= 0 && lastDot >= 0) {
      if (lastDot > lastComma) {
        normalized = normalized.replace(/,/g, "");
      } else {
        normalized = normalized.replace(/\./g, "").replace(",", ".");
      }
    } else if (lastComma >= 0) {
      normalized = normalized.replace(",", ".");
    }
    const value = Number(normalized);
    if (!Number.isFinite(value) || value <= 0) {
      return null;
    }
    const minor = Math.round(value * 100);
    if (minor < MIN_LIST_PRICE_MINOR) {
      return null;
    }
    return minor;
  }
  function formatUsdInputFromMinor(minor) {
    return (minor / 100).toFixed(2);
  }
  function buildInventorySellPreview(priceMinor) {
    if (!Number.isFinite(priceMinor) || priceMinor < MIN_LIST_PRICE_MINOR) {
      return null;
    }
    const commissionMinor = calculateCommissionMinor(priceMinor);
    const sellerReceiveMinor = calculateSellerReceiveMinor(priceMinor);
    return {
      priceMinor,
      commissionMinor,
      sellerReceiveMinor,
      priceLine: formatUsdFromMinor(priceMinor),
      commissionLine: `\u043A\u043E\u043C\u0438\u0441\u0441\u0438\u044F 5% \xB7 ${formatUsdFromMinor(commissionMinor)}`,
      receiveLine: `\u0432\u0430\u043C ${formatUsdFromMinor(sellerReceiveMinor)}`
    };
  }
  function validateCreateLotPriceMinor(priceMinor) {
    if (priceMinor == null) {
      return "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0446\u0435\u043D\u0443 \u0431\u043E\u043B\u044C\u0448\u0435 $0.00";
    }
    if (priceMinor < MIN_LIST_PRICE_MINOR) {
      return "\u041C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u2014 $0.01";
    }
    return null;
  }

  // src/shared/inventory-manage-listing.ts
  function resolveManageListingAction(params) {
    if (!params.connected || !params.platform?.listed) {
      return {
        kind: "none",
        label: "",
        lotId: null,
        lotUrl: null,
        orderUrl: null,
        listedPriceMinor: null,
        message: null
      };
    }
    if (params.platform.inActiveDeal) {
      return {
        kind: "in_deal",
        label: "\u0412 \u0441\u0434\u0435\u043B\u043A\u0435",
        lotId: params.platform.lotId,
        lotUrl: params.platform.lotUrl,
        orderUrl: params.platform.orderUrl,
        listedPriceMinor: parseMinor(params.platform.listedPriceMinor),
        message: "\u041B\u043E\u0442 \u0443\u0436\u0435 \u0432 \u0441\u0434\u0435\u043B\u043A\u0435 \u2014 \u0446\u0435\u043D\u0443 \u043C\u0435\u043D\u044F\u0442\u044C \u0438 \u043E\u0442\u043C\u0435\u043D\u044F\u0442\u044C \u043D\u0435\u043B\u044C\u0437\u044F. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437."
      };
    }
    if (!params.platform.lotId) {
      return {
        kind: "missing_lot",
        label: "\u041D\u0430 R.I.P",
        lotId: null,
        lotUrl: params.platform.lotUrl,
        orderUrl: null,
        listedPriceMinor: parseMinor(params.platform.listedPriceMinor),
        message: "\u041B\u043E\u0442 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435."
      };
    }
    return {
      kind: "manage",
      label: "\u0423\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C",
      lotId: params.platform.lotId,
      lotUrl: params.platform.lotUrl,
      orderUrl: null,
      listedPriceMinor: parseMinor(params.platform.listedPriceMinor),
      message: null
    };
  }
  function formatListedPriceInput(listedPriceMinor) {
    if (listedPriceMinor == null) {
      return "";
    }
    return formatUsdInputFromMinor(listedPriceMinor);
  }
  function buildManagePricePreview(priceInput) {
    const priceMinor = parseUsdInputToMinor(priceInput);
    const error = validateCreateLotPriceMinor(priceMinor);
    if (error || priceMinor == null) {
      return { priceMinor: null, preview: null, error: error ?? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0446\u0435\u043D\u0443" };
    }
    return {
      priceMinor,
      preview: buildInventorySellPreview(priceMinor),
      error: null
    };
  }
  function hasPriceChanged(currentMinor, nextMinor) {
    if (currentMinor == null || nextMinor == null) {
      return false;
    }
    return currentMinor !== nextMinor;
  }
  function formatManageCurrentPriceLine(listedPriceMinor) {
    if (listedPriceMinor == null) {
      return "\u0422\u0435\u043A\u0443\u0449\u0430\u044F \u0446\u0435\u043D\u0430 \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430";
    }
    return `\u0421\u0435\u0439\u0447\u0430\u0441 ${formatUsdFromMinor(listedPriceMinor)}`;
  }

  // src/shared/inventory-bulk-sell.ts
  var MIN_BULK_LISTING_COUNT = 2;
  var MAX_BULK_LISTING_COUNT = 50;
  function formatBulkListingPreview(names, maxVisible = 6) {
    const unique = [];
    const seen = /* @__PURE__ */ new Set();
    for (const raw of names) {
      const name = raw.trim();
      if (!name || seen.has(name)) {
        continue;
      }
      seen.add(name);
      unique.push(name);
    }
    const lines = unique.slice(0, Math.max(1, maxVisible));
    return {
      lines,
      moreCount: Math.max(0, unique.length - lines.length),
      uniqueCount: unique.length
    };
  }
  function isFungibleSteamFacts(steam) {
    if (steam.floatValue != null && String(steam.floatValue).trim() !== "") {
      const numeric = Number(steam.floatValue);
      if (Number.isFinite(numeric)) {
        return false;
      }
    }
    if (steam.paintSeed != null && Number.isFinite(steam.paintSeed)) {
      return false;
    }
    if (steam.wear != null && String(steam.wear).trim() !== "") {
      return false;
    }
    return true;
  }
  function canSelectForBulkSell(params) {
    const action = resolveInventorySellAction({
      connected: params.connected,
      steam: params.steam,
      platform: params.platform,
      nowMs: params.nowMs
    });
    return action.kind === "list";
  }
  function buildBulkSellItem(params) {
    const name = params.steam.marketHashName?.trim();
    if (!name) {
      return null;
    }
    return {
      steamAssetId: params.steam.assetId,
      inventoryAssetId: params.platform?.inventoryAssetId ?? null,
      marketHashName: name,
      fungible: isFungibleSteamFacts(params.steam)
    };
  }
  function planBulkSellOperations(items, options) {
    const maxCount = options?.maxCount ?? MAX_BULK_LISTING_COUNT;
    const unique = /* @__PURE__ */ new Map();
    for (const item of items) {
      if (!item.steamAssetId || !item.marketHashName) {
        continue;
      }
      unique.set(item.steamAssetId, item);
    }
    const all = [...unique.values()];
    const truncated = all.length > maxCount;
    const selected = truncated ? all.slice(0, maxCount) : all;
    const fungibleGroups = /* @__PURE__ */ new Map();
    const sequential = [];
    for (const item of selected) {
      if (!item.fungible) {
        sequential.push(item);
        continue;
      }
      const group = fungibleGroups.get(item.marketHashName) ?? [];
      group.push(item);
      fungibleGroups.set(item.marketHashName, group);
    }
    const operations = [];
    let bulkGroups = 0;
    let sequentialCount = 0;
    for (const [marketHashName, group] of fungibleGroups) {
      if (group.length >= MIN_BULK_LISTING_COUNT) {
        operations.push({
          type: "platform_bulk",
          marketHashName,
          items: group
        });
        bulkGroups += 1;
      } else {
        sequential.push(...group);
      }
    }
    if (sequential.length > 0) {
      operations.push({ type: "sequential", items: sequential });
      sequentialCount = sequential.length;
    }
    const plannedCount = selected.length;
    let modeLabel = "\u041F\u043E \u043E\u0434\u043D\u043E\u043C\u0443";
    if (bulkGroups > 0 && sequentialCount === 0) {
      modeLabel = bulkGroups === 1 ? "\u041F\u0430\u043A\u0435\u0442 (\u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0435)" : "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u0430\u043A\u0435\u0442\u043E\u0432";
    } else if (bulkGroups > 0 && sequentialCount > 0) {
      modeLabel = "\u041F\u0430\u043A\u0435\u0442 + \u043F\u043E \u043E\u0434\u043D\u043E\u043C\u0443";
    } else if (plannedCount >= MIN_BULK_LISTING_COUNT) {
      modeLabel = "\u041F\u043E \u043E\u0434\u043D\u043E\u043C\u0443 (\u0440\u0430\u0437\u043D\u044B\u0435 \u0441\u043A\u0438\u043D\u044B)";
    }
    const parts = [];
    if (bulkGroups > 0) {
      parts.push(
        bulkGroups === 1 ? "1 \u043F\u0430\u043A\u0435\u0442 \u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0445" : `${bulkGroups} \u043F\u0430\u043A\u0435\u0442\u0430 \u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0445`
      );
    }
    if (sequentialCount > 0) {
      parts.push(`${sequentialCount} \u043F\u043E \u043E\u0434\u043D\u043E\u043C\u0443`);
    }
    if (truncated) {
      parts.push(`\u043B\u0438\u043C\u0438\u0442 ${maxCount}`);
    }
    return {
      operations,
      selectedCount: all.length,
      plannedCount,
      truncated,
      modeLabel,
      summaryLine: parts.length > 0 ? parts.join(" \xB7 ") : plannedCount === 1 ? "1 \u043F\u0440\u0435\u0434\u043C\u0435\u0442" : `${plannedCount} \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432`
    };
  }
  function validateBulkSelectionForSubmit(count) {
    if (count < MIN_BULK_LISTING_COUNT) {
      return `\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043C\u0438\u043D\u0438\u043C\u0443\u043C ${MIN_BULK_LISTING_COUNT} \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u0430`;
    }
    if (count > MAX_BULK_LISTING_COUNT) {
      return `\u0417\u0430 \u043E\u0434\u0438\u043D \u0440\u0430\u0437 \u2014 \u0434\u043E ${MAX_BULK_LISTING_COUNT} \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432`;
    }
    return null;
  }
  function buildBulkProgress(params) {
    const total = Math.max(0, params.total);
    const done = Math.min(total, Math.max(0, params.done));
    return {
      total,
      done,
      created: params.created,
      failed: params.failed,
      label: total === 0 ? "\u041D\u0435\u0442 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432" : `\u0412\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E ${params.created} \u0438\u0437 ${total}${params.failed > 0 ? ` \xB7 \u043E\u0448\u0438\u0431\u043E\u043A ${params.failed}` : ""}`
    };
  }
  function toggleBulkSelection(selected, assetId, enabled) {
    const next = new Set(selected);
    if (enabled) {
      if (next.size >= MAX_BULK_LISTING_COUNT && !next.has(assetId)) {
        return next;
      }
      next.add(assetId);
    } else {
      next.delete(assetId);
    }
    return next;
  }

  // src/shared/listing-api-errors.ts
  var MESSAGES_RU = {
    STEAM_VAC_BANNED: "\u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u0441 VAC-\u0431\u0430\u043D\u043E\u043C \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0442\u043E\u0440\u0433\u043E\u0432\u0430\u0442\u044C \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435.",
    STEAM_GAME_BANNED: "\u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u0441 \u0438\u0433\u0440\u043E\u0432\u044B\u043C \u0431\u0430\u043D\u043E\u043C Steam \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0442\u043E\u0440\u0433\u043E\u0432\u0430\u0442\u044C \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435.",
    STEAM_BAN_CHECK_UNAVAILABLE: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0441\u0442\u0430\u0442\u0443\u0441 \u0431\u0430\u043D\u043E\u0432 Steam \u2014 \u044D\u0442\u043E \u043D\u0435 \u0431\u0430\u043D. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0447\u0435\u0440\u0435\u0437 \u043C\u0438\u043D\u0443\u0442\u0443.",
    TRADE_URL_REQUIRED: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 Trade URL \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430 \u2014 \u0431\u0435\u0437 \u043D\u0435\u0433\u043E \u043D\u0435\u043B\u044C\u0437\u044F \u043F\u0440\u043E\u0434\u0430\u0432\u0430\u0442\u044C.",
    TRADE_URL_STEAM_MISMATCH: "Trade URL \u043D\u0435 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u043E\u043C\u0443 Steam-\u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0443.",
    INVENTORY_ASSET_NOT_TRADABLE: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0441\u0435\u0439\u0447\u0430\u0441 \u043D\u0435\u043B\u044C\u0437\u044F \u043E\u0431\u043C\u0435\u043D\u044F\u0442\u044C.",
    INVENTORY_ASSET_TRADE_LOCKED: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0432 trade-lock Steam.",
    INVENTORY_ASSET_NOT_AVAILABLE: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0434\u043B\u044F \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F.",
    INVENTORY_ASSET_NOT_FOUND: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0432 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u0435 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438.",
    LOT_ALREADY_EXISTS_FOR_ASSET: "\u0414\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u0430 \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u043B\u043E\u0442.",
    SELLER_NOT_ACTIVE: "\u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430 \u043D\u0435 \u0430\u043A\u0442\u0438\u0432\u0435\u043D.",
    EXTENSION_SESSION_REVOKED: "\u0421\u0435\u0441\u0441\u0438\u044F \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u0430. \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430.",
    EXTENSION_TOKEN_EXPIRED: "\u0421\u0435\u0441\u0441\u0438\u044F \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u0430. \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430."
  };
  var HARD_BAN_CODES = /* @__PURE__ */ new Set(["STEAM_VAC_BANNED", "STEAM_GAME_BANNED"]);
  function isHardSteamTradeBanCode(code) {
    return Boolean(code && HARD_BAN_CODES.has(code));
  }
  function humanizeListingApiError(error) {
    const code = error.code?.trim() || null;
    if (code && MESSAGES_RU[code]) {
      return MESSAGES_RU[code];
    }
    const raw = (error.message ?? "").trim();
    if (/Unable to verify VAC|Unable to verify Steam ban|ban check is required/i.test(raw)) {
      return MESSAGES_RU.STEAM_BAN_CHECK_UNAVAILABLE;
    }
    if (/VAC ban/i.test(raw) && !/Unable to verify/i.test(raw)) {
      return MESSAGES_RU.STEAM_VAC_BANNED;
    }
    if (/game ban/i.test(raw)) {
      return MESSAGES_RU.STEAM_GAME_BANNED;
    }
    const stripped = raw.replace(
      /^Extension API\s+\S+\s+failed:\s+\d+\s+/i,
      ""
    );
    if (stripped && stripped !== raw) {
      if (/Unable to verify VAC|Unable to verify Steam ban/i.test(stripped)) {
        return MESSAGES_RU.STEAM_BAN_CHECK_UNAVAILABLE;
      }
      return stripped;
    }
    return raw || "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.";
  }

  // src/shared/inventory-layer.ts
  function resolveInventoryLayerView(params) {
    if (params.connected && params.siteSafeMode) {
      return {
        title: "R.I.P Market",
        statusLabel: "\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C",
        body: "\u0421\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430. \u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D, \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u0430.",
        ctaLabel: "\u041C\u043E\u0438 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F",
        ctaHref: params.listingsUrl,
        secondaryCta: {
          label: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
          href: params.sellUrl
        },
        connection: "safe_mode",
        itemHolderCount: params.itemHolderCount
      };
    }
    if (params.connected) {
      return {
        title: "R.I.P Market",
        statusLabel: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
        body: "\u0426\u0435\u043D\u044B \u0438 \u043A\u043D\u043E\u043F\u043A\u0438 \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430\u0445. \u0412\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u043F\u043E \u043E\u0434\u043D\u043E\u043C\u0443 \u0438\u043B\u0438 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u0440\u0430\u0437\u0443.",
        ctaLabel: "\u041C\u043E\u0438 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F",
        ctaHref: params.listingsUrl,
        secondaryCta: {
          label: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
          href: params.sellUrl
        },
        connection: "connected",
        itemHolderCount: params.itemHolderCount
      };
    }
    return {
      title: "R.I.P Market",
      statusLabel: "\u041D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      body: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432 \u0410\u043A\u043A\u0430\u0443\u043D\u0442\u0435 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u2014 \u0442\u043E\u0433\u0434\u0430 \u043C\u043E\u0436\u043D\u043E \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B.",
      ctaLabel: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      ctaHref: params.accountUrl,
      secondaryCta: null,
      connection: "disconnected",
      itemHolderCount: params.itemHolderCount
    };
  }

  // src/shared/extension-i18n-core.ts
  var DEFAULT_EXTENSION_LOCALE = "ru";
  var EXTENSION_LOCALE_STORAGE_KEY = "rip:extension.locale";
  function isExtensionLocale(value) {
    return value === "ru" || value === "en";
  }
  function normalizeExtensionLocale(value, fallback = DEFAULT_EXTENSION_LOCALE) {
    if (isExtensionLocale(value)) {
      return value;
    }
    if (typeof value === "string") {
      const lower = value.trim().toLowerCase();
      if (lower.startsWith("en")) {
        return "en";
      }
      if (lower.startsWith("ru")) {
        return "ru";
      }
    }
    return fallback;
  }
  function getMessageByPath(tree, path) {
    const parts = path.split(".");
    let current = tree;
    for (const part of parts) {
      if (current == null || typeof current === "string") {
        return void 0;
      }
      current = current[part];
    }
    return typeof current === "string" ? current : void 0;
  }
  function interpolateExtension(template, params) {
    if (!params) {
      return template;
    }
    return template.replace(/\{\{(\w+)\}\}/g, (_match, key) => {
      const value = params[key];
      return value === void 0 || value === null ? "" : String(value);
    });
  }
  function translateExtension(tree, key, params) {
    const template = getMessageByPath(tree, key);
    if (template == null) {
      return key;
    }
    return interpolateExtension(template, params);
  }
  async function getStoredExtensionLocale() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local?.get) {
        const stored = await chrome.storage.local.get(EXTENSION_LOCALE_STORAGE_KEY);
        return normalizeExtensionLocale(stored[EXTENSION_LOCALE_STORAGE_KEY]);
      }
    } catch {
    }
    return DEFAULT_EXTENSION_LOCALE;
  }

  // src/shared/extension-messages-en.ts
  var extensionMessagesEn = {
    common: {
      openOrder: "Open order",
      openSite: "Open site",
      more: "More",
      loading: "Loading\u2026",
      cancel: "Cancel",
      buy: "Buy",
      sell: "Sell",
      buyer: "Buyer",
      seller: "Seller"
    },
    popup: {
      lead: "Deals and status \xB7 p2pcs",
      openSite: "Open site",
      refreshHealth: "Status",
      refreshTrades: "Deals",
      copyDebug: "Copy support report",
      copyDebugBusy: "Copying\u2026",
      copyDebugDone: "Copied \u2713",
      copyDebugOpened: "Copied \xB7 opening support",
      disconnect: "Disconnect",
      pairHint: "Connect the extension on the account page on p2pcs.ru.",
      advanced: "Advanced",
      toolsTitle: "Tools",
      healthTitle: "Health",
      trustTitle: "Trust",
      quietNotifyLabel: "Quiet notifications (deal / Guard / Accept / Mismatch)",
      quietNotifyNote: "Only when a deal state changes. Multiple events \u2192 one group alert. \u201CLater\u201D hides the card for 15 minutes. \u201CMute deal\u201D silences alerts until the deal ends.",
      supportEmergency: "Support \xB7 emergency access",
      apiKeyNote: "Not for everyday use. Paste a key only if R.I.P Market support explicitly asked \u2014 and only while Steam is broken.",
      apiKeyLabel: "Backup Steam Web API key",
      apiKeyPlaceholder: "Only if support asked you to",
      apiKeySave: "Save",
      apiKeyClear: "Clear",
      apiKeyStatusSaved: "Key stored locally; api.steampowered.com access granted only for fallback.",
      apiKeyStatusEmpty: "No key \u2014 the extension uses your Steam session in Chrome.",
      apiKeyPermissionDenied: "Chrome did not grant api.steampowered.com \u2014 key was not saved.",
      permissionsTitle: "Why these permissions",
      languageLabel: "Interface language",
      languageRu: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
      languageEn: "English",
      languageHint: "Synced from the site on pair; you can change it here.",
      buyersTitle: "Purchases",
      buyersSub: "Waiting for offer \xB7 verifying",
      sellersTitle: "Sales",
      sellersSub: "In progress \xB7 delivery check",
      receiptsTitle: "Recent deals",
      receiptsSub: "Compact list \xB7 tap for details",
      receiptsAllOnSite: "All deals on the site",
      receiptsMoreOnSite: "{{count}} more on the site",
      actionTitle: "Action needed",
      actionSub: "One primary step per card",
      snoozeLater: "Later",
      emptyTitle: "All quiet",
      emptyBody: "No deals need action right now."
    },
    safeMode: {
      offlineTitle: "Server link lost \xB7 safe mode",
      offlineBody: "The site page may still load in the browser, but the deals API is unreachable. Showing cache; listing and sending offers are paused until the link recovers.",
      degradedTitle: "Unstable link to the server",
      degradedBody: "Cached deals on screen. List / send are paused \u2014 confirm Guard or Accept only in Steam if the offer is already verified.",
      cacheLine: "Deal cache \xB7 {{when}}",
      cacheEmpty: "No cached deals yet \u2014 refresh when the API is back.",
      hint: "Safe mode: platform list and send are paused.",
      waitCta: "Waiting for server link",
      blockMessage: "Deals API unreachable or unstable \u2014 listing and sending offers are paused (safe mode)."
    },
    cta: {
      openDispute: "Open dispute",
      openDisputeSupport: "Open dispute / support",
      openOrder: "Open order",
      confirmGuard: "Confirm in Steam Mobile",
      openTradeUrl: "Open Trade URL",
      retrySend: "Retry send",
      retryAutoSend: "Retry auto-send",
      confirmSent: "I sent the trade",
      openVerifiedOffer: "Open verified offer",
      openVerifiedOfferSteam: "Open verified offer in Steam",
      preAcceptAck: "I see the correct offer",
      problemSupport: "Trade problem",
      confirmReceived: "Item is mine",
      openOfferSteam: "Open offer in Steam",
      platformStatus: "Status on site",
      refreshStatus: "Refresh status",
      waitSeller: "Waiting for seller",
      open: "Open",
      openAccount: "Open account",
      loginNeededSteam: "Sign in to the right Steam",
      loginSteam: "Sign in to Steam",
      openSteamInventory: "Open Steam inventory"
    },
    nextAction: {
      hintDisputeOpen: "A dispute is already open \u2014 evidence goes into the ticket. Do not accept other offers.",
      hintMismatch: "Do not accept this trade in Steam. Evidence (offerId, verify, time) will fill the ticket.",
      hintGuard: "The extension never confirms Guard \u2014 only you in Steam Mobile.",
      hintManualWithUrl: "Send the skin manually, then paste the offerId on the order.",
      hintManualRetry: "Auto-send could not finish \u2014 retry or open the order.",
      hintAccept: "Accept only with Steam\u2019s Accept button on this offer page.",
      hintConfirmReceived: "Confirm here \u2014 no need to return to the site.",
      hintVerifying: "The platform is checking delivery \u2014 usually nothing to do.",
      hintWaitSeller: "As soon as the offer appears, an accept button shows here.",
      hintWaitBuyer: "Offer is with the buyer. Status updates after they Accept."
    },
    dealConfirm: {
      acceptTitle: "Accept the trade in Steam",
      acceptBody: "Check the shield, then press Accept. We never accept for you.",
      receivedTitle: "Item with you?",
      receivedBody: "Confirm here \u2014 the site status updates on its own.",
      verifyingTitle: "Checking delivery",
      verifyingBody: "Matching Steam and inventory. Usually quick.",
      doneTitle: "Done",
      doneBody: "The platform has the deal. Open the order only if you need it.",
      guardTitle: "Confirm in Steam Mobile",
      guardBody: "Guard is only in the Steam app. Status updates here by itself."
    },
    badge: {
      rePair: "Connect",
      steam: "Steam",
      inventory: "Inventory",
      guard: "Guard",
      accept: "Accept",
      mismatch: "Mismatch",
      sendManual: "Manual",
      confirmSent: "Confirm",
      confirmReceived: "Received",
      reportIssue: "Issue"
    },
    connection: {
      revokedTitle: "Session expired",
      revokedDetail: "Reconnect the extension on the account page.",
      offTitle: "Not connected to the site",
      offDetail: "The site may already be open \u2014 go to Account \u2192 \u201CConnect extension\u201D (this is not a Chrome setting).",
      steamUnknown: "Steam: unknown",
      mismatchTitle: "Site connected \xB7 wrong Steam",
      mismatchDetail: "Steam does not match",
      noSteamTitle: "Site connected \xB7 not signed in to Steam",
      noSteamDetail: "Steam: no session",
      connectedUntil: "Connected until {{expires}}",
      connectedOkTitle: "Connected \xB7 site and Steam match",
      inventoryIssueTitle: "Steam OK \xB7 inventory issue",
      connectedTitle: "Connected",
      connectedDetail: "Site and Steam match \u2014 ready for deals.",
      steamAligned: "Site and Steam match"
    },
    buyerPhase: {
      wait_offer: "Waiting for offer",
      accept: "Accept",
      verifying: "Verifying",
      dispute: "Dispute / issue"
    },
    timeout: {
      expired: "Trade window expired \u2014 a dispute may open soon",
      minutes: "~{{minutes}} min left until auto-dispute",
      hoursMinutes: "~{{hours}} h {{minutes}} min left until auto-dispute"
    },
    settlement: {
      soonSuffix: "{{formatted}} (soon)",
      offerOk: "Steam offer: accepted",
      offerWarn: "Steam offer: problem",
      offerPending: "Steam offer: checking",
      offerUnknown: "Steam offer: clarifying",
      invOk: "Inventory: skin with buyer",
      invWarn: "Inventory: still with seller",
      invPending: "Inventory: checking",
      invUnknown: "Inventory: clarifying",
      deliveryTitleSeller: "Verifying delivery",
      deliveryTitleBuyer: "Item is yours \u2014 verifying delivery",
      deliveryBodySeller: "Matching Steam offer and inventory. No new offer needed for this deal.",
      deliveryBodyBuyer: "Nothing to do \u2014 the platform matches Steam offer and inventory.",
      fundsSellerKnown: "Funds available from: {{date}}",
      fundsSellerUnknown: "Funds available after the review window (up to {{days}} days)",
      fundsBuyerKnown: "Seller payout from: {{date}}",
      fundsBuyerUnknown: "Seller payout after the review window (up to {{days}} days)",
      holdTitleSeller: "Funds on hold",
      holdTitleBuyer: "Skin is yours \u2014 settlement on-platform",
      holdBodySeller: "Protects against chargebacks and Steam trade reversals. Payout to balance after hold.",
      holdBodyBuyer: "Item is in your inventory. Seller funds unlock after the on-platform review window."
    },
    dispute: {
      openTitle: "Dispute open",
      openBody: "Support is reviewing the deal. Do not accept other offers for this order and do not send money in chat.",
      needTitle: "Dispute needed",
      needMismatch: "Offer does not match the order. Do not press Accept \u2014 open a dispute with evidence (offerId, verify, time).",
      needGeneric: "There is a problem with this deal. Open a dispute \u2014 evidence fills the ticket automatically.",
      ticketPlaceholder: "(describe what went wrong)"
    },
    receipt: {
      eyebrow: "Receipt",
      bought: "Bought",
      sold: "Sold",
      price: "Deal price",
      commission: "Platform fee (5%)",
      paid: "You paid",
      credited: "Credited to balance",
      openOrder: "Open order"
    },
    session: {
      okTitle: "Ready for deals",
      okMessage: "Extension and Steam are connected.",
      disconnectedTitle: "Extension not connected",
      disconnectedMessage: "Open the site \u2192 Account \u2192 \u201CConnect extension\u201D.",
      disconnectedCta: "Open account on site",
      revokedTitle: "Extension session expired",
      revokedMessage: "Reconnect the extension on the account page.",
      revokedCta: "Connect on site",
      cookieTitle: "Not signed in to Steam",
      cookieMessage: "Sign in to steamcommunity.com in this Chrome with the seller account.",
      cookieCta: "Sign in to Steam",
      mismatchTitle: "Wrong Steam in the browser",
      mismatchMessage: "Chrome is signed in as {{session}}, need {{expected}}",
      mismatchCta: "Sign in to the right Steam",
      privateTitle: "Inventory is private",
      privateMessage: "Make your CS2 inventory visible to the extension (Privacy \u2192 Inventory: Public).",
      privateCta: "Open Steam settings",
      rateTitle: "Steam temporarily limited requests",
      rateMessage: "Wait 1\u20132 minutes and tap \u201CCheck again\u201D. No Steam key needed \u2014 if it lasts, contact support.",
      rateCta: "Open Steam inventory",
      inventoryTitle: "Inventory failed to load",
      inventoryMessage: "Open your CS2 inventory in Steam and check again.",
      inventoryCta: "Open Steam inventory"
    },
    notify: {
      guardTitle: "Sale \u2014 confirm Guard",
      guardBody: "{{short}} \xB7 {{item}}. Open Steam Mobile and confirm the trade.",
      acceptTitle: "Purchase \u2014 offer ready to accept",
      acceptBody: "{{short}} \xB7 {{item}}. Open the verified offer in Steam.",
      mismatchTitle: "Mismatch \u2014 do not accept",
      mismatchBody: "{{short}} \xB7 {{item}}. Skin mismatch \u2014 do not press Accept.",
      newDealTitle: "New sale \u2014 sending the trade",
      newDealBody: "{{short}} \xB7 {{item}}. Keep Steam open \u2014 the extension will send the offer.",
      groupMismatch: "Several mismatches \u2014 do not accept",
      groupGuard: "Several sales waiting for Guard",
      groupAccept: "Several purchases waiting to accept",
      groupNewDeal: "Several new sales",
      groupBody: "{{count}} deals need action",
      muteDeal: "Mute deal"
    },
    cardContext: {
      buy: "Buy",
      sell: "Sell",
      dispute: "Dispute",
      mismatch: "Mismatch",
      waitGuard: "Waiting for Guard",
      waitAccept: "Waiting for Accept",
      sendManual: "Send manually",
      confirmSent: "Confirm sent",
      confirmReceived: "Confirm received",
      platformCheck: "Platform check",
      completed: "Completed",
      offerReady: "Offer ready",
      waitBuyer: "Waiting for buyer",
      checking: "Checking\u2026",
      waitTrade: "Waiting for trade",
      tradeConfirmed: "Trade confirmed",
      hold: "Hold / settlement",
      failed: "Failed",
      canceled: "Canceled",
      inProgress: "In progress"
    },
    guided: {
      mismatchTitle: "Mismatch \u2014 do not accept",
      mismatchBuyer: "This offer does not match the R.I.P Market order. Do not press Accept in Steam.",
      mismatchSeller: "Offer does not match the order. Check on the site and do not ask the buyer to accept.",
      verifiedTitle: "Skin matched",
      verifiedBuyer: "You can accept with Steam\u2019s button on this page. Funds are already on the platform \u2014 do not pay in chat.",
      verifiedSeller: "Trade matched the order. Follow the next step on the site / Guard.",
      partialTitle: "Checking\u2026",
      partialBody: "Some checks are still running. Wait \u2014 do not rush Accept yet.",
      pendingTitle: "Waiting for verification",
      pendingBody: "Matching the offer to the R.I.P Market order.",
      name: "Name",
      stickers: "Stickers",
      partner: "Partner SteamID",
      assetId: "Asset ID",
      wear: "Wear",
      float: "Float",
      hintBlock: "Do not accept this trade in Steam",
      hintAccept: "Accept the trade with Steam\u2019s button on this page",
      hintWait: "Wait for verification to finish \u2014 do not rush Accept"
    },
    offerGate: {
      needCs2Title: "Select CS2",
      needCs2Body: "In the inventory list on the left, choose Counter-Strike 2. The extension will add the deal skin.",
      needItemTitle: "Add the skin to the trade",
      needItemBody: "Needed item: {{name}}. Click it in your inventory \u2014 it should appear under \u201CYour items\u201D.",
      itemReadyTitle: "Skin is in the offer",
      itemReadyBody: "Check the shield, then press \u201CMake Offer\u201D in Steam. Guard is confirmed only in the Steam app."
    },
    shield: {
      dealLine: "Order #{{short}} \xB7 {{amount}}",
      wear: "Wear",
      float: "Float",
      stickers: "Stickers",
      unknownPartner: "Counterparty",
      partnerMatch: "Steam partner matches",
      partnerMismatch: "Steam partner MISMATCH \u2014 do not accept",
      partnerMissingObserved: "Could not read partner from the Steam page",
      partnerMissingExpected: "Order has no counterparty SteamID",
      partnerUnknown: "Partner not recognized",
      partnerMatchCheck: "Partner SteamID matches the order",
      partnerMismatchCheck: "Partner SteamID does not match the order",
      partnerMissingObservedCheck: "Partner SteamID not found on the page",
      partnerMissingExpectedCheck: "Order has no counterparty SteamID",
      copySteamId: "Copy",
      copied: "Copied",
      openProfile: "Steam profile",
      steamIdMissing: "SteamID unavailable",
      expectedCol: "Expected",
      observedCol: "In offer",
      preSendTitle: "Before you send",
      preSendBody: "Confirm the buyer and item. Confirm Guard only in Steam Mobile.",
      compareTitle: "Match against Steam"
    },
    acceptAssist: {
      acceptSteam: "Accept (Steam)",
      confirmAccept: "Confirm Accept in Steam",
      cancel: "Cancel",
      openVerified: "Open verified offer #{{short}} and accept with Steam\u2019s button",
      acceptNotFound: "Steam Accept button not found. Press the green Accept on the page manually.",
      acceptClickFailed: "Could not click Accept. Press Steam\u2019s green button manually.",
      doubleConfirm: "Confirm again \u2014 only then we click Accept in Steam. We never auto-accept.",
      guardHint: "If Steam asks for Guard \u2014 confirm in Steam Mobile.",
      confirmAgain: "If Confirm appears \u2014 tap \u201CAccept (Steam)\u201D again, or Confirm in Steam.",
      commandSent: "Command sent to Steam. {{guardHint}}",
      assistFailed: "Could not help with Accept. Press Steam\u2019s green button on the page.",
      highlightHint: "We highlight Steam\u2019s button. Accept only after your second confirmation."
    },
    manualCreate: {
      buildOffer: "Build offer #{{short}}",
      autoFailed: "Auto-send failed \u2014 we will build the offer via Steam UI: item + buyer Trade URL.",
      canBuild: "You can build the offer manually with the same autofill as auto-send."
    },
    ops: {
      never: "never yet",
      justNow: "just now",
      secondsAgo: "{{seconds}}s ago",
      minutesAgo: "{{minutes}} min ago",
      hoursAgo: "{{hours}} h ago",
      pollStale: "Poll stale \xB7 {{age}}",
      pollNever: "Poll: no successful run yet",
      pollOld: "Poll old \xB7 {{age}}",
      pollOk: "Poll: {{age}}",
      rateLimited: "Steam: rate limit \u2014 wait 1\u20132 min",
      rateOk: "Steam: no rate limit",
      version: "Version {{version}}",
      updateExtension: "Update extension"
    },
    onboarding: {
      coachTitle: "Sell on R.I.P right from here",
      coachBody: "List here \u2014 the trade goes out on purchase. You confirm Guard only in Steam Mobile.",
      coachDismiss: "Got it",
      autoHideHint: "Hides in ~30 sec",
      extensionReady: "Extension connected",
      extensionHint: "Pairing with the site is needed for prices, listing, and auto-trade.",
      extensionAction: "Connect",
      tradeUrlTitle: "Trade URL on the site",
      tradeUrlHint: "Without a Trade URL buyers cannot receive the trade after paying.",
      tradeUrlAction: "Add Trade URL",
      checklistTitle: "Seller readiness",
      checklistReady: "All set \u2014 you can list from Steam",
      checklistProgress: "Ready {{ready}} of {{total}}"
    },
    twoMin: {
      title: "Start",
      lead: "Four steps \u2014 then deals run themselves.",
      progress: "{{ready}} / {{total}}",
      stepInstall: "Extension installed",
      hintInstall: "You\u2019re already here \u2014 this step is done.",
      stepPair: "Connect to the site",
      hintPair: "Account \u2192 \u201CConnect extension\u201D on p2pcs.ru.",
      stepInventory: "Open CS2 inventory",
      hintInventory: "Steam Community \u2192 Inventory \u2192 Counter-Strike 2.",
      stepList: "Trial list",
      hintList: "Pick a skin \u2192 blue \u201CSell\u201D on the card. Guard later only in Mobile.",
      ctaPair: "Open account on site",
      ctaInventory: "Open CS2 inventory",
      ctaList: "List your first skin",
      ctaDone: "Done",
      dismiss: "Later",
      trialTitle: "Trial list (~30 sec)",
      trialBody: "On a skin card in the grid, tap blue \u201CSell\u201D (not Steam\u2019s green Sell on the right). This checks the path \u2014 not play money.",
      trialDismiss: "Hide tip"
    },
    overlay: {
      brand: "R.I.P Market",
      openDispute: "Open dispute",
      openDisputeSupport: "Open dispute / support",
      openOrder: "Open order"
    },
    inventory: {
      layerBrand: "R.I.P Market",
      steamEnrichmentDegraded: "Some Steam float/prices are still loading \u2014 blue \u201CSell\u201D on cards is already available."
    }
  };

  // src/shared/extension-messages-ru.ts
  var extensionMessagesRu = {
    common: {
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437",
      openSite: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u0430\u0439\u0442",
      more: "\u0415\u0449\u0451",
      loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026",
      cancel: "\u041E\u0442\u043C\u0435\u043D\u0430",
      buy: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430",
      sell: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430",
      buyer: "\u041F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044C",
      seller: "\u041F\u0440\u043E\u0434\u0430\u0432\u0435\u0446"
    },
    popup: {
      lead: "\u0421\u0434\u0435\u043B\u043A\u0438 \u0438 \u0441\u0442\u0430\u0442\u0443\u0441 \xB7 p2pcs",
      openSite: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u0430\u0439\u0442",
      refreshHealth: "\u0421\u0442\u0430\u0442\u0443\u0441",
      refreshTrades: "\u0421\u0434\u0435\u043B\u043A\u0438",
      copyDebug: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043E\u0442\u0447\u0451\u0442",
      copyDebugBusy: "\u041A\u043E\u043F\u0438\u0440\u0443\u0435\u043C\u2026",
      copyDebugDone: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u2713",
      copyDebugOpened: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E \xB7 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u043C \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      disconnect: "\u041E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      pairHint: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430 \u043D\u0430 p2pcs.ru.",
      advanced: "\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E",
      toolsTitle: "\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B",
      healthTitle: "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435",
      trustTitle: "\u0414\u043E\u0432\u0435\u0440\u0438\u0435",
      quietNotifyLabel: "\u0422\u043E\u043B\u044C\u043A\u043E \u0432\u0430\u0436\u043D\u044B\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043F\u043E \u0441\u0434\u0435\u043B\u043A\u0430\u043C",
      quietNotifyNote: "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0438 \u0441\u043C\u0435\u043D\u0435 \u0441\u0442\u0430\u0442\u0443\u0441\u0430 \u0441\u0434\u0435\u043B\u043A\u0438. \u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u2192 \u043E\u0434\u043D\u043E \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0435. \xAB\u041F\u043E\u0437\u0436\u0435\xBB \u043F\u0440\u044F\u0447\u0435\u0442 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u043D\u0430 15 \u043C\u0438\u043D\u0443\u0442. \xAB\u0421\u043A\u0440\u044B\u0442\u044C \u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0443\xBB \u0433\u043B\u0443\u0448\u0438\u0442 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u0434\u043E \u043A\u043E\u043D\u0446\u0430 \u0441\u0434\u0435\u043B\u043A\u0438.",
      supportEmergency: "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \xB7 \u0430\u0432\u0430\u0440\u0438\u0439\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F",
      apiKeyNote: "\u041D\u0435 \u0434\u043B\u044F \u043E\u0431\u044B\u0447\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u044B. \u0412\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u043A\u043B\u044E\u0447 \u0442\u043E\u043B\u044C\u043A\u043E \u0435\u0441\u043B\u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 R.I.P Market \u044F\u0432\u043D\u043E \u043F\u043E\u043F\u0440\u043E\u0441\u0438\u043B\u0430 \u2014 \u0438 \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 \u0432\u0440\u0435\u043C\u044F \u0441\u0431\u043E\u044F Steam.",
      apiKeyLabel: "\u0417\u0430\u043F\u0430\u0441\u043D\u043E\u0439 Steam Web API key",
      apiKeyPlaceholder: "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u043E \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0438",
      apiKeySave: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",
      apiKeyClear: "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C",
      apiKeyStatusSaved: "\u041A\u043B\u044E\u0447 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E; \u0434\u043E\u0441\u0442\u0443\u043F \u043A api.steampowered.com \u0432\u044B\u0434\u0430\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F fallback.",
      apiKeyStatusEmpty: "\u041A\u043B\u044E\u0447 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D \u2014 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u0432\u0430\u0448\u0443 \u0441\u0435\u0441\u0441\u0438\u044E Steam \u0432 Chrome.",
      apiKeyPermissionDenied: "Chrome \u043D\u0435 \u0432\u044B\u0434\u0430\u043B \u0434\u043E\u0441\u0442\u0443\u043F \u043A api.steampowered.com \u2014 \u043A\u043B\u044E\u0447 \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D.",
      permissionsTitle: "\u0417\u0430\u0447\u0435\u043C \u043D\u0443\u0436\u043D\u044B \u043F\u0440\u0430\u0432\u0430",
      languageLabel: "\u042F\u0437\u044B\u043A \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u0430",
      languageRu: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
      languageEn: "English",
      languageHint: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0441 \u0441\u0430\u0439\u0442\u043E\u043C \u043F\u0440\u0438 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0438; \u043C\u043E\u0436\u043D\u043E \u0441\u043C\u0435\u043D\u0438\u0442\u044C \u0437\u0434\u0435\u0441\u044C.",
      buyersTitle: "\u041F\u043E\u043A\u0443\u043F\u043A\u0438",
      buyersSub: "\u0416\u0434\u0451\u043C \u043E\u0444\u0444\u0435\u0440 \xB7 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F",
      sellersTitle: "\u041F\u0440\u043E\u0434\u0430\u0436\u0438",
      sellersSub: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435 \xB7 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438",
      receiptsTitle: "\u041D\u0435\u0434\u0430\u0432\u043D\u0438\u0435 \u0441\u0434\u0435\u043B\u043A\u0438",
      receiptsSub: "\u041A\u0440\u0430\u0442\u043A\u0438\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \xB7 \u0434\u0435\u0442\u0430\u043B\u0438 \u043F\u043E \u043A\u043B\u0438\u043A\u0443",
      receiptsAllOnSite: "\u0412\u0441\u0435 \u0441\u0434\u0435\u043B\u043A\u0438 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      receiptsMoreOnSite: "\u0415\u0449\u0451 {{count}} \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      actionTitle: "\u041D\u0443\u0436\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435",
      actionSub: "\u041E\u0434\u0438\u043D \u0433\u043B\u0430\u0432\u043D\u044B\u0439 \u0448\u0430\u0433 \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435",
      snoozeLater: "\u041F\u043E\u0437\u0436\u0435",
      emptyTitle: "\u0412\u0441\u0451 \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u043E",
      emptyBody: "\u041D\u0435\u0442 \u0441\u0434\u0435\u043B\u043E\u043A, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u044F\u043C\u043E \u0441\u0435\u0439\u0447\u0430\u0441."
    },
    safeMode: {
      offlineTitle: "\u0421\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u0430 \xB7 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C",
      offlineBody: "\u0421\u0430\u0439\u0442 \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435 \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0442\u044C\u0441\u044F, \u043D\u043E API \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u041F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u043C \u043A\u044D\u0448; \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043E\u0444\u0444\u0435\u0440\u043E\u0432 \u0441 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B, \u043F\u043E\u043A\u0430 \u0441\u0432\u044F\u0437\u044C \u043D\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0441\u044F.",
      degradedTitle: "\u0421\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430",
      degradedBody: "\u041A\u044D\u0448 \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435. \u0412\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u2014 Guard \u0438\u043B\u0438 Accept \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Steam, \u0435\u0441\u043B\u0438 \u043E\u0444\u0444\u0435\u0440 \u0443\u0436\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D.",
      cacheLine: "\u041A\u044D\u0448 \u0441\u0434\u0435\u043B\u043E\u043A \xB7 {{when}}",
      cacheEmpty: "\u041A\u044D\u0448\u0430 \u0441\u0434\u0435\u043B\u043E\u043A \u043F\u043E\u043A\u0430 \u043D\u0435\u0442 \u2014 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435, \u043A\u043E\u0433\u0434\u0430 API \u043E\u0436\u0438\u0432\u0451\u0442.",
      hint: "\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C: list \u0438 send \u0441 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B.",
      waitCta: "\u0416\u0434\u0451\u043C \u0441\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C",
      blockMessage: "API \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0438\u043B\u0438 \u0441\u0432\u044F\u0437\u044C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430 \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043E\u0444\u0444\u0435\u0440\u043E\u0432 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B (\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C)."
    },
    cta: {
      openDispute: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440",
      openDisputeSupport: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440 / \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437",
      confirmGuard: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile",
      openTradeUrl: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C Trade URL",
      retrySend: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      retryAutoSend: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0430\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      confirmSent: "\u042F \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043B \u043E\u0431\u043C\u0435\u043D",
      openVerifiedOffer: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440",
      openVerifiedOfferSteam: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u0432 Steam",
      preAcceptAck: "\u0412\u0438\u0436\u0443 \u0432\u0435\u0440\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435",
      problemSupport: "\u041F\u0440\u043E\u0431\u043B\u0435\u043C\u0430 \u0441 \u043E\u0431\u043C\u0435\u043D\u043E\u043C",
      confirmReceived: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u043C\u0435\u043D\u044F",
      openOfferSteam: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u0444\u0444\u0435\u0440 \u0432 Steam",
      platformStatus: "\u0421\u0442\u0430\u0442\u0443\u0441 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      refreshStatus: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0430\u0442\u0443\u0441",
      waitSeller: "\u0416\u0434\u0451\u043C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      open: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C",
      openAccount: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442",
      loginNeededSteam: "\u0412\u043E\u0439\u0442\u0438 \u0432 \u043D\u0443\u0436\u043D\u044B\u0439 Steam",
      loginSteam: "\u0412\u043E\u0439\u0442\u0438 \u0432 Steam",
      openSteamInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam"
    },
    nextAction: {
      hintDisputeOpen: "\u0421\u043F\u043E\u0440 \u0443\u0436\u0435 \u043E\u0442\u043A\u0440\u044B\u0442 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0443\u0439\u0434\u0451\u0442 \u0432 \u0442\u0438\u043A\u0435\u0442. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u0438\u0435 \u043E\u0444\u0444\u0435\u0440\u044B.",
      hintMismatch: "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u0432 Steam. \u0414\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u0441\u044F \u0432 \u0442\u0438\u043A\u0435\u0442.",
      hintGuard: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 Guard \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u044B \u0432 Steam Mobile.",
      hintManualWithUrl: "\u041E\u0442\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0441\u043A\u0438\u043D \u0432\u0440\u0443\u0447\u043D\u0443\u044E, \u0437\u0430\u0442\u0435\u043C \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 offerId \u043D\u0430 \u0437\u0430\u043A\u0430\u0437\u0435.",
      hintManualRetry: "\u0410\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043D\u0435 \u0441\u043C\u043E\u0433\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C\u0441\u044F \u2014 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437.",
      hintAccept: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Accept \u0432 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043E\u0444\u0444\u0435\u0440\u0430.",
      hintConfirmReceived: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u043D\u0430 \u0441\u0430\u0439\u0442 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.",
      hintVerifying: "\u041F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u0441\u0432\u0435\u0440\u044F\u0435\u0442 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443 \u2014 \u043E\u0431\u044B\u0447\u043D\u043E \u043D\u0438\u0447\u0435\u0433\u043E \u0434\u0435\u043B\u0430\u0442\u044C \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.",
      hintWaitSeller: "\u041A\u0430\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0444\u0444\u0435\u0440 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u2014 \u0437\u0434\u0435\u0441\u044C \u0431\u0443\u0434\u0435\u0442 \u043A\u043D\u043E\u043F\u043A\u0430 \u043F\u0440\u0438\u043D\u044F\u0442\u044C.",
      hintWaitBuyer: "\u041E\u0431\u043C\u0435\u043D \u0443 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F. \u0421\u0442\u0430\u0442\u0443\u0441 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0441\u0430\u043C \u043F\u043E\u0441\u043B\u0435 Accept."
    },
    dealConfirm: {
      acceptTitle: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u0432 Steam",
      acceptBody: "\u0421\u0432\u0435\u0440\u044C\u0442\u0435 \u0449\u0438\u0442 \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 Accept. \u041C\u044B \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C \u0437\u0430 \u0432\u0430\u0441.",
      receivedTitle: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u0432\u0430\u0441?",
      receivedBody: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u0441\u0442\u0430\u0442\u0443\u0441 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0441\u0430\u043C.",
      verifyingTitle: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      verifyingBody: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C Steam \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C. \u041E\u0431\u044B\u0447\u043D\u043E \u0436\u0434\u0430\u0442\u044C \u043D\u0435\u0434\u043E\u043B\u0433\u043E.",
      doneTitle: "\u0413\u043E\u0442\u043E\u0432\u043E",
      doneBody: "\u0421\u0434\u0435\u043B\u043A\u0430 \u0443 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438. \u0417\u0430\u043A\u0430\u0437 \u043C\u043E\u0436\u043D\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438.",
      guardTitle: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile",
      guardBody: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443 \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438 Steam. \u0415\u0441\u043B\u0438 \u0441\u0442\u0430\u0442\u0443\u0441 \u0437\u0430\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F, \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435."
    },
    badge: {
      rePair: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      steam: "Steam",
      inventory: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C",
      guard: "Guard",
      accept: "Accept",
      mismatch: "Mismatch",
      sendManual: "\u0412\u0440\u0443\u0447\u043D\u0443\u044E",
      confirmSent: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C",
      confirmReceived: "\u041F\u043E\u043B\u0443\u0447\u0435\u043D\u043E",
      reportIssue: "\u041F\u0440\u043E\u0431\u043B\u0435\u043C\u0430"
    },
    connection: {
      revokedTitle: "\u0421\u0435\u0441\u0441\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u0430",
      revokedDetail: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430.",
      offTitle: "\u041D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u043A \u0441\u0430\u0439\u0442\u0443",
      offDetail: "\u0421\u0430\u0439\u0442 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442 \u2014 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB (\u044D\u0442\u043E \u043D\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 Chrome).",
      steamUnknown: "Steam: \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E",
      mismatchTitle: "\u0421\u0430\u0439\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \xB7 \u0434\u0440\u0443\u0433\u043E\u0439 Steam",
      mismatchDetail: "Steam \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      noSteamTitle: "\u0421\u0430\u0439\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \xB7 \u043D\u0435\u0442 \u0432\u0445\u043E\u0434\u0430 \u0432 Steam",
      noSteamDetail: "Steam: \u043D\u0435\u0442 \u0441\u0435\u0441\u0441\u0438\u0438",
      connectedUntil: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u0434\u043E {{expires}}",
      connectedOkTitle: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \xB7 \u0441\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442",
      inventoryIssueTitle: "Steam \u043E\u043A \xB7 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u0441 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u043E\u0439",
      connectedTitle: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      connectedDetail: "\u0421\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442 \u2014 \u043C\u043E\u0436\u043D\u043E \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0441\u043E \u0441\u0434\u0435\u043B\u043A\u0430\u043C\u0438.",
      steamAligned: "\u0421\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442"
    },
    buyerPhase: {
      wait_offer: "\u0416\u0434\u0451\u043C \u043E\u0444\u0444\u0435\u0440",
      accept: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C",
      verifying: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F",
      dispute: "\u0421\u043F\u043E\u0440 / \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430"
    },
    timeout: {
      expired: "\u0412\u0440\u0435\u043C\u044F \u043D\u0430 \u043E\u0431\u043C\u0435\u043D \u0438\u0441\u0442\u0435\u043A\u043B\u043E \u2014 \u0441\u043A\u043E\u0440\u043E \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0442\u044C\u0441\u044F \u0441\u043F\u043E\u0440",
      minutes: "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ~{{minutes}} \u043C\u0438\u043D \u0434\u043E \u0430\u0432\u0442\u043E\u0441\u043F\u043E\u0440\u0430",
      hoursMinutes: "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ~{{hours}} \u0447 {{minutes}} \u043C\u0438\u043D \u0434\u043E \u0430\u0432\u0442\u043E\u0441\u043F\u043E\u0440\u0430"
    },
    settlement: {
      soonSuffix: "{{formatted}} (\u0441\u043A\u043E\u0440\u043E)",
      offerOk: "Steam offer: \u043F\u0440\u0438\u043D\u044F\u0442",
      offerWarn: "Steam offer: \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430",
      offerPending: "Steam offer: \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C",
      offerUnknown: "Steam offer: \u0443\u0442\u043E\u0447\u043D\u044F\u0435\u043C",
      invOk: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0441\u043A\u0438\u043D \u0443 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F",
      invWarn: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0435\u0449\u0451 \u0443 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      invPending: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C",
      invUnknown: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0443\u0442\u043E\u0447\u043D\u044F\u0435\u043C",
      deliveryTitleSeller: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      deliveryTitleBuyer: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u0432\u0430\u0441 \u2014 \u0441\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      deliveryBodySeller: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C Steam offer \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C. \u041D\u043E\u0432\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u043F\u043E \u044D\u0442\u043E\u0439 \u0441\u0434\u0435\u043B\u043A\u0435 \u043D\u0435 \u043D\u0443\u0436\u0435\u043D.",
      deliveryBodyBuyer: "\u041D\u0438\u0447\u0435\u0433\u043E \u0434\u0435\u043B\u0430\u0442\u044C \u043D\u0435 \u043D\u0443\u0436\u043D\u043E \u2014 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u0441\u0432\u0435\u0440\u044F\u0435\u0442 Steam offer \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C.",
      fundsSellerKnown: "\u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0431\u0443\u0434\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B: {{date}}",
      fundsSellerUnknown: "\u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0431\u0443\u0434\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 (\u0434\u043E {{days}} \u0434\u043D.)",
      fundsBuyerKnown: "\u0412\u044B\u043F\u043B\u0430\u0442\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u0441: {{date}}",
      fundsBuyerUnknown: "\u0412\u044B\u043F\u043B\u0430\u0442\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 (\u0434\u043E {{days}} \u0434\u043D.)",
      holdTitleSeller: "\u0412\u044B\u0440\u0443\u0447\u043A\u0430 \u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0435",
      holdTitleBuyer: "\u0421\u043A\u0438\u043D \u0432\u0430\u0448 \u2014 \u0440\u0430\u0441\u0447\u0451\u0442 \u0443 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438",
      holdBodySeller: "\u0417\u0430\u0449\u0438\u0442\u0430 \u043E\u0442 chargeback \u0438 \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u0430 \u043E\u0431\u043C\u0435\u043D\u0430 \u0432 Steam. \u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0441\u0442\u0430\u043D\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u043F\u043E\u0441\u043B\u0435 \u043F\u0435\u0440\u0438\u043E\u0434\u0430 \u0437\u0430\u0449\u0438\u0442\u044B.",
      holdBodyBuyer: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0432 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u0435. \u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u2014 \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435."
    },
    dispute: {
      openTitle: "\u0421\u043F\u043E\u0440 \u043E\u0442\u043A\u0440\u044B\u0442",
      openBody: "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \u0440\u0430\u0437\u0431\u0438\u0440\u0430\u0435\u0442 \u0441\u0434\u0435\u043B\u043A\u0443. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u0438\u0435 \u043E\u0444\u0444\u0435\u0440\u044B \u043F\u043E \u044D\u0442\u043E\u043C\u0443 \u0437\u0430\u043A\u0430\u0437\u0443 \u0438 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442\u0435 \u0434\u0435\u043D\u044C\u0433\u0438 \u0432 \u0447\u0430\u0442.",
      needTitle: "\u041D\u0443\u0436\u0435\u043D \u0441\u043F\u043E\u0440",
      needMismatch: "\u041E\u0444\u0444\u0435\u0440 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u041D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435 Accept \u2014 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u043F\u043E\u0440 \u0441 \u0434\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438.",
      needGeneric: "\u0415\u0441\u0442\u044C \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430 \u043F\u043E \u0441\u0434\u0435\u043B\u043A\u0435. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u043F\u043E\u0440 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u0441\u044F \u0432 \u0442\u0438\u043A\u0435\u0442 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438.",
      ticketPlaceholder: "(\u043E\u043F\u0438\u0448\u0438\u0442\u0435, \u0447\u0442\u043E \u043F\u043E\u0448\u043B\u043E \u043D\u0435 \u0442\u0430\u043A)"
    },
    receipt: {
      eyebrow: "\u041A\u0432\u0438\u0442\u0430\u043D\u0446\u0438\u044F",
      bought: "\u041A\u0443\u043F\u0438\u043B\u0438",
      sold: "\u041F\u0440\u043E\u0434\u0430\u043B\u0438",
      price: "\u0426\u0435\u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0438",
      commission: "\u041A\u043E\u043C\u0438\u0441\u0441\u0438\u044F \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 (5%)",
      paid: "\u041E\u043F\u043B\u0430\u0442\u0438\u043B\u0438",
      credited: "\u041A \u0437\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044E",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437"
    },
    session: {
      okTitle: "\u0413\u043E\u0442\u043E\u0432\u043E \u043A \u0441\u0434\u0435\u043B\u043A\u0430\u043C",
      okMessage: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0438 Steam \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u044B.",
      disconnectedTitle: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      disconnectedMessage: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0430\u0439\u0442 \u2192 \u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB.",
      disconnectedCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      revokedTitle: "\u0421\u0435\u0441\u0441\u0438\u044F \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u0430",
      revokedMessage: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430.",
      revokedCta: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      cookieTitle: "\u041D\u0435\u0442 \u0432\u0445\u043E\u0434\u0430 \u0432 Steam",
      cookieMessage: "\u0412\u043E\u0439\u0434\u0438\u0442\u0435 \u0432 steamcommunity.com \u0432 \u044D\u0442\u043E\u043C Chrome \u043F\u043E\u0434 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u043E\u043C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430.",
      cookieCta: "\u0412\u043E\u0439\u0442\u0438 \u0432 Steam",
      mismatchTitle: "\u0414\u0440\u0443\u0433\u043E\u0439 Steam \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435",
      mismatchMessage: "\u0412 Chrome \u0437\u0430\u043B\u043E\u0433\u0438\u043D\u0435\u043D {{session}}, \u043D\u0443\u0436\u0435\u043D {{expected}}",
      mismatchCta: "\u0412\u043E\u0439\u0442\u0438 \u0432 \u043D\u0443\u0436\u043D\u044B\u0439 Steam",
      privateTitle: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u0441\u043A\u0440\u044B\u0442",
      privateMessage: "\u0421\u0434\u0435\u043B\u0430\u0439\u0442\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2 \u0432\u0438\u0434\u0438\u043C\u044B\u043C \u0434\u043B\u044F \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F (Privacy \u2192 Inventory: Public).",
      privateCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 Steam",
      rateTitle: "Steam \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0438\u043B \u0437\u0430\u043F\u0440\u043E\u0441\u044B",
      rateMessage: "\u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 1\u20132 \u043C\u0438\u043D\u0443\u0442\u044B \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0441\u043D\u043E\u0432\u0430\xBB. \u041A\u043B\u044E\u0447 Steam \u043D\u0435 \u043D\u0443\u0436\u0435\u043D \u2014 \u043F\u0440\u0438 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u043C \u0441\u0431\u043E\u0435 \u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 \u0432 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443.",
      rateCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam",
      inventoryTitle: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u043B\u0441\u044F",
      inventoryMessage: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2 \u0432 Steam \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443.",
      inventoryCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam"
    },
    notify: {
      guardTitle: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430 \u2014 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 Guard",
      guardBody: "{{short}} \xB7 {{item}}. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 Steam Mobile \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D.",
      acceptTitle: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430 \u2014 \u043E\u0444\u0444\u0435\u0440 \u0433\u043E\u0442\u043E\u0432 \u043A accept",
      acceptBody: "{{short}} \xB7 {{item}}. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u0432 Steam.",
      mismatchTitle: "Mismatch \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      mismatchBody: "{{short}} \xB7 {{item}}. \u0421\u043A\u0438\u043D \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u2014 \u043D\u0435 \u0436\u043C\u0438\u0442\u0435 Accept.",
      newDealTitle: "\u041D\u043E\u0432\u0430\u044F \u043F\u0440\u043E\u0434\u0430\u0436\u0430 \u2014 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u043C \u043E\u0431\u043C\u0435\u043D",
      newDealBody: "{{short}} \xB7 {{item}}. \u041E\u0441\u0442\u0430\u0432\u044C\u0442\u0435 Steam \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u043C \u2014 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442 offer.",
      groupMismatch: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E mismatch \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      groupGuard: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E\u0434\u0430\u0436 \u0436\u0434\u0443\u0442 Guard",
      groupAccept: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u043A\u0443\u043F\u043E\u043A \u0436\u0434\u0443\u0442 accept",
      groupNewDeal: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043D\u043E\u0432\u044B\u0445 \u043F\u0440\u043E\u0434\u0430\u0436",
      groupBody: "{{count}} \u0441\u0434\u0435\u043B\u043A\u0438 \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F",
      muteDeal: "\u0421\u043A\u0440\u044B\u0442\u044C \u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0443"
    },
    cardContext: {
      buy: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430",
      sell: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430",
      dispute: "\u0421\u043F\u043E\u0440",
      mismatch: "\u041D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      waitGuard: "\u0416\u0434\u0451\u043C Guard",
      waitAccept: "\u0416\u0434\u0451\u0442 Accept",
      sendManual: "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0432\u0440\u0443\u0447\u043D\u0443\u044E",
      confirmSent: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      confirmReceived: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u0435",
      platformCheck: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438",
      completed: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E",
      offerReady: "\u041E\u0444\u0444\u0435\u0440 \u0433\u043E\u0442\u043E\u0432",
      waitBuyer: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F",
      checking: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u2026",
      waitTrade: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043E\u0431\u043C\u0435\u043D",
      tradeConfirmed: "\u041E\u0431\u043C\u0435\u043D \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D",
      hold: "Hold / \u0440\u0430\u0441\u0447\u0451\u0442",
      failed: "\u0412\u043E\u0437\u0432\u0440\u0430\u0442",
      canceled: "\u041E\u0442\u043C\u0435\u043D\u0451\u043D",
      inProgress: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435"
    },
    guided: {
      mismatchTitle: "\u041D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      mismatchBuyer: "\u042D\u0442\u043E\u0442 offer \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C R.I.P Market. \u041D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435 Accept \u0432 Steam.",
      mismatchSeller: "Offer \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u0438 \u043D\u0435 \u043F\u0440\u043E\u0441\u0438\u0442\u0435 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C.",
      verifiedTitle: "\u0421\u043A\u0438\u043D \u0441\u043E\u0432\u043F\u0430\u043B",
      verifiedBuyer: "\u041C\u043E\u0436\u043D\u043E \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435. \u0414\u0435\u043D\u044C\u0433\u0438 \u0443\u0436\u0435 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435 \u2014 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442\u0435 \u0432 \u0447\u0430\u0442.",
      verifiedSeller: "\u041E\u0431\u043C\u0435\u043D \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u0414\u0430\u043B\u044C\u0448\u0435 \u043F\u043E next step \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 / Guard.",
      partialTitle: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u2026",
      partialBody: "\u0427\u0430\u0441\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043E\u043A \u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430. \u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u2014 Accept \u043F\u043E\u043A\u0430 \u043D\u0435 \u0442\u043E\u0440\u043E\u043F\u0438\u0442\u0435.",
      pendingTitle: "\u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438",
      pendingBody: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C offer \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C R.I.P Market.",
      name: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435",
      stickers: "\u0421\u0442\u0438\u043A\u0435\u0440\u044B",
      partner: "\u041F\u0430\u0440\u0442\u043D\u0451\u0440 SteamID",
      assetId: "Asset ID",
      wear: "\u0418\u0437\u043D\u043E\u0441",
      float: "Float",
      hintBlock: "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u044D\u0442\u043E\u0442 \u043E\u0431\u043C\u0435\u043D \u0432 Steam",
      hintAccept: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435",
      hintWait: "\u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u2014 Accept \u043F\u043E\u043A\u0430 \u043D\u0435 \u0442\u043E\u0440\u043E\u043F\u0438\u0442\u0435"
    },
    offerGate: {
      needCs2Title: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 CS2",
      needCs2Body: "\u0412 \u0441\u043F\u0438\u0441\u043A\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044F \u0441\u043B\u0435\u0432\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 Counter-Strike 2. \u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u0430\u043C\u043E \u0434\u043E\u0431\u0430\u0432\u0438\u0442 \u0441\u043A\u0438\u043D \u0441\u0434\u0435\u043B\u043A\u0438.",
      needItemTitle: "\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0441\u043A\u0438\u043D \u0432 \u043E\u0431\u043C\u0435\u043D",
      needItemBody: "\u041D\u0443\u0436\u043D\u044B\u0439 \u043F\u0440\u0435\u0434\u043C\u0435\u0442: {{name}}. \u041A\u043B\u0438\u043A\u043D\u0438\u0442\u0435 \u0435\u0433\u043E \u0432 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u0435 \u2014 \u043E\u043D \u0434\u043E\u043B\u0436\u0435\u043D \u043F\u043E\u044F\u0432\u0438\u0442\u044C\u0441\u044F \u0432 \xAB\u0412\u0430\u0448\u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B\xBB.",
      itemReadyTitle: "\u0421\u043A\u0438\u043D \u0432 \u043E\u0431\u043C\u0435\u043D\u0435",
      itemReadyBody: "\u0421\u0432\u0435\u0440\u044C\u0442\u0435 \u0449\u0438\u0442 \u0441\u043F\u0440\u0430\u0432\u0430 \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0438\u0442\u044C \u043E\u0431\u043C\u0435\u043D\xBB \u0432 Steam. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438."
    },
    shield: {
      dealLine: "\u0417\u0430\u043A\u0430\u0437 #{{short}} \xB7 {{amount}}",
      wear: "\u0418\u0437\u043D\u043E\u0441",
      float: "Float",
      stickers: "\u0421\u0442\u0438\u043A\u0435\u0440\u044B",
      unknownPartner: "\u041A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442",
      partnerMatch: "Steam-\u043F\u0430\u0440\u0442\u043D\u0451\u0440 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      partnerMismatch: "Steam-\u043F\u0430\u0440\u0442\u043D\u0451\u0440 \u041D\u0415 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      partnerMissingObserved: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u0447\u0438\u0442\u0430\u0442\u044C \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B Steam",
      partnerMissingExpected: "\u0412 \u0437\u0430\u043A\u0430\u0437\u0435 \u043D\u0435\u0442 SteamID \u043A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442\u0430",
      partnerUnknown: "\u041F\u0430\u0440\u0442\u043D\u0451\u0440 \u043D\u0435 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D",
      partnerMatchCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C",
      partnerMismatchCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C",
      partnerMissingObservedCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D",
      partnerMissingExpectedCheck: "\u0412 \u0437\u0430\u043A\u0430\u0437\u0435 \u043D\u0435\u0442 SteamID \u043A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442\u0430",
      copySteamId: "\u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C",
      copied: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E",
      openProfile: "\u041F\u0440\u043E\u0444\u0438\u043B\u044C Steam",
      steamIdMissing: "SteamID \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D",
      expectedCol: "\u041E\u0436\u0438\u0434\u0430\u0435\u043C",
      observedCol: "\u0412 \u043E\u0444\u0444\u0435\u0440\u0435",
      preSendTitle: "\u041F\u0435\u0440\u0435\u0434 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u043E\u0439",
      preSendBody: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Steam Mobile.",
      compareTitle: "\u0421\u0432\u0435\u0440\u043A\u0430 \u0441 Steam"
    },
    acceptAssist: {
      acceptSteam: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C (Steam)",
      confirmAccept: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C Accept \u0432 Steam",
      cancel: "\u041E\u0442\u043C\u0435\u043D\u0430",
      openVerified: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 #{{short}} \u0438 \u043F\u0440\u0438\u043D\u044F\u0442\u044C \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam",
      acceptNotFound: "\u041A\u043D\u043E\u043F\u043A\u0430 Accept \u0432 Steam \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E Accept \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0432\u0440\u0443\u0447\u043D\u0443\u044E.",
      acceptClickFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043D\u0430\u0436\u0430\u0442\u044C Accept. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u0432\u0440\u0443\u0447\u043D\u0443\u044E.",
      doubleConfirm: "\u0415\u0449\u0451 \u0440\u0430\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u043E\u0433\u0434\u0430 \u043D\u0430\u0436\u043C\u0451\u043C Accept \u0432 Steam. \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u043E\u043C \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C.",
      guardHint: "\u0415\u0441\u043B\u0438 Steam \u043F\u043E\u043F\u0440\u043E\u0441\u0438\u0442 Guard \u2014 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile.",
      confirmAgain: "\u0415\u0441\u043B\u0438 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F Confirm \u2014 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437 \xAB\u041F\u0440\u0438\u043D\u044F\u0442\u044C (Steam)\xBB, \u043B\u0438\u0431\u043E Confirm \u0432 Steam.",
      commandSent: "\u041A\u043E\u043C\u0430\u043D\u0434\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0430 \u0432 Steam. {{guardHint}}",
      assistFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043C\u043E\u0447\u044C \u0441 Accept. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435.",
      highlightHint: "\u041F\u043E\u0434\u0441\u0432\u0435\u0442\u0438\u043C \u043A\u043D\u043E\u043F\u043A\u0443 Steam. Accept \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0441\u043B\u0435 \u0432\u0430\u0448\u0435\u0433\u043E \u0432\u0442\u043E\u0440\u043E\u0433\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F."
    },
    manualCreate: {
      buildOffer: "\u0421\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440 #{{short}}",
      autoFailed: "\u0410\u0432\u0442\u043E \u043D\u0435 \u0441\u043C\u043E\u0433 \u2014 \u0441\u043E\u0431\u0435\u0440\u0451\u043C \u043E\u0444\u0444\u0435\u0440 \u0447\u0435\u0440\u0435\u0437 Steam UI: \u043F\u0440\u0435\u0434\u043C\u0435\u0442 + Trade URL \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F.",
      canBuild: "\u041C\u043E\u0436\u043D\u043E \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440 \u0432\u0440\u0443\u0447\u043D\u0443\u044E \u0447\u0435\u0440\u0435\u0437 \u0442\u043E\u0442 \u0436\u0435 autofill, \u0447\u0442\u043E \u0438 \u0430\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430."
    },
    ops: {
      never: "\u0435\u0449\u0451 \u043D\u0435 \u0431\u044B\u043B\u043E",
      justNow: "\u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E",
      secondsAgo: "{{seconds}} \u0441\u0435\u043A \u043D\u0430\u0437\u0430\u0434",
      minutesAgo: "{{minutes}} \u043C\u0438\u043D \u043D\u0430\u0437\u0430\u0434",
      hoursAgo: "{{hours}} \u0447 \u043D\u0430\u0437\u0430\u0434",
      pollStale: "\u041E\u043F\u0440\u043E\u0441 \u0443\u0441\u0442\u0430\u0440\u0435\u043B \xB7 {{age}}",
      pollNever: "\u041E\u043F\u0440\u043E\u0441: \u0435\u0449\u0451 \u043D\u0435 \u0431\u044B\u043B\u043E \u0443\u0441\u043F\u0435\u0448\u043D\u043E\u0433\u043E",
      pollOld: "\u041E\u043F\u0440\u043E\u0441 \u0434\u0430\u0432\u043D\u043E \xB7 {{age}}",
      pollOk: "\u041E\u043F\u0440\u043E\u0441: {{age}}",
      rateLimited: "Steam: rate limit \u2014 \u043F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 1\u20132 \u043C\u0438\u043D",
      rateOk: "Steam: \u0431\u0435\u0437 rate limit",
      version: "\u0412\u0435\u0440\u0441\u0438\u044F {{version}}",
      updateExtension: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435"
    },
    onboarding: {
      coachTitle: "\u041F\u0440\u043E\u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u043D\u0430 R.I.P \u043F\u0440\u044F\u043C\u043E \u043E\u0442\u0441\u044E\u0434\u0430",
      coachBody: "\u0412\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0441\u044E\u0434\u0430 \u2014 \u043E\u0431\u043C\u0435\u043D \u043F\u0440\u0438 \u043F\u043E\u043A\u0443\u043F\u043A\u0435 \u0443\u0439\u0434\u0451\u0442 \u0441\u0430\u043C. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u044B \u0432 Steam Mobile.",
      coachDismiss: "\u041F\u043E\u043D\u044F\u0442\u043D\u043E",
      autoHideHint: "\u0421\u043A\u0440\u043E\u0435\u0442\u0441\u044F \u0447\u0435\u0440\u0435\u0437 ~30 \u0441\u0435\u043A",
      extensionReady: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      extensionHint: "\u041F\u0430\u0440\u0430 \u0441 \u0441\u0430\u0439\u0442\u043E\u043C \u043D\u0443\u0436\u043D\u0430 \u0434\u043B\u044F \u0446\u0435\u043D, \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0438 \u0438 \u0430\u0432\u0442\u043E-\u043E\u0431\u043C\u0435\u043D\u0430.",
      extensionAction: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      tradeUrlTitle: "Trade URL \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      tradeUrlHint: "\u0411\u0435\u0437 Trade URL \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u0438 \u043D\u0435 \u0441\u043C\u043E\u0433\u0443\u0442 \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043E\u0431\u043C\u0435\u043D \u043F\u043E\u0441\u043B\u0435 \u043E\u043F\u043B\u0430\u0442\u044B.",
      tradeUrlAction: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C Trade URL",
      checklistTitle: "\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      checklistReady: "\u0412\u0441\u0451 \u0433\u043E\u0442\u043E\u0432\u043E \u2014 \u043C\u043E\u0436\u043D\u043E \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u0438\u0437 Steam",
      checklistProgress: "\u0413\u043E\u0442\u043E\u0432\u043E {{ready}} \u0438\u0437 {{total}}"
    },
    twoMin: {
      title: "\u0421\u0442\u0430\u0440\u0442",
      lead: "\u0427\u0435\u0442\u044B\u0440\u0435 \u0448\u0430\u0433\u0430 \u2014 \u0438 \u0441\u0434\u0435\u043B\u043A\u0438 \u0438\u0434\u0443\u0442 \u0441\u0430\u043C\u0438.",
      progress: "{{ready}} / {{total}}",
      stepInstall: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E",
      hintInstall: "\u0412\u044B \u0443\u0436\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u044D\u0442\u043E\u0442 \u0448\u0430\u0433 \u0433\u043E\u0442\u043E\u0432.",
      stepPair: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043A \u0441\u0430\u0439\u0442\u0443",
      hintPair: "\u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB \u043D\u0430 p2pcs.ru.",
      stepInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2",
      hintInventory: "Steam Community \u2192 Inventory \u2192 Counter-Strike 2.",
      stepList: "\u041F\u0440\u043E\u0431\u043D\u044B\u0439 list",
      hintList: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043A\u0438\u043D \u2192 \u0441\u0438\u043D\u044F\u044F \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435. Guard \u043F\u043E\u0442\u043E\u043C \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Mobile.",
      ctaPair: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      ctaInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2",
      ctaList: "\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u0435\u0440\u0432\u044B\u0439 \u0441\u043A\u0438\u043D",
      ctaDone: "\u0413\u043E\u0442\u043E\u0432\u043E",
      dismiss: "\u041F\u043E\u0437\u0436\u0435",
      trialTitle: "\u041F\u0440\u043E\u0431\u043D\u044B\u0439 list (~30 \u0441\u0435\u043A)",
      trialBody: "\u041D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435 \u0441\u043A\u0438\u043D\u0430 \u0432 \u0441\u0435\u0442\u043A\u0435 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0441\u0438\u043D\u044E\u044E \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB (\u043D\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u0441\u043F\u0440\u0430\u0432\u0430). \u042D\u0442\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u0443\u0442\u0438 \u2014 \u043D\u0435 \u0442\u0435\u0441\u0442-\u0434\u0435\u043D\u044C\u0433\u0438.",
      trialDismiss: "\u0421\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0443"
    },
    overlay: {
      brand: "R.I.P Market",
      openDispute: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440",
      openDisputeSupport: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440 / \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437"
    },
    inventory: {
      layerBrand: "R.I.P Market",
      steamEnrichmentDegraded: "\u0427\u0430\u0441\u0442\u044C float/\u0446\u0435\u043D Steam \u0435\u0449\u0451 \u043F\u043E\u0434\u0433\u0440\u0443\u0436\u0430\u0435\u0442\u0441\u044F \u2014 \u0441\u0438\u043D\u044F\u044F \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430\u0445 \u0443\u0436\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430."
    }
  };

  // src/shared/extension-i18n.ts
  var messagesByLocale = {
    ru: extensionMessagesRu,
    en: extensionMessagesEn
  };
  function tx(locale, key, params) {
    return translateExtension(messagesByLocale[locale], key, params);
  }
  function createExtensionT(locale) {
    return (key, params) => tx(locale, key, params);
  }

  // src/shared/extension-ops-health.ts
  var POLL_STALE_ERROR_MS = 5 * 6e4;
  var RATE_LIMIT_ACTIVE_WINDOW_MS = 2 * 6e4;

  // src/shared/offline-safe-mode.ts
  var SITE_LINK_STORAGE_KEY = "rip:siteLink";
  function defaultSiteLinkSnapshot(nowMs = Date.now()) {
    return {
      mode: "offline",
      safeMode: true,
      fromCache: false,
      cacheUpdatedAt: null,
      lastError: null,
      checkedAt: new Date(nowMs).toISOString()
    };
  }
  async function getStoredSiteLinkSnapshot() {
    try {
      if (typeof chrome === "undefined" || !chrome.storage?.local?.get) {
        return defaultSiteLinkSnapshot();
      }
      const stored = await chrome.storage.local.get(SITE_LINK_STORAGE_KEY);
      const raw = stored[SITE_LINK_STORAGE_KEY];
      if (!raw || typeof raw !== "object") {
        return defaultSiteLinkSnapshot();
      }
      const record = raw;
      const mode = record.mode === "live" || record.mode === "degraded" || record.mode === "offline" ? record.mode : "offline";
      return {
        mode,
        safeMode: mode !== "live",
        fromCache: Boolean(record.fromCache),
        cacheUpdatedAt: typeof record.cacheUpdatedAt === "string" ? record.cacheUpdatedAt : null,
        lastError: typeof record.lastError === "string" ? record.lastError : null,
        checkedAt: typeof record.checkedAt === "string" ? record.checkedAt : (/* @__PURE__ */ new Date()).toISOString()
      };
    } catch {
      return defaultSiteLinkSnapshot();
    }
  }

  // src/shared/extension-context.ts
  function isExtensionContextValid() {
    try {
      return Boolean(
        typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.id === "string" && chrome.runtime.id.length > 0
      );
    } catch {
      return false;
    }
  }
  function isExtensionContextInvalidatedError(error) {
    if (!error) {
      return false;
    }
    const message = error instanceof Error ? error.message : typeof error === "string" ? error : String(error);
    return /Extension context invalidated/i.test(message);
  }
  async function withExtensionContext(run, fallback) {
    if (!isExtensionContextValid()) {
      return { ok: false, invalidated: true, value: fallback };
    }
    try {
      const value = await run();
      return { ok: true, value };
    } catch (error) {
      const invalidated = isExtensionContextInvalidatedError(error);
      if (invalidated || !isExtensionContextValid()) {
        return { ok: false, invalidated: true, value: fallback };
      }
      return { ok: false, invalidated: false, value: fallback };
    }
  }

  // src/shared/two-minute-onboarding.ts
  var TWO_MINUTE_ONBOARDING_KEY = "rip:twoMinuteOnboarding";
  function defaultTwoMinuteOnboardingState() {
    return {
      inventoryVisitedAt: null,
      firstListAt: null,
      wizardDismissed: false,
      completedAt: null,
      trialHintDismissed: false
    };
  }
  function parseTwoMinuteOnboardingState(raw) {
    if (!raw || typeof raw !== "object") {
      return defaultTwoMinuteOnboardingState();
    }
    const record = raw;
    const asIso = (value) => typeof value === "string" && value.trim() ? value : null;
    return {
      inventoryVisitedAt: asIso(record.inventoryVisitedAt),
      firstListAt: asIso(record.firstListAt),
      wizardDismissed: record.wizardDismissed === true,
      completedAt: asIso(record.completedAt),
      trialHintDismissed: record.trialHintDismissed === true
    };
  }
  function markInventoryVisited(state, nowIso = (/* @__PURE__ */ new Date()).toISOString()) {
    if (state.inventoryVisitedAt) {
      return state;
    }
    return { ...state, inventoryVisitedAt: nowIso };
  }
  function markFirstList(state, nowIso = (/* @__PURE__ */ new Date()).toISOString()) {
    if (state.firstListAt) {
      return state;
    }
    return { ...state, firstListAt: nowIso };
  }
  function dismissTrialListHint(state) {
    return { ...state, trialHintDismissed: true };
  }
  function withAutoComplete(state, connected, nowIso = (/* @__PURE__ */ new Date()).toISOString()) {
    if (state.completedAt) {
      return state;
    }
    const ready = connected && Boolean(state.inventoryVisitedAt) && Boolean(state.firstListAt);
    if (!ready) {
      return state;
    }
    return { ...state, completedAt: nowIso };
  }
  function resolveTrialListHintView(params) {
    const locale = params.locale ?? DEFAULT_EXTENSION_LOCALE;
    const t = createExtensionT(locale);
    const visible = params.connected && params.checklistReady && Boolean(params.state.inventoryVisitedAt) && !params.state.firstListAt && !params.state.trialHintDismissed && !params.state.wizardDismissed;
    return {
      visible,
      title: t("twoMin.trialTitle"),
      body: t("twoMin.trialBody"),
      dismissLabel: t("twoMin.trialDismiss")
    };
  }
  async function getTwoMinuteOnboardingState() {
    const result = await withExtensionContext(async () => {
      const stored = await chrome.storage.local.get(TWO_MINUTE_ONBOARDING_KEY);
      return parseTwoMinuteOnboardingState(stored[TWO_MINUTE_ONBOARDING_KEY]);
    }, defaultTwoMinuteOnboardingState());
    return result.value;
  }
  async function setTwoMinuteOnboardingState(state) {
    await withExtensionContext(async () => {
      await chrome.storage.local.set({ [TWO_MINUTE_ONBOARDING_KEY]: state });
    }, void 0);
  }
  async function recordTwoMinuteInventoryVisit() {
    const next = markInventoryVisited(await getTwoMinuteOnboardingState());
    await setTwoMinuteOnboardingState(next);
    return next;
  }
  async function recordTwoMinuteFirstList() {
    const base = markFirstList(await getTwoMinuteOnboardingState());
    const next = withAutoComplete(base, true);
    await setTwoMinuteOnboardingState(next);
    return next;
  }
  async function persistDismissTrialListHint() {
    const next = dismissTrialListHint(await getTwoMinuteOnboardingState());
    await setTwoMinuteOnboardingState(next);
    return next;
  }

  // src/shared/inventory-seller-onboarding.ts
  var INVENTORY_SELLER_ONBOARDING_KEY = "rip:inventorySellerOnboarding";
  var COACH_AUTO_DISMISS_MS = 3e4;
  function defaultOnboardingState() {
    return {
      coachDismissed: false,
      coachSeenAt: null
    };
  }
  function parseOnboardingState(raw) {
    if (!raw || typeof raw !== "object") {
      return defaultOnboardingState();
    }
    const record = raw;
    return {
      coachDismissed: record.coachDismissed === true,
      coachSeenAt: typeof record.coachSeenAt === "string" && record.coachSeenAt.trim() ? record.coachSeenAt : null
    };
  }
  function shouldShowCoachMark(state) {
    return !state.coachDismissed;
  }
  function markCoachSeen(state, nowIso = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      ...state,
      coachSeenAt: state.coachSeenAt ?? nowIso
    };
  }
  function dismissCoachMark(state, nowIso = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      coachDismissed: true,
      coachSeenAt: state.coachSeenAt ?? nowIso
    };
  }
  function resolveCoachMarkView(params) {
    const locale = params.locale ?? DEFAULT_EXTENSION_LOCALE;
    const t = createExtensionT(locale);
    return {
      visible: shouldShowCoachMark(params.state),
      title: t("onboarding.coachTitle"),
      body: t("onboarding.coachBody"),
      dismissLabel: t("onboarding.coachDismiss"),
      autoDismissMs: COACH_AUTO_DISMISS_MS
    };
  }
  function hasValidTradeUrl(tradeUrl) {
    const trimmed = tradeUrl?.trim() ?? "";
    if (trimmed.length < 10) {
      return false;
    }
    try {
      const parsed = new URL(trimmed);
      if (parsed.hostname !== "steamcommunity.com") {
        return false;
      }
      if (parsed.pathname !== "/tradeoffer/new/") {
        return false;
      }
      const partner = parsed.searchParams.get("partner");
      const token = parsed.searchParams.get("token");
      return Boolean(partner && /^\d+$/.test(partner) && token && token.length > 0);
    } catch {
      return false;
    }
  }
  function resolveSellerChecklistView(params) {
    const locale = params.locale ?? DEFAULT_EXTENSION_LOCALE;
    const t = createExtensionT(locale);
    const tradeUrlReady = hasValidTradeUrl(params.tradeUrl);
    const items = [
      {
        key: "extension",
        label: t("onboarding.extensionReady"),
        hint: t("onboarding.extensionHint"),
        ready: params.extensionConnected,
        actionLabel: params.extensionConnected ? null : t("onboarding.extensionAction"),
        actionHref: params.extensionConnected ? null : params.accountUrl
      },
      {
        key: "trade_url",
        label: t("onboarding.tradeUrlTitle"),
        hint: t("onboarding.tradeUrlHint"),
        ready: tradeUrlReady,
        actionLabel: tradeUrlReady ? null : t("onboarding.tradeUrlAction"),
        actionHref: tradeUrlReady ? null : `${params.accountUrl}#account-trade-url-section`
      }
    ];
    const readyCount = items.filter((item) => item.ready).length;
    const allReady = readyCount === items.length;
    return {
      title: t("onboarding.checklistTitle"),
      items,
      allReady,
      readyCount,
      summaryLine: allReady ? t("onboarding.checklistReady") : t("onboarding.checklistProgress", {
        ready: String(readyCount),
        total: String(items.length)
      })
    };
  }

  // src/shared/inventory-selected-actions.ts
  var SELECTED_SELL_RAIL_ID = "rip-market-selected-sell";
  function isNodeVisuallyShown(node) {
    const el = node;
    const inline = (el.getAttribute("style") ?? "").toLowerCase();
    if (/display\s*:\s*none/.test(inline)) {
      return false;
    }
    if (el.hidden || el.getAttribute("aria-hidden") === "true") {
      return false;
    }
    const live = el.style?.display?.toLowerCase();
    if (live === "none") {
      return false;
    }
    return true;
  }
  function readNameFromItemElement(item) {
    return item.getAttribute("data-market-hash-name")?.trim() || item.getAttribute("data-hash-name")?.trim() || item.querySelector("img[title], img[alt]")?.getAttribute("title")?.trim() || item.querySelector("img[title], img[alt]")?.getAttribute("alt")?.trim() || null;
  }
  function refFromItemElement(item) {
    if (!item) {
      return null;
    }
    const parsed = parseCs2InventoryItemElementId(item.id);
    if (!parsed) {
      return null;
    }
    return {
      assetId: parsed.assetId,
      contextId: parsed.contextId,
      marketHashName: readNameFromItemElement(item)
    };
  }
  function findVisibleItemInfoPanel(doc) {
    const panels = Array.from(
      doc.querySelectorAll(
        "#iteminfo0, #iteminfo1, .inventory_page_right .inventory_iteminfo"
      )
    );
    for (const panel of panels) {
      if (isNodeVisuallyShown(panel)) {
        return panel;
      }
    }
    return panels[0] ?? null;
  }
  function findVisibleItemActionsRoot(doc) {
    const panel = findVisibleItemInfoPanel(doc);
    if (panel) {
      const market = panel.querySelector(
        '[id$="_item_market_actions"], .item_market_actions'
      ) ?? null;
      if (market) {
        return market;
      }
      const actions = panel.querySelector('[id$="_item_actions"], .item_actions') ?? null;
      if (actions) {
        return actions;
      }
    }
    const candidates = Array.from(
      doc.querySelectorAll(
        [
          "#iteminfo0_item_market_actions",
          "#iteminfo1_item_market_actions",
          "#iteminfo0 .item_market_actions",
          "#iteminfo1 .item_market_actions",
          ".inventory_iteminfo .item_market_actions",
          "#iteminfo0_item_actions",
          "#iteminfo1_item_actions",
          "#iteminfo0 .item_actions",
          "#iteminfo1 .item_actions"
        ].join(", ")
      )
    );
    for (const node of candidates) {
      const info = node.closest(
        "#iteminfo0, #iteminfo1, .inventory_iteminfo"
      );
      if (info && !isNodeVisuallyShown(info)) {
        continue;
      }
      if (!isNodeVisuallyShown(node)) {
        continue;
      }
      return node;
    }
    return candidates[0] ?? null;
  }
  function readSelectedCs2ItemFromDom(doc, options) {
    const activeInfo = refFromItemElement(
      doc.querySelector(`${CS2_INVENTORY_ITEM_SELECTOR}.activeInfo`) ?? doc.querySelector(`.itemHolder.activeInfo ${CS2_INVENTORY_ITEM_SELECTOR}`) ?? doc.querySelector(`#inventories ${CS2_INVENTORY_ITEM_SELECTOR}.activeInfo`)
    );
    if (activeInfo) {
      return activeInfo;
    }
    const holderActive = refFromItemElement(
      doc.querySelector(
        `.itemHolder.active ${CS2_INVENTORY_ITEM_SELECTOR}, .itemHolder.hover ${CS2_INVENTORY_ITEM_SELECTOR}`
      )
    );
    if (holderActive) {
      return holderActive;
    }
    const lastId = options?.lastClickedAssetId?.trim();
    if (lastId) {
      const fromClick = refFromItemElement(
        queryCs2InventoryItemByAssetId(doc, lastId)
      );
      if (fromClick) {
        return fromClick;
      }
      return { assetId: lastId, marketHashName: null, contextId: null };
    }
    const panel = findVisibleItemInfoPanel(doc);
    const panelName = panel?.querySelector(
      ".hover_item_name, h1, #iteminfo0_item_name, #iteminfo1_item_name"
    )?.textContent?.trim() || null;
    if (panelName) {
      for (const item of Array.from(
        doc.querySelectorAll(CS2_INVENTORY_ITEM_SELECTOR)
      )) {
        const name = readNameFromItemElement(item);
        if (name && name === panelName) {
          const ref = refFromItemElement(item);
          if (ref) {
            return ref;
          }
        }
      }
    }
    return null;
  }
  function buildSelectedSellRailModel(params) {
    if (!params.selected) {
      return { visible: false, assetId: null, label: params.label, kind: "list" };
    }
    if (!params.connected) {
      return {
        visible: true,
        assetId: params.selected.assetId,
        label: params.label,
        kind: "pair"
      };
    }
    if (params.siteSafeMode) {
      return {
        visible: true,
        assetId: params.selected.assetId,
        label: "\u0421\u0430\u0439\u0442 offline",
        kind: "blocked"
      };
    }
    return {
      visible: true,
      assetId: params.selected.assetId,
      label: params.label,
      kind: "list"
    };
  }

  // src/shared/storage.ts
  var ALGO = {
    name: "RSASSA-PKCS1-v1_5",
    modulusLength: 2048,
    publicExponent: new Uint8Array([1, 0, 1]),
    hash: "SHA-256"
  };
  async function getSessionState() {
    try {
      const stored = await chrome.storage.local.get([
        "sessionId",
        "deviceId",
        "accessToken",
        "expiresAt",
        "apiBaseUrl"
      ]);
      if (!stored.sessionId || !stored.accessToken || !stored.apiBaseUrl) {
        return null;
      }
      return stored;
    } catch {
      return null;
    }
  }

  // src/shared/inventory-lazy-enrich.ts
  var LAZY_ENRICH_VIEWPORT_MARGIN_PX = 240;
  var LAZY_ENRICH_SYNC_CAP = 48;
  var LAZY_ENRICH_BATCH_SIZE = 24;
  function isRectNearViewport(rect, viewport, marginPx = LAZY_ENRICH_VIEWPORT_MARGIN_PX) {
    return !(rect.bottom < -marginPx || rect.top > viewport.height + marginPx || rect.right < -marginPx || rect.left > viewport.width + marginPx);
  }
  function isElementNearViewport(el, opts) {
    const viewport = opts?.viewport ?? {
      width: typeof window !== "undefined" ? window.innerWidth || document.documentElement.clientWidth || 0 : 0,
      height: typeof window !== "undefined" ? window.innerHeight || document.documentElement.clientHeight || 0 : 0
    };
    const getRect = opts?.getBoundingClientRect ?? ((node) => node.getBoundingClientRect());
    return isRectNearViewport(
      getRect(el),
      viewport,
      opts?.marginPx ?? LAZY_ENRICH_VIEWPORT_MARGIN_PX
    );
  }
  function partitionHoldersForEnrich(holders, opts) {
    const syncCap = opts?.syncCap ?? LAZY_ENRICH_SYNC_CAP;
    const near = [];
    const far = [];
    for (const holder of holders) {
      if (isElementNearViewport(holder, {
        marginPx: opts?.marginPx,
        viewport: opts?.viewport,
        getBoundingClientRect: opts?.getBoundingClientRect
      })) {
        near.push(holder);
      } else {
        far.push(holder);
      }
    }
    if (near.length <= syncCap) {
      return { immediate: near, deferred: far };
    }
    return {
      immediate: near.slice(0, syncCap),
      deferred: [...near.slice(syncCap), ...far]
    };
  }

  // src/shared/rate-limit-backoff-runtime.ts
  var RATE_LIMIT_BACKOFF_STORAGE_KEY = "rip:rateLimitBackoff";
  function parseRateLimitBackoffState(raw) {
    if (!raw || typeof raw !== "object") {
      return defaultRateLimitBackoffState();
    }
    const record = raw;
    return {
      consecutiveHits: typeof record.consecutiveHits === "number" ? record.consecutiveHits : 0,
      blockedUntilMs: typeof record.blockedUntilMs === "number" ? record.blockedUntilMs : null,
      lastHitAtMs: typeof record.lastHitAtMs === "number" ? record.lastHitAtMs : null
    };
  }
  async function loadRateLimitBackoff() {
    try {
      const stored = await chrome.storage.session.get(
        RATE_LIMIT_BACKOFF_STORAGE_KEY
      );
      return parseRateLimitBackoffState(
        stored[RATE_LIMIT_BACKOFF_STORAGE_KEY]
      );
    } catch {
      return defaultRateLimitBackoffState();
    }
  }
  async function saveRateLimitBackoff(state) {
    await chrome.storage.session.set({
      [RATE_LIMIT_BACKOFF_STORAGE_KEY]: state
    });
  }
  async function noteRateLimitHit(retryAfterMs) {
    const next = markRateLimitHit(await loadRateLimitBackoff(), {
      retryAfterMs
    });
    await saveRateLimitBackoff(next);
    return next;
  }
  async function canProceedPastRateLimit(nowMs = Date.now()) {
    return !isRateLimitBlocked(await loadRateLimitBackoff(), nowMs);
  }

  // src/shared/active-trades-cache.ts
  var INVENTORY_LAYER_ENABLED_KEY = "extensionInventoryLayerEnabled";

  // src/shared/extension-flags.ts
  function isRemoteFlagOn(stored) {
    return stored !== false;
  }
  async function isExtensionInventoryLayerEnabled() {
    try {
      const stored = await chrome.storage.local.get(INVENTORY_LAYER_ENABLED_KEY);
      return isRemoteFlagOn(stored[INVENTORY_LAYER_ENABLED_KEY]);
    } catch {
      return true;
    }
  }

  // src/shared/steam-inventory-page.ts
  var CS2_APP_ID2 = 730;
  var CS2_CONTEXT_ID = 2;
  var CS2_TRADE_PROTECTED_CONTEXT_ID2 = 16;
  function isSteamInventoryPath(pathname) {
    return /\/inventory\/?/i.test(pathname);
  }
  function parseInventoryAppContext(hash) {
    const raw = hash.startsWith("#") ? hash.slice(1) : hash;
    const cleaned = raw.replace(/^!/, "").trim();
    if (!cleaned) {
      return { appId: null, contextId: null };
    }
    const underscored = cleaned.match(/^(\d+)(?:_(\d+))?/);
    if (underscored) {
      return {
        appId: Number(underscored[1]),
        contextId: underscored[2] ? Number(underscored[2]) : null
      };
    }
    return { appId: null, contextId: null };
  }
  function readActiveInventoryAppIdFromDom(doc) {
    const activeTab = doc.querySelector(
      '.games_list_tab.active[id^="inventory_link_"], a.games_list_tab.active[href*="inventory"]'
    );
    if (activeTab) {
      const idMatch = activeTab.id?.match(/inventory_link_(\d+)/i);
      if (idMatch) {
        return Number(idMatch[1]);
      }
      const href = activeTab.getAttribute("href") ?? "";
      const hrefMatch = href.match(/#(\d+)(?:_(\d+))?/);
      if (hrefMatch) {
        return Number(hrefMatch[1]);
      }
    }
    const activePage = doc.querySelector(
      '[id^="inventory_"][id$="_0"].inventory_ctn, .inventory_ctn[style*="display: block"], .inventory_ctn:not([style*="display: none"])'
    );
    if (activePage?.id) {
      const pageMatch = activePage.id.match(/^inventory_(\d+)_/i);
      if (pageMatch) {
        return Number(pageMatch[1]);
      }
    }
    return null;
  }
  function isCs2InventoryActive(params) {
    if (!isSteamInventoryPath(params.pathname)) {
      return false;
    }
    const fromHash = parseInventoryAppContext(params.hash);
    if (fromHash.appId === CS2_APP_ID2) {
      return true;
    }
    if (fromHash.appId !== null && fromHash.appId !== CS2_APP_ID2) {
      return false;
    }
    if (params.document) {
      const fromDom = readActiveInventoryAppIdFromDom(params.document);
      if (fromDom === CS2_APP_ID2) {
        return true;
      }
      if (fromDom !== null) {
        return false;
      }
    }
    return false;
  }
  function isHtmlElement(node) {
    return typeof node.style !== "undefined";
  }
  function isSteamInventoryNodeVisuallyShown(node, getComputed) {
    if (!isHtmlElement(node)) {
      return true;
    }
    const inline = (node.getAttribute("style") ?? "").toLowerCase();
    if (/display\s*:\s*none/.test(inline)) {
      return false;
    }
    if (node.hidden || node.getAttribute("aria-hidden") === "true") {
      return false;
    }
    if (node.classList.contains("inactive") || node.classList.contains("hidden")) {
      return false;
    }
    const liveDisplay = node.style?.display?.toLowerCase();
    if (liveDisplay === "none") {
      return false;
    }
    if (getComputed) {
      try {
        const computed = getComputed(node);
        if (computed.display === "none" || computed.visibility === "hidden") {
          return false;
        }
      } catch {
      }
    }
    return true;
  }
  function findCs2InventoryContainer(doc) {
    const byId = doc.querySelector(`#inventory_${CS2_APP_ID2}_${CS2_CONTEXT_ID}`) ?? doc.querySelector(
      `#inventory_${CS2_APP_ID2}_${CS2_TRADE_PROTECTED_CONTEXT_ID2}`
    ) ?? doc.querySelector(`[id^="inventory_${CS2_APP_ID2}_"]`);
    if (byId) {
      return byId;
    }
    const containers = Array.from(
      doc.querySelectorAll(".inventory_ctn, #inventories > div, #inventories")
    );
    for (const container of containers) {
      if (container.querySelector(CS2_INVENTORY_ITEM_SELECTOR)) {
        return container;
      }
    }
    return null;
  }
  function listInventoryPages(root) {
    const pages = Array.from(root.querySelectorAll(".inventory_page"));
    if (pages.length > 0) {
      return pages;
    }
    return [root];
  }
  function resolveHolderForItem(item) {
    return item.closest(".itemHolder") ?? (item.parentElement?.classList.contains("itemHolder") ? item.parentElement : item.parentElement);
  }
  function listPaintableCs2InventoryCells(doc, options) {
    const getComputed = options?.getComputedStyle ?? (typeof globalThis.getComputedStyle === "function" ? globalThis.getComputedStyle.bind(globalThis) : void 0);
    const cs2Root = findCs2InventoryContainer(doc);
    const searchRoots = [];
    if (cs2Root) {
      const pages = listInventoryPages(cs2Root);
      const shownPages = pages.filter(
        (page) => isSteamInventoryNodeVisuallyShown(page, getComputed)
      );
      const pageRoots = shownPages.length > 0 ? shownPages : pages.filter(
        (page) => page.querySelector(CS2_INVENTORY_ITEM_SELECTOR)
      );
      if (pageRoots.length > 0) {
        searchRoots.push(...pageRoots);
      } else {
        searchRoots.push(cs2Root);
      }
    } else {
      const inventories = doc.querySelector("#inventories");
      if (inventories) {
        searchRoots.push(inventories);
      }
    }
    if (searchRoots.length === 0) {
      return [];
    }
    const cells = [];
    const seen = /* @__PURE__ */ new Set();
    const pushItem = (item) => {
      const parsed = parseCs2InventoryItemElementId(item.id);
      if (!parsed) {
        return;
      }
      const holder = resolveHolderForItem(item);
      if (!holder) {
        return;
      }
      if (holder.classList.contains("disabled") || holder.classList.contains("unknown")) {
        return;
      }
      if (seen.has(parsed.assetId)) {
        return;
      }
      seen.add(parsed.assetId);
      cells.push({
        holder,
        item,
        assetId: parsed.assetId,
        contextId: parsed.contextId
      });
    };
    for (const root of searchRoots) {
      for (const item of Array.from(
        root.querySelectorAll(CS2_INVENTORY_ITEM_SELECTOR)
      )) {
        const page = item.closest(".inventory_page");
        if (page && !isSteamInventoryNodeVisuallyShown(page, getComputed)) {
          continue;
        }
        pushItem(item);
      }
    }
    if (cells.length === 0) {
      for (const item of Array.from(
        doc.querySelectorAll(
          `#inventories ${CS2_INVENTORY_ITEM_SELECTOR}, ${CS2_INVENTORY_ITEM_SELECTOR}`
        )
      )) {
        const page = item.closest(".inventory_page");
        if (page) {
          const pageStyle = (page.getAttribute("style") ?? "").toLowerCase();
          if (/display\s*:\s*none/.test(pageStyle) || page.style?.display === "none") {
            continue;
          }
        }
        pushItem(item);
      }
    }
    return cells;
  }
  function countVisibleCs2InventoryItemHolders(doc, options) {
    return listPaintableCs2InventoryCells(doc, options).length;
  }
  function siteOriginFromApiBaseUrl(apiBaseUrl) {
    if (!apiBaseUrl) {
      return "https://p2pcs.ru";
    }
    return apiBaseUrl.replace(/\/api\/v1\/?$/, "").replace(/\/$/, "");
  }
  function siteSellInventoryUrl(apiBaseUrl) {
    return `${siteOriginFromApiBaseUrl(apiBaseUrl)}/sell/inventory`;
  }
  function siteAccountUrl(apiBaseUrl) {
    return `${siteOriginFromApiBaseUrl(apiBaseUrl)}/account`;
  }
  function siteListingsPageUrl(apiBaseUrl) {
    return `${siteOriginFromApiBaseUrl(apiBaseUrl)}/deals?tab=listings`;
  }

  // src/shared/inventory-trade-hold.ts
  var TRADE_HOLD_BANNER_DISMISS_KEY = "rip:tradeHoldBannerDismissed";
  function countTradeHoldOrUntradable(facts, nowMs = Date.now()) {
    let count = 0;
    for (const fact of facts) {
      if (isTradeLocked(fact.tradeLockUntil, nowMs) || !fact.tradable) {
        count += 1;
      }
    }
    return count;
  }
  function resolveTradeHoldBannerView(params) {
    const holdCount = countTradeHoldOrUntradable(params.facts, params.nowMs);
    if (params.dismissed || holdCount <= 0) {
      return {
        visible: false,
        title: "",
        body: "",
        holdCount,
        dismissLabel: "\u041F\u043E\u043D\u044F\u0442\u043D\u043E"
      };
    }
    return {
      visible: true,
      title: "\u0427\u0430\u0441\u0442\u044C \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432 \u043D\u0430 Steam trade hold",
      body: holdCount === 1 ? "1 \u043F\u0440\u0435\u0434\u043C\u0435\u0442 \u043D\u0435\u043B\u044C\u0437\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0432 \u043E\u0431\u043C\u0435\u043D, \u043F\u043E\u043A\u0430 Steam \u043D\u0435 \u0441\u043D\u0438\u043C\u0435\u0442 \u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043A\u0443. \u041D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435 \u2014 \u0441\u0440\u043E\u043A (Hold). \u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0430 R.I.P \u043C\u043E\u0436\u043D\u043E \u0442\u043E\u043B\u044C\u043A\u043E tradable." : `${holdCount} \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432 \u043D\u0435\u043B\u044C\u0437\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0432 \u043E\u0431\u043C\u0435\u043D, \u043F\u043E\u043A\u0430 Steam \u043D\u0435 \u0441\u043D\u0438\u043C\u0435\u0442 \u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043A\u0443. \u041D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430\u0445 \u2014 \u0441\u0440\u043E\u043A (Hold). \u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0430 R.I.P \u043C\u043E\u0436\u043D\u043E \u0442\u043E\u043B\u044C\u043A\u043E tradable.`,
      holdCount,
      dismissLabel: "\u041F\u043E\u043D\u044F\u0442\u043D\u043E"
    };
  }
  function isTradeHoldBannerDismissed(storage = sessionStorage) {
    try {
      return storage.getItem(TRADE_HOLD_BANNER_DISMISS_KEY) === "1";
    } catch {
      return false;
    }
  }
  function dismissTradeHoldBanner(storage = sessionStorage) {
    try {
      storage.setItem(TRADE_HOLD_BANNER_DISMISS_KEY, "1");
    } catch {
    }
  }
  function readSteamItemIconUrl(root, assetId, queryItem) {
    const item = queryItem(root, assetId);
    if (!item) {
      return null;
    }
    const img = item.querySelector("img[src]") ?? item.querySelector("img");
    const src = img?.currentSrc?.trim() || img?.src?.trim() || null;
    if (!src || src.startsWith("data:")) {
      return null;
    }
    return src;
  }

  // src/shared/inventory-sell-panel-rails.ts
  function resolveSellPanelPriceRails(hint) {
    const steam = parseMinor(hint?.steamPriceMinor);
    const median = parseMinor(hint?.steamMedianPriceMinor);
    const recommended = parseMinor(hint?.suggestedListMinor) ?? getRecommendedListPriceMinor(hint);
    const bid = parseMinor(hint?.bestBidMinor);
    const bidQty = hint?.bestBidQuantity != null && Number.isFinite(hint.bestBidQuantity) && hint.bestBidQuantity > 0 ? Math.floor(hint.bestBidQuantity) : null;
    const steamLine = steam != null ? `Steam (lowest): ${formatUsdFromMinor(steam)}` : null;
    const medianLine = median != null && median !== steam ? `\u0421\u0440\u0435\u0434\u043D\u044F\u044F Steam: ${formatUsdFromMinor(median)}` : null;
    const recommendedLine = recommended != null ? `\u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u043C: ${formatUsdFromMinor(recommended)} (Steam \u22125% / \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430 R.I.P)` : null;
    const bidLine = bid != null ? bidQty != null && bidQty > 1 ? `\u0421\u043F\u0440\u043E\u0441 (bid): ${formatUsdFromMinor(bid)} \xB7 ${bidQty} \u0448\u0442` : `\u0421\u043F\u0440\u043E\u0441 (bid): ${formatUsdFromMinor(bid)}` : null;
    return {
      steamLine,
      medianLine,
      recommendedLine,
      recommendedMinor: recommended,
      bidLine,
      bidMinor: bid,
      honestyLine: bidLine ? "\u041F\u043E bid \u2014 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044E, \u043D\u0435 \u043C\u0433\u043D\u043E\u0432\u0435\u043D\u043D\u0430\u044F \u0432\u044B\u043F\u043B\u0430\u0442\u0430." : null
    };
  }

  // src/shared/inventory-sell-draft.ts
  var INVENTORY_SELL_DRAFT_KEY = "rip:inventorySellDraft:v1";
  var MAX_SELECTED = 50;
  function normalizeInventorySellDraft(raw) {
    if (!raw || typeof raw !== "object") {
      return null;
    }
    const value = raw;
    if (value.version !== 1) {
      return null;
    }
    const selectedRaw = Array.isArray(value.selectedAssetIds) ? value.selectedAssetIds : [];
    const selectedAssetIds = [
      ...new Set(
        selectedRaw.filter((id) => typeof id === "string" && id.trim() !== "").map((id) => id.trim()).slice(0, MAX_SELECTED)
      )
    ];
    const steamId = typeof value.steamId === "string" && /^\d{17}$/.test(value.steamId) ? value.steamId : null;
    const priceInput = typeof value.priceInput === "string" && value.priceInput.trim() !== "" ? value.priceInput.trim() : null;
    const priceAssetId = typeof value.priceAssetId === "string" && value.priceAssetId.trim() !== "" ? value.priceAssetId.trim() : null;
    const updatedAt = typeof value.updatedAt === "number" && Number.isFinite(value.updatedAt) ? value.updatedAt : Date.now();
    return {
      version: 1,
      steamId,
      bulkMode: value.bulkMode === true,
      selectedAssetIds,
      priceInput,
      priceAssetId,
      updatedAt
    };
  }
  function readInventorySellDraft(storage = sessionStorage) {
    try {
      const raw = storage.getItem(INVENTORY_SELL_DRAFT_KEY);
      if (!raw) {
        return null;
      }
      return normalizeInventorySellDraft(JSON.parse(raw));
    } catch {
      return null;
    }
  }
  function writeInventorySellDraft(draft, storage = sessionStorage) {
    try {
      const normalized = normalizeInventorySellDraft({
        ...draft,
        updatedAt: Date.now()
      });
      if (!normalized) {
        return;
      }
      storage.setItem(INVENTORY_SELL_DRAFT_KEY, JSON.stringify(normalized));
    } catch {
    }
  }
  function clearInventorySellDraft(storage = sessionStorage) {
    try {
      storage.removeItem(INVENTORY_SELL_DRAFT_KEY);
    } catch {
    }
  }
  function filterDraftSelectionToKnownAssets(selectedAssetIds, knownAssetIds) {
    return selectedAssetIds.filter((id) => knownAssetIds.has(id));
  }
  function resolveInventorySellDraftRestore(params) {
    const empty = {
      restored: false,
      bulkMode: false,
      selectedAssetIds: [],
      priceInput: null,
      priceAssetId: null,
      chipLabel: null
    };
    const draft = params.draft;
    if (!draft) {
      return empty;
    }
    if (draft.steamId && params.pageSteamId && draft.steamId !== params.pageSteamId) {
      return empty;
    }
    const selectedAssetIds = filterDraftSelectionToKnownAssets(
      draft.selectedAssetIds,
      params.knownAssetIds
    );
    const priceAssetId = draft.priceAssetId && params.knownAssetIds.has(draft.priceAssetId) ? draft.priceAssetId : null;
    const priceInput = priceAssetId ? draft.priceInput : null;
    const bulkMode2 = draft.bulkMode && selectedAssetIds.length > 0;
    const restored = bulkMode2 || selectedAssetIds.length > 0 || priceInput != null;
    if (!restored) {
      return empty;
    }
    const chipLabel = selectedAssetIds.length > 0 ? `\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E \xB7 \u0432\u044B\u0431\u0440\u0430\u043D\u043E ${selectedAssetIds.length}` : priceInput ? "\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0446\u0435\u043D\u044B" : null;
    return {
      restored: true,
      bulkMode: bulkMode2,
      selectedAssetIds,
      priceInput,
      priceAssetId,
      chipLabel
    };
  }

  // src/shared/inventory-browser-assist.ts
  var MAX_BROWSER_ASSIST_ASSETS = 500;
  function buildBrowserAssistAssetsFromFacts(facts, iconByAssetId) {
    const out = [];
    for (const fact of facts) {
      const marketHashName = fact.marketHashName?.trim();
      const assetId = fact.assetId?.trim();
      if (!marketHashName || !assetId) {
        continue;
      }
      out.push({
        assetId,
        marketHashName,
        tradable: fact.tradable,
        marketable: fact.marketable,
        tradeLockUntil: fact.tradeLockUntil,
        floatValue: fact.floatValue,
        paintSeed: fact.paintSeed,
        wear: fact.wear,
        iconUrl: iconByAssetId?.get(assetId) ?? null
      });
      if (out.length >= MAX_BROWSER_ASSIST_ASSETS) {
        break;
      }
    }
    return out;
  }

  // src/content/inventory-bridge.ts
  var HOST_ID = "rip-market-inventory-layer";
  var STYLE_ID = "rip-market-inventory-layer-style";
  var ATTR_READY = "data-rip-inventory-ready";
  var ENRICH_ATTR = "data-rip-enriched";
  var OVERLAY_CLASS = "rip-item-enrich";
  var SELL_PANEL_ID = "rip-market-sell-panel";
  var TOAST_ID = "rip-market-sell-toast";
  var BULK_BAR_ID = "rip-market-bulk-bar";
  var STEAM_FACTS_TTL_MS = 9e4;
  var STEAM_ENRICHMENT_RECOVERY_MS = 8e3;
  var PLATFORM_FACTS_TTL_MS = 6e4;
  var PRICE_HINTS_TTL_MS = 12e4;
  var steamFactsCache = null;
  var platformFactsCache = null;
  var priceHintsCache = null;
  var steamFactsInflight = null;
  var enrichTimer = null;
  var renderTimer = null;
  var mounted = false;
  var bulkMode = false;
  var bulkSelected = /* @__PURE__ */ new Set();
  var lastConnected = false;
  var lastSiteSafeMode = false;
  var coachAutoDismissTimer = null;
  var coachMarkedSeenThisSession = false;
  var enrichObserver = null;
  var deferredEnrichContext = null;
  var deferredEnrichQueue = [];
  var deferredEnrichRaf = null;
  var steamEnrichmentDegraded = false;
  var steamEnrichmentRetryTimer = null;
  var extensionContextInvalidated = false;
  var lastClickedAssetId = null;
  var sellDraftRestoreAttempted = false;
  var sellDraftRestoreChip = null;
  var sellDraftPriceByAsset = null;
  var browserAssistBusy = false;
  function currentPageSteamId() {
    return readSteamIdFromDocumentHtml(document.documentElement?.innerHTML ?? "");
  }
  function persistSellDraft() {
    const draft = {
      version: 1,
      steamId: currentPageSteamId(),
      bulkMode,
      selectedAssetIds: [...bulkSelected],
      priceInput: sellDraftPriceByAsset?.priceInput ?? null,
      priceAssetId: sellDraftPriceByAsset?.assetId ?? null,
      updatedAt: Date.now()
    };
    if (!draft.bulkMode && draft.selectedAssetIds.length === 0 && !draft.priceInput) {
      clearInventorySellDraft();
      sellDraftRestoreChip = null;
      return;
    }
    writeInventorySellDraft(draft);
  }
  async function runBrowserAssistSync() {
    if (browserAssistBusy || !isExtensionContextValid()) {
      return;
    }
    const steamId = currentPageSteamId();
    const facts = steamFactsCache?.byAssetId;
    if (!steamId || !facts || facts.size === 0) {
      showSellToast({
        message: "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u043E\u0436\u0434\u0438\u0442\u0435\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 Steam"
      });
      return;
    }
    const iconByAssetId = /* @__PURE__ */ new Map();
    for (const assetId of facts.keys()) {
      iconByAssetId.set(
        assetId,
        readSteamItemIconUrl(document, assetId, queryCs2InventoryItemByAssetId)
      );
    }
    const assets = buildBrowserAssistAssetsFromFacts(facts.values(), iconByAssetId);
    if (assets.length === 0) {
      showSellToast({ message: "\u041D\u0435\u0442 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432 \u0441 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435\u043C \u0434\u043B\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438" });
      return;
    }
    browserAssistBusy = true;
    scheduleHostRender();
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.BROWSER_ASSIST_INVENTORY_SYNC,
        steamId,
        assets,
        complete: true
      });
      if (!response?.ok) {
        showSellToast({
          message: response?.error ?? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435"
        });
        return;
      }
      platformFactsCache = null;
      showSellToast({
        message: response.warning || `\u0421\u0430\u0439\u0442 \u043E\u0431\u043D\u043E\u0432\u043B\u0451\u043D: ${response.itemCount ?? assets.length} \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432`
      });
      scheduleEnrichment(false);
    } catch (error) {
      showSellToast({
        message: error instanceof Error ? error.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435"
      });
    } finally {
      browserAssistBusy = false;
      scheduleHostRender();
    }
  }
  function tryRestoreSellDraft(knownAssetIds) {
    if (sellDraftRestoreAttempted) {
      return;
    }
    sellDraftRestoreAttempted = true;
    const view = resolveInventorySellDraftRestore({
      draft: readInventorySellDraft(),
      pageSteamId: currentPageSteamId(),
      knownAssetIds
    });
    if (!view.restored) {
      return;
    }
    if (view.bulkMode || view.selectedAssetIds.length > 0) {
      bulkMode = view.bulkMode || view.selectedAssetIds.length > 0;
      bulkSelected = new Set(view.selectedAssetIds);
    }
    if (view.priceAssetId && view.priceInput) {
      sellDraftPriceByAsset = {
        assetId: view.priceAssetId,
        priceInput: view.priceInput
      };
    }
    sellDraftRestoreChip = view.chipLabel;
    persistSellDraft();
  }
  function escapeHtml(value) {
    return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }
  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
    #${HOST_ID} {
      display: block;
      margin: 10px 0 14px;
      padding: 0;
      font-family: Inter, system-ui, -apple-system, sans-serif;
      z-index: 20;
      position: relative;
      --rip-bg: rgba(24, 28, 38, 0.96);
      --rip-bg-deep: #0b0d12;
      --rip-elevated-solid: #181c26;
      --rip-radius: 12px;
      --rip-radius-sm: 8px;
      --rip-border: rgba(255, 255, 255, 0.1);
      --rip-text: #f4f4f5;
      --rip-muted: #94a3b8;
      --rip-link: #7dd3fc;
      --rip-primary-from: #0284c7;
      --rip-primary-to: #2563eb;
      --rip-success: #86efac;
      --rip-success-bg: rgba(34, 197, 94, 0.16);
      --rip-warn: #fde047;
      --rip-warn-bg: rgba(234, 179, 8, 0.14);
      --rip-danger: #fecaca;
      --rip-danger-bg: rgba(239, 68, 68, 0.14);
    }
    #${HOST_ID} .rip-inv-bar {
      display: flex;
      flex-direction: column;
      gap: 12px;
      padding: 14px 16px;
      border-radius: var(--rip-radius);
      background:
        linear-gradient(145deg, rgba(2, 132, 199, 0.08), transparent 42%),
        var(--rip-bg);
      border: 1px solid var(--rip-border);
      color: var(--rip-text);
      font-size: 13px;
      line-height: 1.4;
      box-shadow:
        0 10px 28px rgba(0, 0, 0, 0.35),
        inset 0 1px 0 rgba(255, 255, 255, 0.04);
    }
    #${HOST_ID} .rip-inv-bar[data-connection="disconnected"] {
      border-color: rgba(234, 179, 8, 0.35);
      background:
        linear-gradient(145deg, rgba(234, 179, 8, 0.1), transparent 50%),
        var(--rip-bg);
    }
    #${HOST_ID} .rip-inv-bar[data-connection="safe_mode"] {
      border-color: rgba(234, 179, 8, 0.4);
      background:
        linear-gradient(145deg, rgba(234, 179, 8, 0.12), transparent 50%),
        var(--rip-bg);
    }
    #${HOST_ID} .rip-inv-bar-top {
      display: flex;
      flex-wrap: wrap;
      gap: 8px 14px;
      align-items: center;
      justify-content: space-between;
    }
    #${HOST_ID} .rip-inv-identity {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      align-items: center;
      min-width: 0;
    }
    #${HOST_ID} .rip-inv-brand {
      color: var(--rip-link);
      font-weight: 750;
      font-size: 14px;
      letter-spacing: 0.01em;
      white-space: nowrap;
    }
    #${HOST_ID} .rip-inv-status {
      display: inline-flex;
      align-items: center;
      padding: 3px 9px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 650;
      line-height: 1.2;
      border: 1px solid transparent;
    }
    #${HOST_ID} .rip-inv-status[data-connection="connected"] {
      color: var(--rip-success);
      background: var(--rip-success-bg);
      border-color: rgba(134, 239, 172, 0.28);
    }
    #${HOST_ID} .rip-inv-status[data-connection="disconnected"],
    #${HOST_ID} .rip-inv-status[data-connection="safe_mode"] {
      color: var(--rip-warn);
      background: var(--rip-warn-bg);
      border-color: rgba(253, 224, 71, 0.28);
    }
    #${HOST_ID} .rip-inv-meta {
      color: var(--rip-muted);
      font-size: 12px;
      white-space: nowrap;
    }
    #${HOST_ID} .rip-inv-body {
      margin: 0;
      color: var(--rip-muted);
      font-size: 12.5px;
      max-width: 62ch;
    }
    #${HOST_ID} .rip-inv-bar-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      align-items: center;
    }
    #${HOST_ID} .rip-inv-cta,
    #${HOST_ID} .rip-inv-cta-secondary,
    #${HOST_ID} .rip-inv-bulk-toggle {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 8px 12px;
      border-radius: 9px;
      font-weight: 650;
      font-size: 12px;
      line-height: 1.2;
      white-space: nowrap;
      cursor: pointer;
      text-decoration: none !important;
      transition: filter 0.12s ease, border-color 0.12s ease, background 0.12s ease;
    }
    #${HOST_ID} .rip-inv-cta {
      border: none;
      background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
      color: #fff !important;
      box-shadow: 0 0 0 1px color-mix(in srgb, var(--rip-primary-from) 35%, transparent);
    }
    #${HOST_ID} .rip-inv-cta:hover { filter: brightness(1.07); }
    #${HOST_ID} .rip-inv-cta-secondary,
    #${HOST_ID} button.rip-inv-cta-secondary {
      border: 1px solid var(--rip-border);
      background: rgba(15, 23, 42, 0.65);
      color: #e2e8f0;
    }
    #${HOST_ID} .rip-inv-cta-secondary:hover {
      border-color: rgba(125, 211, 252, 0.35);
      color: #fff;
    }
    #${HOST_ID} .rip-inv-bulk-toggle {
      border: 1px solid rgba(125, 211, 252, 0.28);
      background: rgba(14, 165, 233, 0.1);
      color: var(--rip-link);
    }
    #${HOST_ID} .rip-inv-bulk-toggle[data-active="1"] {
      border-color: transparent;
      background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
      color: #fff;
    }
    #${HOST_ID} .rip-inv-draft-chip {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 5px 10px;
      border-radius: 999px;
      background: rgba(15, 23, 42, 0.9);
      border: 1px solid rgba(125, 211, 252, 0.28);
      color: var(--rip-link);
      font-size: 11px;
      font-weight: 600;
    }
    #${HOST_ID} .rip-inv-draft-chip button {
      border: 0;
      background: transparent;
      color: var(--rip-muted);
      cursor: pointer;
      font-size: 11px;
      padding: 0;
    }

    #${HOST_ID} .rip-inv-hold {
      margin-top: 8px;
      padding: 10px 12px;
      border-radius: 12px;
      border: 1px solid rgba(253, 224, 71, 0.32);
      background: var(--rip-warn-bg);
      color: #fef3c7;
      font-size: 12px;
      line-height: 1.4;
    }
    #${HOST_ID} .rip-inv-hold-title {
      margin: 0 0 4px;
      font-weight: 700;
      color: #fde047;
    }
    #${HOST_ID} .rip-inv-hold-body {
      margin: 0 0 8px;
      color: #f5e6b8;
    }
    #${HOST_ID} .rip-inv-hold-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    #${HOST_ID} .rip-inv-steam-warn {
      margin: 0;
      padding: 8px 10px;
      border-radius: 10px;
      background: var(--rip-warn-bg);
      border: 1px solid rgba(253, 224, 71, 0.28);
      color: #f5e6b8;
      font-size: 12px;
      line-height: 1.35;
    }
    #${HOST_ID} .rip-inv-reload {
      margin: 0;
      padding: 10px 12px;
      border-radius: 10px;
      background: var(--rip-danger-bg);
      border: 1px solid rgba(248, 113, 113, 0.35);
      color: var(--rip-danger);
      font-size: 12px;
      line-height: 1.4;
      font-weight: 600;
    }
    #${HOST_ID} .rip-inv-reload button {
      margin-left: 8px;
      padding: 5px 10px;
      border-radius: 8px;
      border: 1px solid rgba(248, 113, 113, 0.45);
      background: rgba(127, 29, 29, 0.55);
      color: #fff;
      font-weight: 700;
      cursor: pointer;
    }

    .itemHolder {
      position: relative !important;
      --rip-primary-from: #0284c7;
      --rip-primary-to: #2563eb;
      --rip-link: #7dd3fc;
      --rip-success: #86efac;
      --rip-warn: #fde047;
      --rip-danger: #fecaca;
      --rip-muted: #94a3b8;
      --rip-text: #f4f4f5;
    }
    /* Mount on Steam's .item \u2014 it fills the holder and otherwise covers sibling overlays. */
    .itemHolder .item[id^="item730_"],
    .itemHolder .item[id^="730_"] {
      position: absolute !important;
    }
    .itemHolder .item[id^="item730_"] .${OVERLAY_CLASS},
    .itemHolder .item[id^="730_"] .${OVERLAY_CLASS},
    .itemHolder .${OVERLAY_CLASS} {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      top: 0;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      pointer-events: none;
      z-index: 1000 !important;
      font-family: Inter, system-ui, -apple-system, sans-serif;
      border-radius: 2px;
      overflow: hidden;
    }
    .itemHolder:hover .${OVERLAY_CLASS},
    .itemHolder .item.activeInfo .${OVERLAY_CLASS} {
      box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--rip-link) 55%, transparent);
    }
    .itemHolder .rip-item-badges {
      display: flex;
      flex-wrap: wrap;
      gap: 2px;
      padding: 3px;
      min-height: 0;
      pointer-events: auto;
    }
    .itemHolder .rip-item-badge {
      display: inline-flex;
      align-items: center;
      padding: 2px 5px;
      border-radius: 4px;
      font-size: 9px;
      font-weight: 600;
      line-height: 1.25;
      border: 1px solid transparent;
      text-decoration: none !important;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      text-shadow: 0 1px 1px rgba(0,0,0,0.55);
    }
    .itemHolder .rip-item-badge--accent {
      background: color-mix(in srgb, var(--rip-primary-to) 88%, transparent);
      color: #fff;
      border-color: color-mix(in srgb, var(--rip-link) 45%, transparent);
    }
    .itemHolder .rip-item-badge--ok {
      background: rgba(34, 197, 94, 0.88);
      color: #ecfdf5;
      border-color: rgba(134, 239, 172, 0.45);
    }
    .itemHolder .rip-item-badge--warn {
      background: rgba(234, 179, 8, 0.88);
      color: #1c1917;
      border-color: rgba(253, 224, 71, 0.45);
    }
    .itemHolder .rip-item-badge--info {
      background: rgba(2, 132, 199, 0.88);
      color: #e0f2fe;
      border-color: rgba(125, 211, 252, 0.4);
    }
    .itemHolder .rip-item-badge--muted {
      background: rgba(30, 41, 59, 0.92);
      color: var(--rip-muted);
      border-color: rgba(255, 255, 255, 0.1);
    }
    .itemHolder .rip-item-footer {
      display: grid;
      gap: 3px;
      padding: 5px 4px 4px;
      background: linear-gradient(
        180deg,
        rgba(11, 13, 18, 0) 0%,
        rgba(11, 13, 18, 0.72) 22%,
        rgba(11, 13, 18, 0.94) 100%
      );
    }
    .itemHolder .rip-item-wear-track {
      position: relative;
      height: 2px;
      border-radius: 999px;
      background: linear-gradient(90deg, #6ecf6e 0%, #7fd67f 7%, #5fd0d5 15%, #ffb454 38%, #ff6b57 45%, #ff6b57 100%);
      overflow: hidden;
      opacity: 0.9;
    }
    .itemHolder .rip-item-wear-pointer {
      position: absolute;
      top: -1px;
      width: 2px;
      height: 4px;
      background: #fff;
      box-shadow: 0 0 2px #000;
      transform: translateX(-50%);
    }
    .itemHolder .rip-item-meta {
      color: var(--rip-muted);
      font-size: 9px;
      font-weight: 500;
      line-height: 1.2;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      text-shadow: 0 1px 2px rgba(0,0,0,0.8);
    }
    .itemHolder .rip-item-price {
      color: var(--rip-text);
      font-size: 11px;
      font-weight: 700;
      letter-spacing: -0.01em;
      line-height: 1.15;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      text-shadow: 0 1px 2px rgba(0,0,0,0.75);
    }
    .itemHolder .rip-item-detail {
      display: none;
      gap: 1px;
    }
    .itemHolder:hover .rip-item-detail,
    .itemHolder .item.activeInfo .rip-item-detail,
    .itemHolder[data-rip-bulk-selected="1"] .rip-item-detail {
      display: grid;
    }
    .itemHolder .rip-item-price-sub {
      color: var(--rip-muted);
      font-size: 8px;
      line-height: 1.15;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .itemHolder .rip-item-price-net {
      color: var(--rip-success);
      font-size: 8px;
      font-weight: 600;
      line-height: 1.15;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .itemHolder .rip-item-price-bid {
      color: var(--rip-warn);
      font-size: 8px;
      font-weight: 600;
      line-height: 1.15;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .itemHolder .rip-item-sell {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-top: 2px;
      padding: 5px 6px;
      border-radius: 6px;
      border: 1px solid transparent;
      background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
      color: #fff;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.01em;
      line-height: 1.15;
      cursor: pointer;
      pointer-events: auto;
      width: 100%;
      box-sizing: border-box;
      box-shadow:
        0 0 0 1px color-mix(in srgb, var(--rip-primary-from) 35%, transparent),
        0 1px 2px rgba(0,0,0,0.35);
    }
    .itemHolder .rip-item-sell:hover {
      filter: brightness(1.06);
    }
    .itemHolder .rip-item-sell--muted {
      background: rgba(30, 41, 59, 0.95);
      border-color: rgba(255, 255, 255, 0.1);
      color: var(--rip-muted);
      box-shadow: none;
      font-weight: 600;
    }
    .itemHolder .rip-item-sell--link {
      text-decoration: none !important;
    }
    .itemHolder .rip-item-select {
      position: absolute;
      top: 4px;
      right: 4px;
      z-index: 6;
      pointer-events: auto;
      width: 18px;
      height: 18px;
      accent-color: var(--rip-primary-to);
      cursor: pointer;
    }
    .itemHolder[data-rip-bulk-selected="1"] {
      outline: 2px solid var(--rip-link);
      outline-offset: -2px;
    }
    .itemHolder[data-rip-bulk-selected="1"] .${OVERLAY_CLASS} {
      box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--rip-link) 45%, transparent);
    }

    #${HOST_ID} .rip-inv-draft-chip {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 5px 10px;
      border-radius: 999px;
      background: rgba(15, 23, 42, 0.9);
      border: 1px solid rgba(125, 211, 252, 0.28);
      color: var(--rip-link);
      font-size: 11px;
      font-weight: 600;
    }
    #${HOST_ID} .rip-inv-draft-chip button {
      border: 0;
      background: transparent;
      color: var(--rip-muted);
      cursor: pointer;
      font-size: 11px;
      padding: 0;
    }

    #${HOST_ID} .rip-inv-coach {
      margin-bottom: 8px;
      padding: 12px 14px;
      border-radius: var(--rip-radius);
      background:
        linear-gradient(145deg, rgba(2, 132, 199, 0.08), transparent 42%),
        var(--rip-bg);
      border: 1px solid var(--rip-border);
      color: var(--rip-text);
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.28);
    }
    #${HOST_ID} .rip-inv-coach-title {
      margin: 0 0 4px;
      font-size: 14px;
      font-weight: 700;
      color: var(--rip-link);
    }
    #${HOST_ID} .rip-inv-coach-body {
      margin: 0 0 10px;
      color: var(--rip-muted);
      font-size: 12px;
      line-height: 1.4;
    }
    #${HOST_ID} .rip-inv-coach-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      align-items: center;
    }
    #${HOST_ID} .rip-inv-coach-dismiss {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 7px 12px;
      border-radius: var(--rip-radius-sm);
      border: none;
      background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
      color: #fff;
      font-weight: 600;
      font-size: 12px;
      cursor: pointer;
    }
    #${HOST_ID} .rip-inv-coach-hint {
      color: var(--rip-muted);
      font-size: 11px;
    }

    #${HOST_ID} .rip-inv-trial {
      margin: 0 0 10px;
      padding: 10px 12px;
      border-radius: var(--rip-radius-sm);
      border: 1px solid rgba(125, 211, 252, 0.28);
      background: rgba(56, 189, 248, 0.1);
    }
    #${HOST_ID} .rip-inv-trial-title {
      margin: 0 0 4px;
      font-size: 12px;
      font-weight: 700;
      color: var(--rip-link);
    }
    #${HOST_ID} .rip-inv-trial-body {
      margin: 0 0 8px;
      font-size: 11px;
      color: var(--rip-soft);
      line-height: 1.35;
    }
    #${HOST_ID} .rip-inv-trial-dismiss {
      border: 1px solid var(--rip-border);
      border-radius: var(--rip-radius-sm);
      padding: 6px 10px;
      font-size: 11px;
      cursor: pointer;
      background: rgba(15, 23, 42, 0.65);
      color: var(--rip-text);
    }

    #${HOST_ID} .rip-inv-checklist {
      margin-top: 8px;
      padding: 10px 12px;
      border-radius: var(--rip-radius-sm);
      background: var(--rip-elevated-solid);
      border: 1px solid var(--rip-border);
    }
    #${HOST_ID} .rip-inv-checklist[data-ready="1"] {
      border-color: rgba(134, 239, 172, 0.35);
      background: var(--rip-success-bg);
    }
    #${HOST_ID} .rip-inv-checklist-head {
      display: flex;
      flex-wrap: wrap;
      gap: 6px 12px;
      align-items: baseline;
      margin-bottom: 8px;
    }
    #${HOST_ID} .rip-inv-checklist-title {
      margin: 0;
      font-size: 12px;
      font-weight: 700;
      color: var(--rip-text);
    }
    #${HOST_ID} .rip-inv-checklist-summary {
      margin: 0;
      font-size: 11px;
      color: var(--rip-muted);
    }
    #${HOST_ID} .rip-inv-checklist-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: grid;
      gap: 8px;
    }
    #${HOST_ID} .rip-inv-checklist-item {
      display: flex;
      flex-wrap: wrap;
      gap: 8px 12px;
      align-items: flex-start;
      justify-content: space-between;
    }
    #${HOST_ID} .rip-inv-checklist-mark {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      font-size: 11px;
      font-weight: 700;
      flex: 0 0 auto;
      margin-top: 1px;
    }
    #${HOST_ID} .rip-inv-checklist-item[data-ready="1"] .rip-inv-checklist-mark {
      background: var(--rip-success-bg);
      color: var(--rip-success);
      border: 1px solid rgba(134, 239, 172, 0.35);
    }
    #${HOST_ID} .rip-inv-checklist-item[data-ready="0"] .rip-inv-checklist-mark {
      background: rgba(30, 41, 59, 0.85);
      color: var(--rip-muted);
    }
    #${HOST_ID} .rip-inv-checklist-copy {
      flex: 1 1 180px;
      min-width: 0;
    }
    #${HOST_ID} .rip-inv-checklist-label {
      display: block;
      font-size: 12px;
      font-weight: 600;
      color: var(--rip-text);
    }
    #${HOST_ID} .rip-inv-checklist-hint {
      margin: 2px 0 0;
      font-size: 11px;
      color: var(--rip-muted);
      line-height: 1.35;
    }
    #${HOST_ID} .rip-inv-checklist-action {
      display: inline-flex;
      align-items: center;
      padding: 6px 10px;
      border-radius: var(--rip-radius-sm);
      background: rgba(15, 23, 42, 0.65);
      border: 1px solid var(--rip-border);
      color: var(--rip-link) !important;
      text-decoration: none !important;
      font-size: 11px;
      font-weight: 600;
      white-space: nowrap;
    }

    #${BULK_BAR_ID} {
      position: fixed;
      left: 50%;
      bottom: 18px;
      transform: translateX(-50%);
      z-index: 99990;
      display: flex;
      flex-wrap: wrap;
      gap: 8px 10px;
      align-items: center;
      padding: 12px 14px;
      border-radius: var(--rip-radius);
      background: rgba(24, 28, 38, 0.96);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: #f4f4f5;
      font-family: Inter, system-ui, -apple-system, sans-serif;
      font-size: 13px;
      box-shadow: 0 14px 36px rgba(0, 0, 0, 0.5);
      max-width: min(680px, calc(100vw - 24px));
      backdrop-filter: blur(8px);
    }
    #${BULK_BAR_ID} .rip-bulk-count {
      font-weight: 750;
      color: var(--rip-link);
    }
    #${BULK_BAR_ID} .rip-bulk-meta {
      color: var(--rip-muted);
      font-size: 12px;
      max-width: 280px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    #${BULK_BAR_ID} .rip-bulk-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 8px 12px;
      border-radius: 9px;
      border: none;
      font-size: 12px;
      font-weight: 650;
      cursor: pointer;
    }
    #${BULK_BAR_ID} .rip-bulk-btn--primary {
      background: linear-gradient(135deg, #0284c7, #2563eb);
      color: #fff;
    }
    #${BULK_BAR_ID} .rip-bulk-btn--secondary {
      background: rgba(15, 23, 42, 0.85);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: #e2e8f0;
    }
    #${BULK_BAR_ID} .rip-bulk-btn:disabled {
      opacity: 0.55;
      cursor: not-allowed;
    }

    #${SELL_PANEL_ID} {
      position: fixed;
      inset: 0;
      z-index: 99999;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(11, 13, 18, 0.72);
      font-family: Inter, system-ui, -apple-system, sans-serif;
      backdrop-filter: blur(2px);
      --rip-border: rgba(255, 255, 255, 0.08);
      --rip-link: #7dd3fc;
      --rip-muted: #94a3b8;
      --rip-radius-sm: 8px;
    }
    #${SELL_PANEL_ID} .rip-sell-card {
      width: min(440px, calc(100vw - 24px));
      background:
        linear-gradient(160deg, rgba(2, 132, 199, 0.1), transparent 40%),
        rgba(24, 28, 38, 0.98);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 16px;
      padding: 18px;
      color: #f4f4f5;
      box-shadow: 0 20px 48px rgba(0, 0, 0, 0.55);
    }
    #${SELL_PANEL_ID} .rip-sell-eyebrow {
      margin: 0 0 6px;
      font-size: 11px;
      font-weight: 650;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: #7dd3fc;
    }
    #${SELL_PANEL_ID} .rip-sell-name-list {
      list-style: none;
      margin: 0 0 12px;
      padding: 10px 12px;
      border-radius: 12px;
      background: rgba(15, 23, 42, 0.72);
      border: 1px solid rgba(255, 255, 255, 0.08);
      display: grid;
      gap: 6px;
      max-height: 168px;
      overflow: auto;
    }
    #${SELL_PANEL_ID} .rip-sell-name-list li {
      margin: 0;
      font-size: 12.5px;
      line-height: 1.35;
      color: #e2e8f0;
      word-break: break-word;
    }
    #${SELL_PANEL_ID} .rip-sell-name-more {
      margin: -4px 0 12px;
      font-size: 11px;
      color: #94a3b8;
    }
    #${SELL_PANEL_ID} .rip-sell-hero {
      display: flex;
      gap: 12px;
      align-items: flex-start;
      margin-bottom: 12px;
    }
    #${SELL_PANEL_ID} .rip-sell-thumb {
      width: 72px;
      height: 72px;
      border-radius: 10px;
      object-fit: contain;
      background: #0b0d12;
      border: 1px solid rgba(255, 255, 255, 0.08);
      flex-shrink: 0;
    }
    #${SELL_PANEL_ID} .rip-sell-thumb-ph {
      width: 72px;
      height: 72px;
      border-radius: 10px;
      background: #0b0d12;
      border: 1px dashed rgba(255, 255, 255, 0.12);
      flex-shrink: 0;
    }
    #${SELL_PANEL_ID} .rip-sell-hero-text {
      min-width: 0;
      flex: 1;
    }
    #${SELL_PANEL_ID} .rip-sell-title {
      margin: 0 0 4px;
      font-size: 17px;
      font-weight: 750;
      color: #7dd3fc;
    }
    #${SELL_PANEL_ID} .rip-sell-item {
      margin: 0;
      color: #94a3b8;
      font-size: 13px;
      line-height: 1.35;
      word-break: break-word;
    }
    #${SELL_PANEL_ID} .rip-sell-rails {
      margin: 0 0 12px;
      padding: 10px 10px 8px;
      border-radius: var(--rip-radius-sm);
      background: rgba(15, 23, 42, 0.72);
      border: 1px solid var(--rip-border);
    }
    #${SELL_PANEL_ID} .rip-sell-rail {
      display: flex;
      flex-wrap: wrap;
      gap: 6px 10px;
      align-items: center;
      margin: 0 0 6px;
      font-size: 12px;
      color: var(--rip-muted);
      line-height: 1.35;
    }
    #${SELL_PANEL_ID} .rip-sell-rail:last-child {
      margin-bottom: 0;
    }
    #${SELL_PANEL_ID} .rip-sell-rail-apply {
      padding: 3px 8px;
      border-radius: var(--rip-radius-sm);
      border: 1px solid var(--rip-border);
      background: rgba(15, 23, 42, 0.65);
      color: var(--rip-link);
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
    }
    #${SELL_PANEL_ID} .rip-sell-honesty {
      margin: 4px 0 0;
      font-size: 11px;
      color: #7d8494;
      line-height: 1.35;
    }
    #${SELL_PANEL_ID} .rip-sell-label {
      display: block;
      margin-bottom: 4px;
      font-size: 12px;
      color: #7d8494;
    }
    #${SELL_PANEL_ID} .rip-sell-input {
      width: 100%;
      box-sizing: border-box;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid #3a4250;
      background: #0d1016;
      color: #fff;
      font-size: 15px;
      margin-bottom: 8px;
    }
    #${SELL_PANEL_ID} .rip-sell-preview {
      margin: 0 0 12px;
      font-size: 12px;
      color: #a8adb8;
      line-height: 1.4;
    }
    #${SELL_PANEL_ID} .rip-sell-preview strong {
      color: #8fe6a4;
      font-weight: 700;
    }
    #${SELL_PANEL_ID} .rip-sell-error {
      margin: 0 0 10px;
      color: #ffb4a8;
      font-size: 12px;
    }
    #${SELL_PANEL_ID} .rip-sell-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    #${SELL_PANEL_ID} .rip-sell-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 9px 12px;
      border-radius: 8px;
      border: none;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none !important;
    }
    #${SELL_PANEL_ID} .rip-sell-btn:disabled {
      opacity: 0.6;
      cursor: wait;
    }
    #${SELL_PANEL_ID} .rip-sell-btn--primary {
      background: linear-gradient(135deg, #0284c7, #2563eb);
      color: #fff;
    }
    #${SELL_PANEL_ID} .rip-sell-btn--secondary {
      background: rgba(15, 23, 42, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: #e2e8f0;
    }
    #${SELL_PANEL_ID} .rip-sell-preview strong {
      color: #86efac;
    }
    #${SELL_PANEL_ID} .rip-sell-success {
      margin: 0 0 12px;
      color: #8fe6a4;
      font-size: 14px;
      font-weight: 600;
    }

    #${TOAST_ID} {
      position: fixed;
      right: 16px;
      bottom: 16px;
      z-index: 100000;
      max-width: min(360px, calc(100vw - 24px));
      padding: 12px 14px;
      border-radius: 8px;
      background: #181c26;
      border: 1px solid rgba(134, 239, 172, 0.35);
      color: #f4f4f5;
      font-family: Inter, system-ui, -apple-system, sans-serif;
      font-size: 13px;
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.4);
      --rip-link: #7dd3fc;
    }
    #${TOAST_ID} a {
      color: var(--rip-link);
      font-weight: 600;
    }

    /* Selected-item rail \u2014 competitor parity next to Steam green Sell */
    #${SELECTED_SELL_RAIL_ID} {
      display: inline-flex;
      align-items: center;
      margin: 8px 8px 8px 0;
      vertical-align: middle;
      --rip-primary-from: #0284c7;
      --rip-primary-to: #2563eb;
      --rip-border: rgba(255, 255, 255, 0.08);
      --rip-muted: #94a3b8;
      --rip-radius: 12px;
    }
    #${SELECTED_SELL_RAIL_ID} .rip-selected-sell {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 148px;
      padding: 8px 14px;
      border-radius: var(--rip-radius);
      border: none;
      background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
      color: #fff !important;
      font-size: 13px;
      font-weight: 700;
      line-height: 1.2;
      text-decoration: none !important;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(0,0,0,0.35);
      font-family: Inter, system-ui, -apple-system, sans-serif;
    }
    #${SELECTED_SELL_RAIL_ID} .rip-selected-sell:hover {
      filter: brightness(1.07);
    }
    #${SELECTED_SELL_RAIL_ID} .rip-selected-sell--muted {
      background: rgba(15, 23, 42, 0.85);
      border: 1px solid var(--rip-border);
      color: var(--rip-muted) !important;
    }
  `;
    document.documentElement.appendChild(style);
  }
  function findMountParent() {
    return document.querySelector("#inventory_pagecontrols")?.parentElement ?? document.querySelector("#tabcontent_inventory") ?? document.querySelector(".inventory_links")?.parentElement ?? document.querySelector("#mainContents") ?? document.querySelector(".responsive_page_template_content") ?? document.body;
  }
  function ensureHost() {
    let host = document.getElementById(HOST_ID);
    if (host) {
      return host;
    }
    host = document.createElement("section");
    host.id = HOST_ID;
    host.setAttribute("data-rip-inventory-layer", "1");
    host.setAttribute(ATTR_READY, "0");
    host.setAttribute("aria-label", "R.I.P Market inventory layer");
    const parent = findMountParent();
    const controls = document.querySelector("#inventory_pagecontrols");
    if (controls?.parentElement === parent) {
      parent.insertBefore(host, controls);
    } else {
      parent.prepend(host);
    }
    return host;
  }
  function removeHost() {
    if (coachAutoDismissTimer != null) {
      window.clearTimeout(coachAutoDismissTimer);
      coachAutoDismissTimer = null;
    }
    disconnectEnrichObserver();
    document.getElementById(HOST_ID)?.remove();
    clearItemOverlays();
    removeBulkBar();
  }
  async function loadOnboardingState() {
    try {
      const stored = await chrome.storage.local.get(INVENTORY_SELLER_ONBOARDING_KEY);
      return parseOnboardingState(stored[INVENTORY_SELLER_ONBOARDING_KEY]);
    } catch {
      return parseOnboardingState(null);
    }
  }
  async function saveOnboardingState(state) {
    try {
      await chrome.storage.local.set({
        [INVENTORY_SELLER_ONBOARDING_KEY]: state
      });
    } catch {
    }
  }
  async function loadSellerOnboardingFromRuntime() {
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.GET_SELLER_ONBOARDING_STATUS
      });
      if (response?.ok) {
        return {
          connected: Boolean(response.connected),
          tradeUrl: response.tradeUrl ?? null,
          accountUrl: response.accountUrl?.trim() || siteAccountUrl(void 0)
        };
      }
    } catch {
    }
    const session = await getSessionState();
    return {
      connected: Boolean(session?.accessToken && session.apiBaseUrl),
      tradeUrl: null,
      accountUrl: siteAccountUrl(session?.apiBaseUrl)
    };
  }
  async function persistCoachDismiss() {
    if (coachAutoDismissTimer != null) {
      window.clearTimeout(coachAutoDismissTimer);
      coachAutoDismissTimer = null;
    }
    const current = await loadOnboardingState();
    await saveOnboardingState(dismissCoachMark(current));
    void renderHostBar();
  }
  function scheduleCoachAutoDismiss() {
    if (coachAutoDismissTimer != null) {
      return;
    }
    coachAutoDismissTimer = window.setTimeout(() => {
      coachAutoDismissTimer = null;
      void persistCoachDismiss();
    }, COACH_AUTO_DISMISS_MS);
  }
  function clearItemOverlays() {
    disconnectEnrichObserver();
    document.querySelectorAll(`.${OVERLAY_CLASS}`).forEach((node) => node.remove());
    document.querySelectorAll(`[${ENRICH_ATTR}]`).forEach((node) => {
      node.removeAttribute(ENRICH_ATTR);
    });
    document.getElementById(SELECTED_SELL_RAIL_ID)?.remove();
  }
  async function resolveSteamId() {
    return resolveInventoryPageSteamId({
      pathname: window.location.pathname,
      getHtml: () => document.documentElement.innerHTML
    });
  }
  function scheduleSteamEnrichmentRecovery() {
    if (steamEnrichmentRetryTimer != null) {
      return;
    }
    steamEnrichmentRetryTimer = window.setTimeout(() => {
      steamEnrichmentRetryTimer = null;
      void enrichItemCards(true).then(() => {
        void renderHostBar();
      });
    }, STEAM_ENRICHMENT_RECOVERY_MS);
  }
  async function loadSteamFactsFromPageMain(steamId) {
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.GET_INVENTORY_PAGE_FACTS,
        steamId
      });
      return {
        facts: Array.isArray(response?.facts) ? response.facts : [],
        source: response?.source ?? "empty",
        error: response?.error
      };
    } catch (error) {
      return {
        facts: [],
        source: "empty",
        error: error instanceof Error ? error.message : "Steam page enrichment failed"
      };
    }
  }
  async function loadSteamFacts(force = false) {
    const now = Date.now();
    if (!force && steamFactsCache && now - steamFactsCache.fetchedAt < STEAM_FACTS_TTL_MS) {
      return steamFactsCache.byAssetId;
    }
    if (steamFactsInflight) {
      return steamFactsInflight;
    }
    if (!await canProceedPastRateLimit()) {
      return steamFactsCache?.byAssetId ?? /* @__PURE__ */ new Map();
    }
    const steamId = await resolveSteamId();
    steamFactsInflight = (async () => {
      const pageLoad = await loadSteamFactsFromPageMain(steamId);
      if (pageLoad.facts.length > 0) {
        const byAssetId = inventoryItemSteamFactsToMap(pageLoad.facts);
        steamFactsCache = { fetchedAt: Date.now(), byAssetId };
        steamEnrichmentDegraded = false;
        if (steamEnrichmentRetryTimer != null) {
          window.clearTimeout(steamEnrichmentRetryTimer);
          steamEnrichmentRetryTimer = null;
        }
        scheduleHostRender();
        return byAssetId;
      }
      if (steamId) {
        try {
          const byAssetId = await fetchCs2InventoryEnrichmentFacts(steamId);
          if (byAssetId.size > 0) {
            steamFactsCache = { fetchedAt: Date.now(), byAssetId };
            steamEnrichmentDegraded = false;
            if (steamEnrichmentRetryTimer != null) {
              window.clearTimeout(steamEnrichmentRetryTimer);
              steamEnrichmentRetryTimer = null;
            }
            scheduleHostRender();
            return byAssetId;
          }
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          if (/HTTP 429|rate.?limit/i.test(message)) {
            void noteRateLimitHit();
          }
          console.warn(
            "[rip-market] inventory enrichment API fallback failed",
            error
          );
        }
      }
      console.warn(
        "[rip-market] inventory enrichment unavailable",
        pageLoad.error ?? "no Steam facts"
      );
      steamEnrichmentDegraded = true;
      scheduleSteamEnrichmentRecovery();
      scheduleHostRender();
      return steamFactsCache?.byAssetId ?? /* @__PURE__ */ new Map();
    })().finally(() => {
      steamFactsInflight = null;
    });
    return steamFactsInflight;
  }
  async function loadPlatformFacts(force = false) {
    const now = Date.now();
    if (!force && platformFactsCache && now - platformFactsCache.fetchedAt < PLATFORM_FACTS_TTL_MS) {
      return platformFactsCache.byAssetId;
    }
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.GET_INVENTORY_PLATFORM_STATUS
      });
      const byAssetId = response?.ok ? response.byAssetId ?? {} : {};
      platformFactsCache = { fetchedAt: Date.now(), byAssetId };
      return byAssetId;
    } catch {
      return platformFactsCache?.byAssetId ?? {};
    }
  }
  async function loadPriceHints(marketHashNames, force = false) {
    const now = Date.now();
    if (!force && priceHintsCache && now - priceHintsCache.fetchedAt < PRICE_HINTS_TTL_MS) {
      const missing = marketHashNames.filter((name) => !priceHintsCache.byName[name]);
      if (missing.length === 0) {
        return priceHintsCache.byName;
      }
    }
    if (marketHashNames.length === 0) {
      return priceHintsCache?.byName ?? {};
    }
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.GET_INVENTORY_PRICE_HINTS,
        marketHashNames,
        cacheOnly: true
      });
      const next = {
        ...priceHintsCache?.byName ?? {},
        ...response?.ok ? response.hints ?? {} : {}
      };
      priceHintsCache = { fetchedAt: Date.now(), byName: next };
      return next;
    } catch {
      return priceHintsCache?.byName ?? {};
    }
  }
  function renderOverlayHtml(view, platform, sellAction, assetId, options) {
    const badges = view.badges.slice(0, 2).map((badge) => {
      const href = badge.kind === "listed" ? platform?.lotUrl : badge.kind === "in_deal" ? platform?.orderUrl : null;
      const className = `rip-item-badge rip-item-badge--${badge.tone}`;
      if (href) {
        return `<a class="${className}" href="${escapeHtml(href)}" target="_blank" rel="noreferrer">${escapeHtml(badge.label)}</a>`;
      }
      return `<span class="${className}">${escapeHtml(badge.label)}</span>`;
    }).join("");
    const wear = view.wearPointerPercent != null ? `<div class="rip-item-wear-track" aria-hidden="true"><i class="rip-item-wear-pointer" style="left:${view.wearPointerPercent.toFixed(2)}%"></i></div>` : "";
    const meta = view.metaLine ? `<div class="rip-item-meta">${escapeHtml(view.metaLine)}</div>` : "";
    const priceCompact = view.priceCompact ? `<div class="rip-item-price">${escapeHtml(view.priceCompact)}</div>` : "";
    const priceSecondary = view.priceSecondary ? `<div class="rip-item-price-sub">${escapeHtml(view.priceSecondary)}</div>` : "";
    const priceNet = view.priceNet ? `<div class="rip-item-price-net">${escapeHtml(view.priceNet)}</div>` : "";
    const priceBid = view.priceBid && view.priceCompact !== view.priceBid ? `<div class="rip-item-price-bid">${escapeHtml(view.priceBid)}</div>` : "";
    const detailParts = [meta, priceSecondary, priceBid, priceNet].filter(Boolean);
    const detail = detailParts.length > 0 ? `<div class="rip-item-detail">${detailParts.join("")}</div>` : "";
    const selectBox = options.bulkMode && options.connected ? `<input class="rip-item-select" type="checkbox" data-rip-bulk-asset="${escapeHtml(assetId)}" ${options.selected ? "checked" : ""} ${options.selectable ? "" : "disabled"} aria-label="\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0434\u043B\u044F \u043F\u0440\u043E\u0434\u0430\u0436\u0438" />` : "";
    let sellCta = "";
    if (!options.bulkMode) {
      if (sellAction.kind === "open_lot" && sellAction.lotUrl) {
        sellCta = `<a class="rip-item-sell rip-item-sell--link" href="${escapeHtml(sellAction.lotUrl)}" target="_blank" rel="noreferrer" data-rip-sell-kind="open_lot" aria-label="\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043B\u043E\u0442 \u043D\u0430 R.I.P">${escapeHtml(sellAction.label)}</a>`;
      } else if (sellAction.kind === "manage") {
        sellCta = `<button type="button" class="rip-item-sell" data-rip-sell-kind="manage" data-rip-sell-asset="${escapeHtml(assetId)}" data-rip-lot-id="${escapeHtml(sellAction.lotId ?? "")}" aria-label="\u0423\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C \u043B\u043E\u0442\u043E\u043C \u043D\u0430 R.I.P">${escapeHtml(sellAction.label)}</button>`;
      } else {
        const muted = sellAction.kind === "blocked" ? " rip-item-sell--muted" : "";
        sellCta = `<button type="button" class="rip-item-sell${muted}" data-rip-sell-kind="${escapeHtml(sellAction.kind)}" data-rip-sell-asset="${escapeHtml(assetId)}" aria-label="\u041F\u0440\u043E\u0434\u0430\u0442\u044C \u043D\u0430 R.I.P">${escapeHtml(sellAction.label)}</button>`;
      }
    }
    const badgesBlock = badges ? `<div class="rip-item-badges">${badges}</div>` : `<div class="rip-item-badges" aria-hidden="true"></div>`;
    return `
    ${selectBox}
    ${badgesBlock}
    <div class="rip-item-footer">${wear}${priceCompact}${detail}${sellCta}</div>
  `;
  }
  function buildSellHeroHtml(ctx) {
    const thumb = ctx.iconUrl ? `<img class="rip-sell-thumb" src="${escapeHtml(ctx.iconUrl)}" alt="" />` : `<div class="rip-sell-thumb-ph" aria-hidden="true"></div>`;
    return `
    <div class="rip-sell-hero">
      ${thumb}
      <div class="rip-sell-hero-text">
        <p class="rip-sell-title">${escapeHtml(ctx.title)}</p>
        <p class="rip-sell-item">${escapeHtml(ctx.marketHashName)}</p>
      </div>
    </div>`;
  }
  function buildSellPriceRailsHtml(hint) {
    const rails = resolveSellPanelPriceRails(hint);
    const rows = [];
    if (rails.steamLine) {
      rows.push(`<div class="rip-sell-rail">${escapeHtml(rails.steamLine)}</div>`);
    }
    if (rails.medianLine) {
      rows.push(`<div class="rip-sell-rail">${escapeHtml(rails.medianLine)}</div>`);
    }
    if (rails.recommendedLine && rails.recommendedMinor != null) {
      rows.push(`
      <div class="rip-sell-rail">
        <span>${escapeHtml(rails.recommendedLine)}</span>
        <button type="button" class="rip-sell-rail-apply" data-rip-apply-price="${rails.recommendedMinor}">\u041F\u043E\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u044C</button>
      </div>`);
    }
    if (rails.bidLine) {
      rows.push(`<div class="rip-sell-rail">${escapeHtml(rails.bidLine)}</div>`);
    }
    if (rails.honestyLine) {
      rows.push(
        `<p class="rip-sell-honesty">${escapeHtml(rails.honestyLine)}</p>`
      );
    }
    if (rows.length === 0) {
      return "";
    }
    return `<div class="rip-sell-rails">${rows.join("")}</div>`;
  }
  function closeSellPanel() {
    document.getElementById(SELL_PANEL_ID)?.remove();
  }
  function showSellToast(params) {
    document.getElementById(TOAST_ID)?.remove();
    const toast = document.createElement("div");
    toast.id = TOAST_ID;
    const links = [];
    if (params.lotUrl) {
      links.push(
        `<a href="${escapeHtml(params.lotUrl)}" target="_blank" rel="noreferrer">\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043B\u043E\u0442</a>`
      );
    }
    if (params.listingsUrl) {
      links.push(
        `<a href="${escapeHtml(params.listingsUrl)}" target="_blank" rel="noreferrer">\u041C\u043E\u0438 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F</a>`
      );
    }
    toast.innerHTML = `<div>${escapeHtml(params.message)}</div>${links.length ? `<div style="margin-top:8px;display:flex;gap:10px;flex-wrap:wrap">${links.join("")}</div>` : ""}`;
    document.documentElement.appendChild(toast);
    window.setTimeout(() => toast.remove(), 8e3);
  }
  function updateSellPreview(panel) {
    const input = panel.querySelector(".rip-sell-input");
    const previewEl = panel.querySelector("[data-rip-sell-commission]");
    const errorEl = panel.querySelector(".rip-sell-error");
    if (!input || !previewEl) {
      return;
    }
    const priceMinor = parseUsdInputToMinor(input.value);
    const preview = priceMinor != null ? buildInventorySellPreview(priceMinor) : null;
    if (!preview) {
      previewEl.textContent = "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0446\u0435\u043D\u0443 \u2014 \u043F\u043E\u043A\u0430\u0436\u0435\u043C \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u044E \u0438 \xAB\u0432\u0430\u043C\xBB.";
      if (errorEl && input.value.trim()) {
        errorEl.textContent = validateCreateLotPriceMinor(null) ?? "";
      } else if (errorEl) {
        errorEl.textContent = "";
      }
      return;
    }
    previewEl.innerHTML = `${escapeHtml(preview.commissionLine)} \xB7 <strong>${escapeHtml(preview.receiveLine)}</strong>`;
    if (errorEl) {
      errorEl.textContent = "";
    }
  }
  function openSellPanel(ctx) {
    ensureStyles();
    closeSellPanel();
    const panel = document.createElement("div");
    panel.id = SELL_PANEL_ID;
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    panel.setAttribute("aria-label", "\u041F\u0440\u043E\u0434\u0430\u0442\u044C \u043D\u0430 R.I.P");
    if (ctx.action.kind === "pair") {
      panel.innerHTML = `
      <div class="rip-sell-card">
        ${buildSellHeroHtml({
        title: "\u041F\u0440\u043E\u0434\u0430\u0442\u044C \u043D\u0430 R.I.P",
        marketHashName: ctx.marketHashName,
        iconUrl: ctx.iconUrl
      })}
        <p class="rip-sell-preview">${escapeHtml(ctx.action.blockMessage ?? "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435.")}</p>
        <div class="rip-sell-actions">
          <a class="rip-sell-btn rip-sell-btn--primary" href="${escapeHtml(ctx.accountUrl)}" target="_blank" rel="noreferrer">\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435</a>
          <button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-sell-close>\u041E\u0442\u043C\u0435\u043D\u0430</button>
        </div>
      </div>
    `;
    } else if (ctx.action.kind === "blocked") {
      panel.innerHTML = `
      <div class="rip-sell-card">
        ${buildSellHeroHtml({
        title: "\u041F\u043E\u043A\u0430 \u043D\u0435\u043B\u044C\u0437\u044F \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C",
        marketHashName: ctx.marketHashName,
        iconUrl: ctx.iconUrl
      })}
        <p class="rip-sell-preview">${escapeHtml(ctx.action.blockMessage ?? "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u043D\u0435\u043B\u044C\u0437\u044F \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441.")}</p>
        <div class="rip-sell-actions">
          ${ctx.action.lotUrl ? `<a class="rip-sell-btn rip-sell-btn--primary" href="${escapeHtml(ctx.action.lotUrl)}" target="_blank" rel="noreferrer">${ctx.action.blockReason === "active_trade_task" || ctx.action.blockReason === "in_deal" ? "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437" : "\u041E\u0442\u043A\u0440\u044B\u0442\u044C"}</a>` : `<a class="rip-sell-btn rip-sell-btn--primary" href="${escapeHtml(ctx.sellUrl)}" target="_blank" rel="noreferrer">\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435</a>`}
          <button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-sell-close>\u0417\u0430\u043A\u0440\u044B\u0442\u044C</button>
        </div>
      </div>
    `;
    } else {
      const bidOffer = resolveBidListOffer(ctx.priceHint);
      const draftPrice = sellDraftPriceByAsset?.assetId === ctx.assetId ? sellDraftPriceByAsset.priceInput : null;
      const defaultValue = draftPrice ?? (ctx.defaultPriceMinor != null ? formatUsdInputFromMinor(ctx.defaultPriceMinor) : "");
      const bidBlock = bidOffer.available ? `
        <p class="rip-sell-preview" data-rip-bid-hint>${escapeHtml(bidOffer.hintLine ?? "")}</p>
        <p class="rip-sell-preview" style="color:#7d8494;font-size:11px">${escapeHtml(bidOffer.honestyLine)}</p>
        <div class="rip-sell-actions" style="margin-bottom:10px">
          <button type="button" class="rip-sell-btn rip-sell-btn--primary" data-rip-sell-bid>${escapeHtml(bidOffer.buttonLabel ?? "\u041F\u043E bid")}</button>
        </div>
      ` : "";
      panel.innerHTML = `
      <div class="rip-sell-card">
        ${buildSellHeroHtml({
        title: "\u041F\u0440\u043E\u0434\u0430\u0442\u044C \u043D\u0430 R.I.P",
        marketHashName: ctx.marketHashName,
        iconUrl: ctx.iconUrl
      })}
        ${buildSellPriceRailsHtml(ctx.priceHint)}
        ${bidBlock}
        <label class="rip-sell-label" for="rip-sell-price">\u0426\u0435\u043D\u0430 ($)</label>
        <input id="rip-sell-price" class="rip-sell-input" type="text" inputmode="decimal" autocomplete="off" value="${escapeHtml(defaultValue)}" placeholder="0.00" />
        <p class="rip-sell-preview" data-rip-sell-commission></p>
        <p class="rip-sell-error" data-testid="rip-sell-error"></p>
        <div class="rip-sell-actions">
          <button type="button" class="rip-sell-btn rip-sell-btn--primary" data-rip-sell-confirm>\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C</button>
          <button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-sell-close>\u041E\u0442\u043C\u0435\u043D\u0430</button>
        </div>
      </div>
    `;
    }
    document.documentElement.appendChild(panel);
    updateSellPreview(panel);
    panel.addEventListener("click", (event) => {
      const target = event.target;
      if (target === panel || target?.closest?.("[data-rip-sell-close]")) {
        closeSellPanel();
      }
    });
    panel.querySelector(".rip-sell-input")?.addEventListener("input", () => {
      const input = panel.querySelector(".rip-sell-input");
      const value = input?.value?.trim() ?? "";
      if (value) {
        sellDraftPriceByAsset = {
          assetId: ctx.assetId,
          priceInput: value
        };
      } else if (sellDraftPriceByAsset?.assetId === ctx.assetId) {
        sellDraftPriceByAsset = null;
      }
      persistSellDraft();
      updateSellPreview(panel);
    });
    panel.querySelectorAll("[data-rip-apply-price]").forEach((button) => {
      button.addEventListener("click", () => {
        const minor = Number(button.dataset.ripApplyPrice);
        const input = panel.querySelector(".rip-sell-input");
        if (!input || !Number.isFinite(minor) || minor <= 0) {
          return;
        }
        input.value = formatUsdInputFromMinor(minor);
        sellDraftPriceByAsset = {
          assetId: ctx.assetId,
          priceInput: input.value
        };
        persistSellDraft();
        updateSellPreview(panel);
      });
    });
    panel.querySelector("[data-rip-sell-confirm]")?.addEventListener("click", () => {
      void submitSellFromPanel(panel, ctx);
    });
    panel.querySelector("[data-rip-sell-bid]")?.addEventListener("click", () => {
      const bidOffer = resolveBidListOffer(ctx.priceHint);
      const input = panel.querySelector(".rip-sell-input");
      if (!bidOffer.available || bidOffer.priceMinor == null || !input) {
        return;
      }
      input.value = formatUsdInputFromMinor(bidOffer.priceMinor);
      updateSellPreview(panel);
      void submitSellFromPanel(panel, ctx);
    });
    panel.querySelector(".rip-sell-input")?.focus();
  }
  async function submitSellFromPanel(panel, ctx) {
    const input = panel.querySelector(".rip-sell-input");
    const errorEl = panel.querySelector(".rip-sell-error");
    const confirmBtn = panel.querySelector(
      "[data-rip-sell-confirm]"
    );
    const bidBtn = panel.querySelector("[data-rip-sell-bid]");
    const priceMinor = parseUsdInputToMinor(input?.value ?? "");
    const priceError = validateCreateLotPriceMinor(priceMinor);
    if (priceError || priceMinor == null) {
      if (errorEl) {
        errorEl.textContent = priceError ?? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0446\u0435\u043D\u0443";
      }
      return;
    }
    const setBusy = (busy, label = "\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C") => {
      if (confirmBtn) {
        confirmBtn.disabled = busy;
        confirmBtn.textContent = busy ? "\u0412\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u043C\u2026" : label;
      }
      if (bidBtn) {
        bidBtn.disabled = busy;
      }
    };
    setBusy(true);
    if (errorEl) {
      errorEl.textContent = "";
    }
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.CREATE_INVENTORY_LOT,
        steamAssetId: ctx.assetId,
        inventoryAssetId: ctx.inventoryAssetId,
        priceMinor
      });
      if (!response?.ok) {
        const code = response?.errorCode ?? null;
        const message = humanizeListingApiError({
          code,
          message: response?.error
        });
        if (errorEl) {
          errorEl.textContent = message;
        }
        const hardBan = isHardSteamTradeBanCode(code);
        if (confirmBtn) {
          confirmBtn.disabled = hardBan;
          confirmBtn.textContent = hardBan ? "\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043D\u0435\u043B\u044C\u0437\u044F" : isRetryableLabel(code) ? "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C" : "\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C";
        }
        if (bidBtn) {
          bidBtn.disabled = hardBan;
        }
        return;
      }
      void recordTwoMinuteFirstList().catch(() => void 0);
      if (sellDraftPriceByAsset?.assetId === ctx.assetId) {
        sellDraftPriceByAsset = null;
      }
      bulkSelected.delete(ctx.assetId);
      persistSellDraft();
      const card = panel.querySelector(".rip-sell-card");
      if (card) {
        card.innerHTML = `
        <p class="rip-sell-title">\u0412\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E</p>
        <p class="rip-sell-success">\u041B\u043E\u0442 \u043D\u0430 R.I.P \u0441\u043E\u0437\u0434\u0430\u043D.</p>
        <p class="rip-sell-item">${escapeHtml(ctx.marketHashName)}</p>
        <div class="rip-sell-actions">
          ${response.lotUrl ? `<a class="rip-sell-btn rip-sell-btn--primary" href="${escapeHtml(response.lotUrl)}" target="_blank" rel="noreferrer">\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043B\u043E\u0442</a>` : ""}
          ${response.listingsUrl ? `<a class="rip-sell-btn rip-sell-btn--secondary" href="${escapeHtml(response.listingsUrl)}" target="_blank" rel="noreferrer">\u041C\u043E\u0438 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F</a>` : ""}
          <button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-sell-close>\u0417\u0430\u043A\u0440\u044B\u0442\u044C</button>
        </div>
      `;
        card.querySelector("[data-rip-sell-close]")?.addEventListener("click", () => closeSellPanel());
      }
      showSellToast({
        message: "\u041B\u043E\u0442 \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D \u043D\u0430 R.I.P",
        lotUrl: response.lotUrl,
        listingsUrl: response.listingsUrl
      });
      platformFactsCache = null;
      scheduleEnrichment(false);
    } catch (error) {
      if (errorEl) {
        errorEl.textContent = humanizeListingApiError({
          message: error instanceof Error ? error.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043B\u043E\u0442"
        });
      }
      setBusy(false);
    }
  }
  function isRetryableLabel(code) {
    return code === "STEAM_BAN_CHECK_UNAVAILABLE";
  }
  function applyEnrichmentToHolder(holder, steamFacts, platformFacts, priceHints, connected) {
    const item = holder.querySelector(CS2_INVENTORY_ITEM_SELECTOR);
    const assetId = parseAssetIdFromItemElementId(item?.id);
    if (!assetId || !item) {
      return;
    }
    const steam = steamFacts.get(assetId) ?? {
      assetId,
      marketHashName: platformFacts[assetId]?.marketHashName ?? null,
      floatValue: null,
      paintSeed: null,
      wear: null,
      tradable: true,
      marketable: true,
      tradeLockUntil: null
    };
    const platform = platformFacts[assetId] ?? null;
    const resolvedName = steam.marketHashName?.trim() || platform?.marketHashName?.trim() || null;
    const priceHint = resolvedName ? priceHints[resolvedName] ?? null : null;
    const view = buildInventoryItemEnrichmentView({
      steam: { ...steam, marketHashName: resolvedName },
      platform,
      priceHint
    });
    const sellAction = resolveInventorySellAction({
      connected,
      siteSafeMode: lastSiteSafeMode,
      steam: { ...steam, marketHashName: resolvedName },
      platform
    });
    const mountRoot = item;
    let overlay = mountRoot.querySelector(`.${OVERLAY_CLASS}`);
    if (!overlay) {
      holder.querySelector(`.${OVERLAY_CLASS}`)?.remove();
      overlay = document.createElement("div");
      overlay.className = OVERLAY_CLASS;
      overlay.setAttribute("data-rip-asset-id", assetId);
      mountRoot.appendChild(overlay);
    }
    overlay.setAttribute(
      "data-rip-inventory-asset-id",
      platform?.inventoryAssetId ?? ""
    );
    overlay.setAttribute("data-rip-lot-id", platform?.lotId ?? "");
    overlay.setAttribute(
      "data-rip-listed-price-minor",
      platform?.listedPriceMinor ?? ""
    );
    overlay.setAttribute("data-rip-market-hash-name", resolvedName ?? "");
    const defaultMinor = resolveDefaultListPriceMinor(priceHint);
    if (defaultMinor != null) {
      overlay.setAttribute("data-rip-default-price-minor", String(defaultMinor));
    } else {
      overlay.removeAttribute("data-rip-default-price-minor");
    }
    overlay.innerHTML = renderOverlayHtml(
      view,
      platform,
      sellAction,
      assetId,
      {
        bulkMode,
        selected: bulkSelected.has(assetId),
        connected,
        selectable: canSelectForBulkSell({
          connected,
          steam: {
            tradable: steam.tradable,
            marketable: steam.marketable,
            tradeLockUntil: steam.tradeLockUntil
          },
          platform
        })
      }
    );
    holder.setAttribute(ENRICH_ATTR, "1");
    holder.setAttribute(
      "data-rip-bulk-selected",
      bulkMode && bulkSelected.has(assetId) ? "1" : "0"
    );
  }
  function disconnectEnrichObserver() {
    enrichObserver?.disconnect();
    enrichObserver = null;
    deferredEnrichQueue = [];
    deferredEnrichContext = null;
    if (deferredEnrichRaf != null) {
      cancelAnimationFrame(deferredEnrichRaf);
      deferredEnrichRaf = null;
    }
  }
  function flushDeferredEnrichBatch() {
    deferredEnrichRaf = null;
    const ctx = deferredEnrichContext;
    if (!ctx || deferredEnrichQueue.length === 0) {
      return;
    }
    const batch = deferredEnrichQueue.splice(0, LAZY_ENRICH_BATCH_SIZE);
    for (const holder of batch) {
      if (!holder.isConnected) {
        continue;
      }
      if (holder.getAttribute(ENRICH_ATTR) === "1") {
        continue;
      }
      applyEnrichmentToHolder(
        holder,
        ctx.steamFacts,
        ctx.platformFacts,
        ctx.priceHints,
        ctx.connected
      );
    }
    if (deferredEnrichQueue.length > 0) {
      deferredEnrichRaf = window.requestAnimationFrame(() => {
        flushDeferredEnrichBatch();
      });
    }
  }
  function enqueueDeferredEnrich(holders) {
    for (const holder of holders) {
      deferredEnrichQueue.push(holder);
    }
    if (deferredEnrichRaf == null && deferredEnrichQueue.length > 0) {
      deferredEnrichRaf = window.requestAnimationFrame(() => {
        flushDeferredEnrichBatch();
      });
    }
  }
  function ensureEnrichObserver() {
    if (enrichObserver) {
      return enrichObserver;
    }
    enrichObserver = new IntersectionObserver(
      (entries) => {
        const due = [];
        for (const entry of entries) {
          if (!entry.isIntersecting) {
            continue;
          }
          const holder = entry.target;
          enrichObserver?.unobserve(holder);
          if (holder.getAttribute(ENRICH_ATTR) === "1") {
            continue;
          }
          due.push(holder);
        }
        if (due.length > 0) {
          enqueueDeferredEnrich(due);
        }
      },
      {
        root: null,
        rootMargin: `${LAZY_ENRICH_VIEWPORT_MARGIN_PX}px`,
        threshold: 0.01
      }
    );
    return enrichObserver;
  }
  function paintInventoryOverlays(params) {
    const cells = listPaintableCs2InventoryCells(document);
    const holders = cells.map((cell) => cell.holder);
    if (holders.length === 0) {
      const cs2Cells = document.querySelectorAll(CS2_INVENTORY_ITEM_SELECTOR).length;
      if (cs2Cells > 0) {
        console.warn(
          "[rip-market] inventory overlay: CS2 cells present but no paintable holders",
          { cs2Cells }
        );
      }
    }
    deferredEnrichContext = {
      steamFacts: params.steamFacts,
      platformFacts: params.platformFacts,
      priceHints: params.priceHints,
      connected: params.connected
    };
    const { immediate, deferred } = holders.length > 80 ? partitionHoldersForEnrich(holders) : { immediate: holders, deferred: [] };
    for (const holder of immediate) {
      holder.removeAttribute(ENRICH_ATTR);
      applyEnrichmentToHolder(
        holder,
        params.steamFacts,
        params.platformFacts,
        params.priceHints,
        params.connected
      );
    }
    const observer = ensureEnrichObserver();
    for (const holder of deferred) {
      holder.removeAttribute(ENRICH_ATTR);
      observer.observe(holder);
    }
    renderBulkBar();
    syncSelectedSellRail({
      steamFacts: params.steamFacts,
      platformFacts: params.platformFacts,
      priceHints: params.priceHints,
      connected: params.connected
    });
  }
  function syncSelectedSellRail(params) {
    const actionsRoot = findVisibleItemActionsRoot(document);
    if (!actionsRoot) {
      document.getElementById(SELECTED_SELL_RAIL_ID)?.remove();
      return;
    }
    const selected = readSelectedCs2ItemFromDom(document, {
      lastClickedAssetId
    });
    const model = buildSelectedSellRailModel({
      selected,
      connected: params.connected,
      siteSafeMode: lastSiteSafeMode,
      label: "\u041F\u0440\u043E\u0434\u0430\u0442\u044C \u043D\u0430 R.I.P"
    });
    let rail = document.getElementById(SELECTED_SELL_RAIL_ID);
    if (!model.visible || !model.assetId) {
      rail?.remove();
      return;
    }
    if (!rail || rail.parentElement !== actionsRoot) {
      rail?.remove();
      rail = document.createElement("span");
      rail.id = SELECTED_SELL_RAIL_ID;
      const steamSell = actionsRoot.querySelector(
        'a.item_market_action_button_green, a.item_market_action_button, a[href*="SellCurrentSelection"]'
      );
      if (steamSell?.nextSibling) {
        actionsRoot.insertBefore(rail, steamSell.nextSibling);
      } else if (steamSell) {
        steamSell.insertAdjacentElement("afterend", rail);
      } else {
        actionsRoot.appendChild(rail);
      }
    }
    const muted = model.kind === "blocked" ? " rip-selected-sell--muted" : "";
    rail.innerHTML = `<button type="button" class="rip-selected-sell${muted}" data-rip-sell-kind="${escapeHtml(model.kind)}" data-rip-sell-asset="${escapeHtml(model.assetId)}" aria-label="\u041F\u0440\u043E\u0434\u0430\u0442\u044C \u043D\u0430 R.I.P">${escapeHtml(model.label)}</button>`;
  }
  async function enrichItemCards(forceSteam = false) {
    if (!isCs2InventoryActive({
      pathname: window.location.pathname,
      hash: window.location.hash,
      document
    })) {
      clearItemOverlays();
      removeBulkBar();
      document.getElementById(SELECTED_SELL_RAIL_ID)?.remove();
      disconnectEnrichObserver();
      return;
    }
    ensureStyles();
    const domFacts = buildDomBaselineSteamFacts(document);
    paintInventoryOverlays({
      steamFacts: steamFactsCache?.byAssetId ? mergeSteamFactsMaps(domFacts, steamFactsCache.byAssetId) : domFacts,
      platformFacts: platformFactsCache?.byAssetId ?? {},
      priceHints: priceHintsCache?.byName ?? {},
      connected: lastConnected
    });
    if (!isExtensionContextValid()) {
      extensionContextInvalidated = true;
      scheduleHostRender();
      return;
    }
    let connected = lastConnected;
    try {
      const session = await getSessionState();
      connected = Boolean(session?.accessToken && session.apiBaseUrl);
      lastConnected = connected;
      extensionContextInvalidated = false;
    } catch {
      extensionContextInvalidated = !isExtensionContextValid();
      connected = false;
      lastConnected = false;
    }
    if (!connected && bulkMode) {
      bulkMode = false;
      bulkSelected = /* @__PURE__ */ new Set();
    }
    const platformFacts = connected ? await loadPlatformFacts(false) : {};
    const namedDom = applyPlatformNamesToSteamFacts(domFacts, platformFacts);
    steamFactsCache = {
      fetchedAt: steamFactsCache?.fetchedAt ?? Date.now(),
      byAssetId: namedDom
    };
    const earlyNames = [];
    for (const fact of namedDom.values()) {
      if (fact.marketHashName) {
        earlyNames.push(fact.marketHashName);
      }
    }
    const earlyHints = connected ? await loadPriceHints(earlyNames, false) : {};
    paintInventoryOverlays({
      steamFacts: namedDom,
      platformFacts,
      priceHints: earlyHints,
      connected
    });
    tryRestoreSellDraft(new Set(namedDom.keys()));
    steamEnrichmentDegraded = false;
    scheduleHostRender();
    void (async () => {
      if (!isExtensionContextValid()) {
        extensionContextInvalidated = true;
        scheduleHostRender();
        return;
      }
      const enriched = await loadSteamFacts(forceSteam);
      const merged = applyPlatformNamesToSteamFacts(
        mergeSteamFactsMaps(namedDom, enriched),
        platformFacts
      );
      steamFactsCache = { fetchedAt: Date.now(), byAssetId: merged };
      const names = [];
      for (const fact of merged.values()) {
        if (fact.marketHashName) {
          names.push(fact.marketHashName);
        }
      }
      const priceHints = connected ? await loadPriceHints(names, false) : {};
      const enrichmentEmpty = enriched.size === 0 && namedDom.size > 0;
      steamEnrichmentDegraded = enrichmentEmpty;
      scheduleHostRender();
      paintInventoryOverlays({
        steamFacts: merged,
        platformFacts,
        priceHints,
        connected
      });
    })().catch((error) => {
      console.warn("[rip-market] progressive inventory enrichment failed", error);
      if (!isExtensionContextValid()) {
        extensionContextInvalidated = true;
      }
      steamEnrichmentDegraded = true;
      scheduleHostRender();
    });
  }
  async function renderHostBar() {
    if (!isSteamInventoryPath(window.location.pathname)) {
      removeHost();
      removeBulkBar();
      return;
    }
    const cs2Active = isCs2InventoryActive({
      pathname: window.location.pathname,
      hash: window.location.hash,
      document
    });
    if (!cs2Active) {
      removeHost();
      removeBulkBar();
      return;
    }
    ensureStyles();
    const host = ensureHost();
    if (!isExtensionContextValid()) {
      extensionContextInvalidated = true;
    }
    const session = extensionContextInvalidated ? null : await getSessionState();
    const connected = Boolean(session?.accessToken && session.apiBaseUrl);
    if (!extensionContextInvalidated) {
      lastConnected = connected;
    }
    if (!connected && bulkMode) {
      bulkMode = false;
      bulkSelected = /* @__PURE__ */ new Set();
    }
    const itemHolderCount = countVisibleCs2InventoryItemHolders(document);
    let siteLinkSafeMode = lastSiteSafeMode;
    if (!extensionContextInvalidated) {
      try {
        const siteLink = await getStoredSiteLinkSnapshot();
        siteLinkSafeMode = Boolean(siteLink.safeMode);
      } catch {
        extensionContextInvalidated = !isExtensionContextValid();
      }
    }
    lastSiteSafeMode = siteLinkSafeMode;
    if (connected && !extensionContextInvalidated) {
      void recordTwoMinuteInventoryVisit().catch(() => void 0);
    }
    const view = resolveInventoryLayerView({
      connected: connected && !extensionContextInvalidated,
      siteSafeMode: lastSiteSafeMode,
      sellUrl: siteSellInventoryUrl(session?.apiBaseUrl),
      listingsUrl: siteListingsPageUrl(session?.apiBaseUrl),
      accountUrl: siteAccountUrl(session?.apiBaseUrl),
      itemHolderCount
    });
    const [onboardingState, sellerStatus, locale] = extensionContextInvalidated ? [
      parseOnboardingState(null),
      {
        connected: false,
        tradeUrl: null,
        accountUrl: siteAccountUrl(null)
      },
      "ru"
    ] : await Promise.all([
      loadOnboardingState(),
      loadSellerOnboardingFromRuntime(),
      getStoredExtensionLocale()
    ]);
    const t = createExtensionT(locale);
    const checklist = resolveSellerChecklistView({
      extensionConnected: sellerStatus.connected || connected,
      tradeUrl: sellerStatus.tradeUrl,
      accountUrl: sellerStatus.accountUrl || siteAccountUrl(session?.apiBaseUrl),
      locale
    });
    const coach = resolveCoachMarkView({ state: onboardingState, locale });
    const twoMinState = extensionContextInvalidated ? defaultTwoMinuteOnboardingState() : await getTwoMinuteOnboardingState();
    const trial = resolveTrialListHintView({
      connected: connected && !extensionContextInvalidated,
      checklistReady: checklist.allReady,
      state: twoMinState,
      locale
    });
    if (coach.visible && !coachMarkedSeenThisSession) {
      coachMarkedSeenThisSession = true;
      void saveOnboardingState(markCoachSeen(onboardingState));
    }
    if (coach.visible) {
      scheduleCoachAutoDismiss();
    } else if (coachAutoDismissTimer != null) {
      window.clearTimeout(coachAutoDismissTimer);
      coachAutoDismissTimer = null;
    }
    host.setAttribute("data-connection", view.connection);
    host.setAttribute("data-item-holders", String(view.itemHolderCount));
    host.setAttribute(ATTR_READY, "1");
    host.setAttribute("data-appid", "730");
    host.setAttribute("data-bulk-mode", bulkMode ? "1" : "0");
    host.setAttribute("data-onboarding-ready", checklist.allReady ? "1" : "0");
    host.setAttribute("data-coach", coach.visible ? "1" : "0");
    const bulkToggle = connected && !lastSiteSafeMode ? `<button type="button" class="rip-inv-bulk-toggle" data-rip-bulk-toggle data-active="${bulkMode ? "1" : "0"}">${bulkMode ? "\u041C\u0443\u043B\u044C\u0442\u0438\u0432\u044B\u0431\u043E\u0440 \xB7 \u0432\u043A\u043B" : "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E"}</button>` : "";
    const draftChip = sellDraftRestoreChip ? `<span class="rip-inv-draft-chip" data-testid="rip-inv-draft-chip" data-rip-draft-chip>
        ${escapeHtml(sellDraftRestoreChip)}
        <button type="button" data-rip-draft-dismiss aria-label="\u0421\u043A\u0440\u044B\u0442\u044C">\u2715</button>
      </span>` : "";
    const browserAssistBtn = connected && !extensionContextInvalidated && !lastSiteSafeMode ? `<button type="button" class="rip-inv-cta-secondary" data-rip-browser-assist ${browserAssistBusy ? "disabled" : ""}>${browserAssistBusy ? "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F\u2026" : "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441 \u0441\u0430\u0439\u0442\u043E\u043C"}</button>` : "";
    const coachHtml = coach.visible ? `<div class="rip-inv-coach" data-rip-coach role="status">
        <p class="rip-inv-coach-title">${escapeHtml(coach.title)}</p>
        <p class="rip-inv-coach-body">${escapeHtml(coach.body)}</p>
        <div class="rip-inv-coach-actions">
          <button type="button" class="rip-inv-coach-dismiss" data-rip-coach-dismiss>${escapeHtml(coach.dismissLabel)}</button>
          <span class="rip-inv-coach-hint">${escapeHtml(t("onboarding.autoHideHint"))}</span>
        </div>
      </div>` : "";
    const trialHtml = trial.visible ? `<div class="rip-inv-trial" data-rip-trial role="status">
        <p class="rip-inv-trial-title">${escapeHtml(trial.title)}</p>
        <p class="rip-inv-trial-body">${escapeHtml(trial.body)}</p>
        <button type="button" class="rip-inv-trial-dismiss" data-rip-trial-dismiss>${escapeHtml(trial.dismissLabel)}</button>
      </div>` : "";
    const checklistItemsHtml = checklist.allReady ? "" : `<ul class="rip-inv-checklist-list">
        ${checklist.items.map(
      (item) => `<li class="rip-inv-checklist-item" data-ready="${item.ready ? "1" : "0"}" data-key="${escapeHtml(item.key)}">
              <span class="rip-inv-checklist-mark" aria-hidden="true">${item.ready ? "\u2713" : "\xB7"}</span>
              <div class="rip-inv-checklist-copy">
                <span class="rip-inv-checklist-label">${escapeHtml(item.label)}</span>
                <p class="rip-inv-checklist-hint">${escapeHtml(item.hint)}</p>
              </div>
              ${item.actionHref && item.actionLabel ? `<a class="rip-inv-checklist-action" href="${escapeHtml(item.actionHref)}" target="_blank" rel="noreferrer">${escapeHtml(item.actionLabel)}</a>` : ""}
            </li>`
    ).join("")}
      </ul>`;
    const checklistHtml = !checklist.allReady || coach.visible ? `<div class="rip-inv-checklist" data-ready="${checklist.allReady ? "1" : "0"}" data-rip-checklist>
      <div class="rip-inv-checklist-head">
        <p class="rip-inv-checklist-title">${escapeHtml(checklist.title)}</p>
        <p class="rip-inv-checklist-summary">${escapeHtml(checklist.summaryLine)}</p>
      </div>
      ${checklistItemsHtml}
    </div>` : "";
    const steamWarnHtml = steamEnrichmentDegraded ? `<p class="rip-inv-steam-warn" data-rip-steam-enrich-warn role="status">${escapeHtml(
      t("inventory.steamEnrichmentDegraded")
    )}</p>` : "";
    const reloadHtml = extensionContextInvalidated ? `<p class="rip-inv-reload" role="alert">\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043E\u0431\u043D\u043E\u0432\u0438\u043B\u043E\u0441\u044C \u2014 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0432\u043A\u043B\u0430\u0434\u043A\u0443 Steam, \u0438\u043D\u0430\u0447\u0435 \u043A\u043D\u043E\u043F\u043A\u0438 \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u044E\u0442. <button type="button" data-rip-reload-tab>\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443</button></p>` : "";
    const holdFacts = mergeSteamFactsMaps(
      buildDomBaselineSteamFacts(document),
      steamFactsCache?.byAssetId
    );
    const holdBanner = resolveTradeHoldBannerView({
      facts: holdFacts.values(),
      dismissed: isTradeHoldBannerDismissed()
    });
    const holdHtml = holdBanner.visible ? `<div class="rip-inv-hold" role="status" data-rip-trade-hold>
      <p class="rip-inv-hold-title">${escapeHtml(holdBanner.title)}</p>
      <p class="rip-inv-hold-body">${escapeHtml(holdBanner.body)}</p>
      <div class="rip-inv-hold-actions">
        <button type="button" class="rip-inv-cta-secondary" data-rip-hold-dismiss>${escapeHtml(holdBanner.dismissLabel)}</button>
      </div>
    </div>` : "";
    const secondaryCtaHtml = view.secondaryCta ? `<a class="rip-inv-cta-secondary" href="${escapeHtml(view.secondaryCta.href)}" target="_blank" rel="noreferrer">${escapeHtml(view.secondaryCta.label)}</a>` : "";
    host.innerHTML = `
    ${coachHtml}
    ${trialHtml}
    <div class="rip-inv-bar" data-connection="${view.connection}">
      <div class="rip-inv-bar-top">
        <div class="rip-inv-identity">
          <span class="rip-inv-brand">${escapeHtml(view.title)}</span>
          <span class="rip-inv-status" data-connection="${view.connection}">${escapeHtml(view.statusLabel)}</span>
        </div>
        <span class="rip-inv-meta">\u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435 \xB7 ${view.itemHolderCount}</span>
      </div>
      <p class="rip-inv-body">${escapeHtml(view.body)}</p>
      <div class="rip-inv-bar-actions">
        ${draftChip}
        ${bulkToggle}
        ${browserAssistBtn}
        <a class="rip-inv-cta" href="${escapeHtml(view.ctaHref)}" target="_blank" rel="noreferrer">${escapeHtml(view.ctaLabel)}</a>
        ${secondaryCtaHtml}
      </div>
      ${reloadHtml}
      ${steamWarnHtml}
    </div>
    ${holdHtml}
    ${checklistHtml}
  `;
    host.querySelector("[data-rip-reload-tab]")?.addEventListener("click", () => {
      window.location.reload();
    });
    host.querySelector("[data-rip-draft-dismiss]")?.addEventListener("click", () => {
      sellDraftRestoreChip = null;
      scheduleHostRender();
    });
    host.querySelector("[data-rip-browser-assist]")?.addEventListener("click", () => {
      void runBrowserAssistSync();
    });
    host.querySelector("[data-rip-bulk-toggle]")?.addEventListener("click", () => {
      bulkMode = !bulkMode;
      if (!bulkMode) {
        bulkSelected = /* @__PURE__ */ new Set();
      }
      persistSellDraft();
      scheduleHostRender();
      scheduleEnrichment(false);
    });
    host.querySelector("[data-rip-coach-dismiss]")?.addEventListener("click", () => {
      void persistCoachDismiss();
    });
    host.querySelector("[data-rip-trial-dismiss]")?.addEventListener("click", () => {
      void persistDismissTrialListHint().then(() => scheduleHostRender()).catch(() => void 0);
    });
    host.querySelector("[data-rip-hold-dismiss]")?.addEventListener("click", () => {
      dismissTradeHoldBanner();
      scheduleHostRender();
    });
    renderBulkBar();
  }
  function removeBulkBar() {
    document.getElementById(BULK_BAR_ID)?.remove();
  }
  function collectBulkItemsFromSelection() {
    const items = [];
    for (const assetId of bulkSelected) {
      const steam = steamFactsCache?.byAssetId.get(assetId);
      if (!steam) {
        continue;
      }
      const platform = platformFactsCache?.byAssetId[assetId] ?? null;
      const item = buildBulkSellItem({ steam, platform });
      if (item) {
        items.push(item);
      }
    }
    return items;
  }
  function renderBulkBar() {
    if (!bulkMode || !lastConnected) {
      removeBulkBar();
      return;
    }
    ensureStyles();
    const plan = planBulkSellOperations(collectBulkItemsFromSelection());
    const count = plan.selectedCount;
    const submitError = validateBulkSelectionForSubmit(plan.plannedCount);
    const namePreview = formatBulkListingPreview(
      plan.operations.flatMap((op) => op.items.map((entry) => entry.marketHashName)),
      2
    );
    const namesHint = namePreview.lines.length > 0 ? namePreview.moreCount > 0 ? `${namePreview.lines.join(" \xB7 ")} \xB7 +${namePreview.moreCount}` : namePreview.lines.join(" \xB7 ") : plan.summaryLine || plan.modeLabel;
    let bar = document.getElementById(BULK_BAR_ID);
    if (!bar) {
      bar = document.createElement("div");
      bar.id = BULK_BAR_ID;
      document.documentElement.appendChild(bar);
    }
    bar.innerHTML = `
    <span class="rip-bulk-count">\u0412\u044B\u0431\u0440\u0430\u043D\u043E: ${count}</span>
    <span class="rip-bulk-meta" title="${escapeHtml(namesHint)}">${escapeHtml(namesHint)}</span>
    <button type="button" class="rip-bulk-btn rip-bulk-btn--primary" data-rip-bulk-sell ${submitError ? "disabled" : ""}>\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C</button>
    <button type="button" class="rip-bulk-btn rip-bulk-btn--secondary" data-rip-bulk-clear>\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C</button>
    <button type="button" class="rip-bulk-btn rip-bulk-btn--secondary" data-rip-bulk-exit>\u0412\u044B\u0439\u0442\u0438</button>
  `;
    bar.querySelector("[data-rip-bulk-clear]")?.addEventListener("click", () => {
      bulkSelected = /* @__PURE__ */ new Set();
      persistSellDraft();
      scheduleEnrichment(false);
    });
    bar.querySelector("[data-rip-bulk-exit]")?.addEventListener("click", () => {
      bulkMode = false;
      bulkSelected = /* @__PURE__ */ new Set();
      persistSellDraft();
      scheduleHostRender();
    });
    bar.querySelector("[data-rip-bulk-sell]")?.addEventListener("click", () => {
      if (submitError) {
        showSellToast({ message: submitError });
        return;
      }
      openBulkSellPanel();
    });
  }
  function openBulkSellPanel() {
    const items = collectBulkItemsFromSelection();
    const plan = planBulkSellOperations(items);
    const submitError = validateBulkSelectionForSubmit(plan.plannedCount);
    if (submitError) {
      showSellToast({ message: submitError });
      return;
    }
    ensureStyles();
    closeSellPanel();
    const names = [
      ...new Set(
        plan.operations.flatMap((op) => op.items.map((entry) => entry.marketHashName))
      )
    ];
    const namePreview = formatBulkListingPreview(names, 8);
    const primaryName = names[0] ?? "\u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B";
    const hint = primaryName && priceHintsCache?.byName[primaryName] || null;
    const defaultMinor = resolveDefaultListPriceMinor(hint);
    const defaultValue = defaultMinor != null ? formatUsdInputFromMinor(defaultMinor) : "";
    const namesListHtml = namePreview.lines.length > 0 ? `<ul class="rip-sell-name-list" data-testid="rip-bulk-name-list">
          ${namePreview.lines.map((name) => `<li>${escapeHtml(name)}</li>`).join("")}
        </ul>
        ${namePreview.moreCount > 0 ? `<p class="rip-sell-name-more">\u0438 \u0435\u0449\u0451 ${namePreview.moreCount}</p>` : ""}` : "";
    const panel = document.createElement("div");
    panel.id = SELL_PANEL_ID;
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    panel.innerHTML = `
    <div class="rip-sell-card">
      <p class="rip-sell-eyebrow">R.I.P Market</p>
      <p class="rip-sell-title">\u041C\u043D\u043E\u0436\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u043F\u0440\u043E\u0434\u0430\u0436\u0430</p>
      <p class="rip-sell-item">${escapeHtml(String(plan.plannedCount))} \u0448\u0442 \xB7 ${escapeHtml(plan.modeLabel)}</p>
      <p class="rip-sell-preview">${escapeHtml(plan.summaryLine)}</p>
      ${namesListHtml}
      <label class="rip-sell-label" for="rip-sell-price">\u0426\u0435\u043D\u0430 \u0437\u0430 \u0448\u0442\u0443\u043A\u0443 ($)</label>
      <input id="rip-sell-price" class="rip-sell-input" type="text" inputmode="decimal" autocomplete="off" value="${escapeHtml(defaultValue)}" placeholder="0.00" />
      <p class="rip-sell-preview" data-rip-sell-commission></p>
      <p class="rip-sell-error"></p>
      <div class="rip-sell-actions">
        <button type="button" class="rip-sell-btn rip-sell-btn--primary" data-rip-bulk-confirm>\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0432\u0441\u0451</button>
        <button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-sell-close>\u041E\u0442\u043C\u0435\u043D\u0430</button>
      </div>
    </div>
  `;
    document.documentElement.appendChild(panel);
    updateSellPreview(panel);
    panel.addEventListener("click", (event) => {
      const target = event.target;
      if (target === panel || target?.closest?.("[data-rip-sell-close]")) {
        closeSellPanel();
      }
    });
    panel.querySelector(".rip-sell-input")?.addEventListener("input", () => updateSellPreview(panel));
    panel.querySelector("[data-rip-bulk-confirm]")?.addEventListener("click", () => {
      void submitBulkSellFromPanel(panel, plan.operations);
    });
    panel.querySelector(".rip-sell-input")?.focus();
  }
  async function submitBulkSellFromPanel(panel, operations) {
    const input = panel.querySelector(".rip-sell-input");
    const errorEl = panel.querySelector(".rip-sell-error");
    const confirmBtn = panel.querySelector(
      "[data-rip-bulk-confirm]"
    );
    const priceMinor = parseUsdInputToMinor(input?.value ?? "");
    const priceError = validateCreateLotPriceMinor(priceMinor);
    if (priceError || priceMinor == null) {
      if (errorEl) {
        errorEl.textContent = priceError ?? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0446\u0435\u043D\u0443";
      }
      return;
    }
    const total = operations.reduce((sum, op) => sum + op.items.length, 0);
    if (confirmBtn) {
      confirmBtn.disabled = true;
      confirmBtn.textContent = "\u0412\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u043C\u2026";
    }
    if (errorEl) {
      errorEl.textContent = "";
    }
    const progressEl = panel.querySelector("[data-rip-sell-commission]");
    if (progressEl) {
      progressEl.textContent = buildBulkProgress({
        total,
        done: 0,
        created: 0,
        failed: 0
      }).label;
    }
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.CREATE_INVENTORY_LOTS_BATCH,
        priceMinor,
        operations
      });
      const created = response?.created ?? [];
      const failed = response?.failed ?? [];
      if (created.length > 0) {
        void recordTwoMinuteFirstList().catch(() => void 0);
      }
      const progress = buildBulkProgress({
        total,
        done: created.length + failed.length,
        created: created.length,
        failed: failed.length
      });
      const card = panel.querySelector(".rip-sell-card");
      if (card) {
        const failHint = failed.length > 0 ? `<p class="rip-sell-error">${escapeHtml(
          failed[0]?.error ?? "\u0427\u0430\u0441\u0442\u044C \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043E\u0432 \u043D\u0435 \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u043B\u0430\u0441\u044C"
        )}${failed.length > 1 ? ` (+${failed.length - 1})` : ""}</p>` : "";
        card.innerHTML = `
        <p class="rip-sell-title">${created.length > 0 ? "\u0413\u043E\u0442\u043E\u0432\u043E" : "\u041D\u0435 \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E"}</p>
        <p class="rip-sell-success">${escapeHtml(progress.label)}</p>
        ${failHint}
        <div class="rip-sell-actions">
          ${response?.listingsUrl ? `<a class="rip-sell-btn rip-sell-btn--primary" href="${escapeHtml(response.listingsUrl)}" target="_blank" rel="noreferrer">\u041C\u043E\u0438 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F</a>` : ""}
          ${failed.length > 0 ? `<button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-bulk-retry>\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u043E\u0448\u0438\u0431\u043A\u0438</button>` : ""}
          <button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-sell-close>\u0417\u0430\u043A\u0440\u044B\u0442\u044C</button>
        </div>
      `;
        card.querySelector("[data-rip-sell-close]")?.addEventListener("click", () => closeSellPanel());
        card.querySelector("[data-rip-bulk-retry]")?.addEventListener("click", () => {
          const failedIds = new Set(failed.map((entry) => entry.steamAssetId));
          bulkSelected = new Set(
            [...bulkSelected].filter((id) => failedIds.has(id))
          );
          closeSellPanel();
          openBulkSellPanel();
          scheduleEnrichment(false);
        });
      }
      showSellToast({
        message: progress.label,
        listingsUrl: response?.listingsUrl,
        lotUrl: created[0]?.lotUrl
      });
      for (const entry of created) {
        bulkSelected.delete(entry.steamAssetId);
      }
      platformFactsCache = null;
      scheduleEnrichment(false);
    } catch (error) {
      if (errorEl) {
        errorEl.textContent = humanizeListingApiError({
          message: error instanceof Error ? error.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043B\u043E\u0442\u044B"
        });
      }
      if (confirmBtn) {
        confirmBtn.disabled = false;
        confirmBtn.textContent = "\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0432\u0441\u0451";
      }
    }
  }
  function scheduleHostRender() {
    if (renderTimer !== null) {
      window.clearTimeout(renderTimer);
    }
    renderTimer = window.setTimeout(() => {
      renderTimer = null;
      void renderHostBar();
      scheduleEnrichment();
    }, 120);
  }
  function scheduleEnrichment(forceSteam = false) {
    if (enrichTimer !== null) {
      window.clearTimeout(enrichTimer);
    }
    enrichTimer = window.setTimeout(() => {
      enrichTimer = null;
      void enrichItemCards(forceSteam);
    }, 180);
  }
  function watchInventoryDom() {
    const root = document.querySelector("#inventories") ?? document.querySelector("#mainContents") ?? document.body;
    const observer = new MutationObserver((mutations) => {
      const onlyOverlay = mutations.length > 0 && mutations.every((mutation) => {
        const nodes = [
          ...Array.from(mutation.addedNodes),
          ...Array.from(mutation.removedNodes)
        ];
        return nodes.length > 0 && nodes.every(
          (node) => node instanceof Element && (node.classList?.contains(OVERLAY_CLASS) || node.id === SELL_PANEL_ID || node.id === TOAST_ID || node.id === BULK_BAR_ID || node.id === SELECTED_SELL_RAIL_ID || node.closest?.(`.${OVERLAY_CLASS}`) || node.closest?.(`#${SELL_PANEL_ID}`) || node.closest?.(`#${TOAST_ID}`) || node.closest?.(`#${BULK_BAR_ID}`) || node.closest?.(`#${SELECTED_SELL_RAIL_ID}`))
        );
      });
      if (onlyOverlay) {
        return;
      }
      scheduleHostRender();
    });
    observer.observe(root, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style", "id"]
    });
  }
  function watchNavigation() {
    window.addEventListener("hashchange", () => {
      scheduleHostRender();
    });
    window.addEventListener("popstate", () => {
      scheduleHostRender();
    });
    document.addEventListener(
      "click",
      (event) => {
        const target = event.target;
        const selectBox = target?.closest?.(
          ".rip-item-select[data-rip-bulk-asset]"
        );
        if (selectBox) {
          event.stopPropagation();
          const assetId = selectBox.getAttribute("data-rip-bulk-asset")?.trim();
          if (assetId) {
            bulkSelected = toggleBulkSelection(
              bulkSelected,
              assetId,
              selectBox.checked
            );
            persistSellDraft();
            renderBulkBar();
            const holder = selectBox.closest(".itemHolder");
            holder?.setAttribute(
              "data-rip-bulk-selected",
              selectBox.checked ? "1" : "0"
            );
          }
          return;
        }
        const sellBtn = target?.closest?.(
          ".rip-item-sell[data-rip-sell-asset], .rip-selected-sell[data-rip-sell-asset]"
        );
        if (sellBtn) {
          event.preventDefault();
          event.stopPropagation();
          void openSellFromButton(sellBtn);
          return;
        }
        const clickedItem = target?.closest?.(
          `${CS2_INVENTORY_ITEM_SELECTOR}, .itemHolder`
        );
        if (clickedItem) {
          const itemEl = clickedItem.matches?.(CS2_INVENTORY_ITEM_SELECTOR) ? clickedItem : clickedItem.querySelector(CS2_INVENTORY_ITEM_SELECTOR);
          const clickedAsset = parseAssetIdFromItemElementId(itemEl?.id);
          if (clickedAsset) {
            lastClickedAssetId = clickedAsset;
            window.setTimeout(() => {
              syncSelectedSellRail({
                steamFacts: steamFactsCache?.byAssetId ?? /* @__PURE__ */ new Map(),
                platformFacts: platformFactsCache?.byAssetId ?? {},
                priceHints: priceHintsCache?.byName ?? {},
                connected: lastConnected
              });
            }, 50);
          }
        }
        if (target?.closest?.(
          '.games_list_tab, #inventory_applogo, a[href*="inventory"], .inventory_page_right, .inventory_page_left'
        )) {
          scheduleHostRender();
          window.setTimeout(() => scheduleEnrichment(false), 400);
        }
      },
      true
    );
  }
  async function openSellFromButton(button) {
    const assetId = button.getAttribute("data-rip-sell-asset")?.trim();
    if (!assetId) {
      return;
    }
    const overlay = button.closest(`.${OVERLAY_CLASS}`);
    const session = await getSessionState();
    const connected = Boolean(session?.accessToken && session.apiBaseUrl);
    const platform = platformFactsCache?.byAssetId[assetId] ?? null;
    const steam = steamFactsCache?.byAssetId.get(assetId);
    const action = resolveInventorySellAction({
      connected,
      siteSafeMode: lastSiteSafeMode,
      steam: steam ?? {
        tradable: true,
        marketable: true,
        tradeLockUntil: null
      },
      platform
    });
    const defaultAttr = overlay?.getAttribute("data-rip-default-price-minor");
    const defaultPriceMinor = defaultAttr ? Number(defaultAttr) : null;
    const marketHashName = overlay?.getAttribute("data-rip-market-hash-name")?.trim() || steam?.marketHashName?.trim() || platform?.marketHashName?.trim() || `Asset ${assetId}`;
    const priceHint = marketHashName && priceHintsCache?.byName[marketHashName] || null;
    const sellUrl = siteSellInventoryUrl(session?.apiBaseUrl);
    const accountUrl = siteAccountUrl(session?.apiBaseUrl);
    if (action.kind === "manage") {
      const manage = resolveManageListingAction({ connected, platform });
      openManagePanel({
        assetId,
        marketHashName,
        lotId: manage.lotId || overlay?.getAttribute("data-rip-lot-id")?.trim() || action.lotId || "",
        lotUrl: manage.lotUrl || action.lotUrl,
        listedPriceMinor: manage.listedPriceMinor ?? (overlay?.getAttribute("data-rip-listed-price-minor") ? Number(overlay.getAttribute("data-rip-listed-price-minor")) : null),
        sellUrl
      });
      return;
    }
    openSellPanel({
      assetId,
      marketHashName,
      iconUrl: readSteamItemIconUrl(
        document,
        assetId,
        queryCs2InventoryItemByAssetId
      ),
      inventoryAssetId: overlay?.getAttribute("data-rip-inventory-asset-id")?.trim() || platform?.inventoryAssetId || null,
      defaultPriceMinor: defaultPriceMinor != null && Number.isFinite(defaultPriceMinor) ? defaultPriceMinor : null,
      priceHint,
      action,
      accountUrl,
      sellUrl
    });
  }
  function openManagePanel(ctx) {
    ensureStyles();
    closeSellPanel();
    if (!ctx.lotId) {
      showSellToast({
        message: "\u041B\u043E\u0442 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435.",
        listingsUrl: ctx.sellUrl
      });
      return;
    }
    const priceValue = formatListedPriceInput(ctx.listedPriceMinor);
    const panel = document.createElement("div");
    panel.id = SELL_PANEL_ID;
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    panel.setAttribute("aria-label", "\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043B\u043E\u0442\u043E\u043C");
    panel.innerHTML = `
    <div class="rip-sell-card">
      <p class="rip-sell-title">\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043B\u043E\u0442\u043E\u043C</p>
      <p class="rip-sell-item">${escapeHtml(ctx.marketHashName)}</p>
      <p class="rip-sell-preview">${escapeHtml(formatManageCurrentPriceLine(ctx.listedPriceMinor))}</p>
      <label class="rip-sell-label" for="rip-sell-price">\u041D\u043E\u0432\u0430\u044F \u0446\u0435\u043D\u0430 ($)</label>
      <input id="rip-sell-price" class="rip-sell-input" type="text" inputmode="decimal" autocomplete="off" value="${escapeHtml(priceValue)}" placeholder="0.00" />
      <p class="rip-sell-preview" data-rip-sell-commission></p>
      <p class="rip-sell-error"></p>
      <div class="rip-sell-actions">
        <button type="button" class="rip-sell-btn rip-sell-btn--primary" data-rip-manage-save>\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0446\u0435\u043D\u0443</button>
        <button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-manage-cancel>\u0421\u043D\u044F\u0442\u044C \u0441 \u043F\u0440\u043E\u0434\u0430\u0436\u0438</button>
        ${ctx.lotUrl ? `<a class="rip-sell-btn rip-sell-btn--secondary" href="${escapeHtml(ctx.lotUrl)}" target="_blank" rel="noreferrer">\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043B\u043E\u0442</a>` : ""}
        <button type="button" class="rip-sell-btn rip-sell-btn--secondary" data-rip-sell-close>\u0417\u0430\u043A\u0440\u044B\u0442\u044C</button>
      </div>
    </div>
  `;
    document.documentElement.appendChild(panel);
    updateSellPreview(panel);
    panel.addEventListener("click", (event) => {
      const target = event.target;
      if (target === panel || target?.closest?.("[data-rip-sell-close]")) {
        closeSellPanel();
      }
    });
    panel.querySelector(".rip-sell-input")?.addEventListener("input", () => updateSellPreview(panel));
    panel.querySelector("[data-rip-manage-save]")?.addEventListener("click", () => {
      void submitManagePrice(panel, ctx);
    });
    panel.querySelector("[data-rip-manage-cancel]")?.addEventListener("click", () => {
      void submitManageCancel(panel, ctx);
    });
    panel.querySelector(".rip-sell-input")?.focus();
  }
  async function submitManagePrice(panel, ctx) {
    const input = panel.querySelector(".rip-sell-input");
    const errorEl = panel.querySelector(".rip-sell-error");
    const saveBtn = panel.querySelector("[data-rip-manage-save]");
    const parsed = buildManagePricePreview(input?.value ?? "");
    if (parsed.error || parsed.priceMinor == null) {
      if (errorEl) {
        errorEl.textContent = parsed.error ?? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0446\u0435\u043D\u0443";
      }
      return;
    }
    if (!hasPriceChanged(ctx.listedPriceMinor, parsed.priceMinor)) {
      if (errorEl) {
        errorEl.textContent = "\u0426\u0435\u043D\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C";
      }
      return;
    }
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.textContent = "\u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u043C\u2026";
    }
    if (errorEl) {
      errorEl.textContent = "";
    }
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.UPDATE_INVENTORY_LOT_PRICE,
        lotId: ctx.lotId,
        priceMinor: parsed.priceMinor
      });
      if (!response?.ok) {
        if (errorEl) {
          errorEl.textContent = response?.error ?? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0446\u0435\u043D\u0443";
        }
        if (saveBtn) {
          saveBtn.disabled = false;
          saveBtn.textContent = "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0446\u0435\u043D\u0443";
        }
        return;
      }
      showSellToast({
        message: "\u0426\u0435\u043D\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430",
        lotUrl: response.lotUrl ?? ctx.lotUrl,
        listingsUrl: response.listingsUrl
      });
      closeSellPanel();
      platformFactsCache = null;
      scheduleEnrichment(false);
    } catch (error) {
      if (errorEl) {
        errorEl.textContent = error instanceof Error ? error.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0446\u0435\u043D\u0443";
      }
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.textContent = "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0446\u0435\u043D\u0443";
      }
    }
  }
  async function submitManageCancel(panel, ctx) {
    const errorEl = panel.querySelector(".rip-sell-error");
    const cancelBtn = panel.querySelector(
      "[data-rip-manage-cancel]"
    );
    const confirmed = window.confirm(
      `\u0421\u043D\u044F\u0442\u044C \xAB${ctx.marketHashName}\xBB \u0441 \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u043D\u0430 R.I.P?`
    );
    if (!confirmed) {
      return;
    }
    if (cancelBtn) {
      cancelBtn.disabled = true;
      cancelBtn.textContent = "\u0421\u043D\u0438\u043C\u0430\u0435\u043C\u2026";
    }
    if (errorEl) {
      errorEl.textContent = "";
    }
    try {
      const response = await chrome.runtime.sendMessage({
        type: TRADE_VERIFICATION_RUNTIME.CANCEL_INVENTORY_LOT,
        lotId: ctx.lotId
      });
      if (!response?.ok) {
        if (errorEl) {
          errorEl.textContent = response?.error ?? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043D\u044F\u0442\u044C \u0441 \u043F\u0440\u043E\u0434\u0430\u0436\u0438";
        }
        if (cancelBtn) {
          cancelBtn.disabled = false;
          cancelBtn.textContent = "\u0421\u043D\u044F\u0442\u044C \u0441 \u043F\u0440\u043E\u0434\u0430\u0436\u0438";
        }
        return;
      }
      showSellToast({
        message: "\u041B\u043E\u0442 \u0441\u043D\u044F\u0442 \u0441 \u043F\u0440\u043E\u0434\u0430\u0436\u0438",
        listingsUrl: response.listingsUrl
      });
      closeSellPanel();
      platformFactsCache = null;
      scheduleEnrichment(false);
    } catch (error) {
      if (errorEl) {
        errorEl.textContent = error instanceof Error ? error.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043D\u044F\u0442\u044C \u0441 \u043F\u0440\u043E\u0434\u0430\u0436\u0438";
      }
      if (cancelBtn) {
        cancelBtn.disabled = false;
        cancelBtn.textContent = "\u0421\u043D\u044F\u0442\u044C \u0441 \u043F\u0440\u043E\u0434\u0430\u0436\u0438";
      }
    }
  }
  async function mount() {
    if (!isSteamInventoryPath(window.location.pathname) || mounted) {
      return;
    }
    if (!await isExtensionInventoryLayerEnabled()) {
      return;
    }
    mounted = true;
    await renderHostBar();
    await enrichItemCards(true);
    watchInventoryDom();
    watchNavigation();
    window.setInterval(() => {
      void renderHostBar();
      void enrichItemCards(false);
    }, 12e3);
  }
  void mount();
})();
//# sourceMappingURL=inventory-bridge.js.map
