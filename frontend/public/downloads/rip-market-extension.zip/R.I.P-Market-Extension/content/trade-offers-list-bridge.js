"use strict";
(() => {
  // src/shared/trade-verification-runtime.ts
  var TRADE_VERIFICATION_RUNTIME = {
    GET_ACTIVE_TRADES: "RIP_MARKET_GET_ACTIVE_TRADES",
    VERIFY_TRADE: "RIP_MARKET_VERIFY_TRADE",
    ACK_TRADE: "RIP_MARKET_ACK_TRADE",
    REFRESH_ACTIVE_TRADES: "RIP_MARKET_REFRESH_ACTIVE_TRADES",
    REPORT_STEAM_OFFER_PAGE: "RIP_MARKET_REPORT_STEAM_OFFER_PAGE",
    RESOLVE_ASSET_FLOAT: "RIP_MARKET_RESOLVE_ASSET_FLOAT",
    GET_INVENTORY_PLATFORM_STATUS: "RIP_MARKET_GET_INVENTORY_PLATFORM_STATUS",
    GET_INVENTORY_PRICE_HINTS: "RIP_MARKET_GET_INVENTORY_PRICE_HINTS",
    /** Load CS2 enrichment facts from the Steam inventory tab MAIN world. */
    GET_INVENTORY_PAGE_FACTS: "RIP_MARKET_GET_INVENTORY_PAGE_FACTS",
    BROWSER_ASSIST_INVENTORY_SYNC: "RIP_MARKET_BROWSER_ASSIST_INVENTORY_SYNC",
    CREATE_INVENTORY_LOT: "RIP_MARKET_CREATE_INVENTORY_LOT",
    CREATE_INVENTORY_LOTS_BATCH: "RIP_MARKET_CREATE_INVENTORY_LOTS_BATCH",
    UPDATE_INVENTORY_LOT_PRICE: "RIP_MARKET_UPDATE_INVENTORY_LOT_PRICE",
    CANCEL_INVENTORY_LOT: "RIP_MARKET_CANCEL_INVENTORY_LOT",
    GET_SELLER_ONBOARDING_STATUS: "RIP_MARKET_GET_SELLER_ONBOARDING_STATUS",
    MANUAL_CREATE_OFFER: "RIP_MARKET_MANUAL_CREATE_OFFER"
  };

  // src/shared/trade-offers-list-marking.ts
  function parseTradeOfferIdFromElementId(elementId) {
    const match = elementId.match(/^tradeofferid_(\d+)$/i);
    return match?.[1] ?? null;
  }
  function isRipOfferMark(kind) {
    return kind === "rip_verified" || kind === "rip_pending" || kind === "rip_mismatch";
  }
  function classifyOfferMark(offerId, trades) {
    const normalized = offerId.trim();
    if (!normalized) {
      return { kind: "not_ours", label: "\u041D\u0435 \u043D\u0430\u0448\u0430 \u0441\u0434\u0435\u043B\u043A\u0430", trade: null };
    }
    const trade = trades.find((entry) => entry.offerId && entry.offerId === normalized) ?? null;
    if (!trade) {
      return { kind: "not_ours", label: "\u041D\u0435 \u043D\u0430\u0448\u0430 \u0441\u0434\u0435\u043B\u043A\u0430", trade: null };
    }
    if (trade.verificationStatus === "mismatch") {
      return { kind: "rip_mismatch", label: "\u041F\u043E\u0434\u043E\u0437\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u043E", trade };
    }
    if (trade.verificationStatus === "verified") {
      return { kind: "rip_verified", label: "\u0421\u0434\u0435\u043B\u043A\u0430 R.I.P", trade };
    }
    return { kind: "rip_pending", label: "\u0421\u0434\u0435\u043B\u043A\u0430 R.I.P", trade };
  }
  function formatMoneyMinor(amountMinor) {
    const value = Number(amountMinor) / 100;
    if (!Number.isFinite(value)) {
      return amountMinor;
    }
    return `$${value.toFixed(2)}`;
  }

  // src/shared/trade-offer-anti-scam.ts
  function antiScamStickyShort() {
    return "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u043E\u0431\u043C\u0435\u043D\u044B \u0438\u0437 \u0447\u0430\u0442\u0430 / \u043F\u0440\u043E\u0444\u0438\u043B\u044F \u043D\u0435\u0437\u043D\u0430\u043A\u043E\u043C\u0446\u0430 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u0434\u0435\u043B\u043A\u0438 R.I.P.";
  }

  // src/shared/extension-i18n-core.ts
  var DEFAULT_EXTENSION_LOCALE = "ru";
  var EXTENSION_LOCALE_STORAGE_KEY = "rip:extension.locale";
  function isExtensionLocale(value) {
    return value === "ru" || value === "en";
  }
  function normalizeExtensionLocale(value, fallback = DEFAULT_EXTENSION_LOCALE) {
    if (isExtensionLocale(value)) {
      return value;
    }
    if (typeof value === "string") {
      const lower = value.trim().toLowerCase();
      if (lower.startsWith("en")) {
        return "en";
      }
      if (lower.startsWith("ru")) {
        return "ru";
      }
    }
    return fallback;
  }
  function getMessageByPath(tree, path) {
    const parts = path.split(".");
    let current = tree;
    for (const part of parts) {
      if (current == null || typeof current === "string") {
        return void 0;
      }
      current = current[part];
    }
    return typeof current === "string" ? current : void 0;
  }
  function interpolateExtension(template, params) {
    if (!params) {
      return template;
    }
    return template.replace(/\{\{(\w+)\}\}/g, (_match, key) => {
      const value = params[key];
      return value === void 0 || value === null ? "" : String(value);
    });
  }
  function translateExtension(tree, key, params) {
    const template = getMessageByPath(tree, key);
    if (template == null) {
      return key;
    }
    return interpolateExtension(template, params);
  }
  async function getStoredExtensionLocale() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local?.get) {
        const stored = await chrome.storage.local.get(EXTENSION_LOCALE_STORAGE_KEY);
        return normalizeExtensionLocale(stored[EXTENSION_LOCALE_STORAGE_KEY]);
      }
    } catch {
    }
    return DEFAULT_EXTENSION_LOCALE;
  }

  // src/shared/extension-messages-en.ts
  var extensionMessagesEn = {
    common: {
      openOrder: "Open order",
      openSite: "Open site",
      more: "More",
      loading: "Loading\u2026",
      cancel: "Cancel",
      buy: "Buy",
      sell: "Sell",
      buyer: "Buyer",
      seller: "Seller"
    },
    popup: {
      lead: "Deals and status \xB7 p2pcs",
      openSite: "Open site",
      refreshHealth: "Status",
      refreshTrades: "Deals",
      copyDebug: "Copy support report",
      copyDebugBusy: "Copying\u2026",
      copyDebugDone: "Copied \u2713",
      copyDebugOpened: "Copied \xB7 opening support",
      disconnect: "Disconnect",
      pairHint: "Connect the extension on the account page on p2pcs.ru.",
      advanced: "Advanced",
      toolsTitle: "Tools",
      healthTitle: "Health",
      trustTitle: "Trust",
      quietNotifyLabel: "Quiet notifications (deal / Guard / Accept / Mismatch)",
      quietNotifyNote: "Only when a deal state changes. Multiple events \u2192 one group alert. \u201CLater\u201D hides the card for 15 minutes. \u201CMute deal\u201D silences alerts until the deal ends.",
      supportEmergency: "Support \xB7 emergency access",
      apiKeyNote: "Not for everyday use. Paste a key only if R.I.P Market support explicitly asked \u2014 and only while Steam is broken.",
      apiKeyLabel: "Backup Steam Web API key",
      apiKeyPlaceholder: "Only if support asked you to",
      apiKeySave: "Save",
      apiKeyClear: "Clear",
      apiKeyStatusSaved: "Key stored locally; api.steampowered.com access granted only for fallback.",
      apiKeyStatusEmpty: "No key \u2014 the extension uses your Steam session in Chrome.",
      apiKeyPermissionDenied: "Chrome did not grant api.steampowered.com \u2014 key was not saved.",
      permissionsTitle: "Why these permissions",
      languageLabel: "Interface language",
      languageRu: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
      languageEn: "English",
      languageHint: "Synced from the site on pair; you can change it here.",
      buyersTitle: "Purchases",
      buyersSub: "Waiting for offer \xB7 verifying",
      sellersTitle: "Sales",
      sellersSub: "In progress \xB7 delivery check",
      receiptsTitle: "Recent deals",
      receiptsSub: "Receipts \xB7 fee \xB7 offer",
      actionTitle: "Action needed",
      actionSub: "One primary step per card",
      snoozeLater: "Later",
      emptyTitle: "All quiet",
      emptyBody: "No deals need action right now."
    },
    safeMode: {
      offlineTitle: "Server link lost \xB7 safe mode",
      offlineBody: "The site page may still load in the browser, but the deals API is unreachable. Showing cache; listing and sending offers are paused until the link recovers.",
      degradedTitle: "Unstable link to the server",
      degradedBody: "Cached deals on screen. List / send are paused \u2014 confirm Guard or Accept only in Steam if the offer is already verified.",
      cacheLine: "Deal cache \xB7 {{when}}",
      cacheEmpty: "No cached deals yet \u2014 refresh when the API is back.",
      hint: "Safe mode: platform list and send are paused.",
      waitCta: "Waiting for server link",
      blockMessage: "Deals API unreachable or unstable \u2014 listing and sending offers are paused (safe mode)."
    },
    cta: {
      openDispute: "Open dispute",
      openDisputeSupport: "Open dispute / support",
      openOrder: "Open order",
      confirmGuard: "Confirm in Steam Mobile",
      openTradeUrl: "Open Trade URL",
      retrySend: "Retry send",
      retryAutoSend: "Retry auto-send",
      confirmSent: "I sent the trade",
      openVerifiedOffer: "Open verified offer",
      openVerifiedOfferSteam: "Open verified offer in Steam",
      preAcceptAck: "I see the correct offer",
      problemSupport: "Trade problem",
      confirmReceived: "Item is mine",
      openOfferSteam: "Open offer in Steam",
      platformStatus: "Status on site",
      refreshStatus: "Refresh status",
      waitSeller: "Waiting for seller",
      open: "Open",
      openAccount: "Open account",
      loginNeededSteam: "Sign in to the right Steam",
      loginSteam: "Sign in to Steam",
      openSteamInventory: "Open Steam inventory"
    },
    nextAction: {
      hintDisputeOpen: "A dispute is already open \u2014 evidence goes into the ticket. Do not accept other offers.",
      hintMismatch: "Do not accept this trade in Steam. Evidence (offerId, verify, time) will fill the ticket.",
      hintGuard: "The extension never confirms Guard \u2014 only you in Steam Mobile.",
      hintManualWithUrl: "Send the skin manually, then paste the offerId on the order.",
      hintManualRetry: "Auto-send could not finish \u2014 retry or open the order.",
      hintAccept: "Accept only with Steam\u2019s Accept button on this offer page.",
      hintConfirmReceived: "Confirm here \u2014 no need to return to the site.",
      hintVerifying: "The platform is checking delivery \u2014 usually nothing to do.",
      hintWaitSeller: "As soon as the offer appears, an accept button shows here.",
      hintWaitBuyer: "Offer is with the buyer. Status updates after they Accept."
    },
    dealConfirm: {
      acceptTitle: "Accept the trade in Steam",
      acceptBody: "Check the shield, then press Accept. We never accept for you.",
      receivedTitle: "Item with you?",
      receivedBody: "Confirm here \u2014 the site status updates on its own.",
      verifyingTitle: "Checking delivery",
      verifyingBody: "Matching Steam and inventory. Usually quick.",
      doneTitle: "Done",
      doneBody: "The platform has the deal. Open the order only if you need it.",
      guardTitle: "Confirm in Steam Mobile",
      guardBody: "Guard is only in the Steam app. Status updates here by itself."
    },
    badge: {
      rePair: "Connect",
      steam: "Steam",
      inventory: "Inventory",
      guard: "Guard",
      accept: "Accept",
      mismatch: "Mismatch",
      sendManual: "Manual",
      confirmSent: "Confirm",
      confirmReceived: "Received",
      reportIssue: "Issue"
    },
    connection: {
      revokedTitle: "Session expired",
      revokedDetail: "Reconnect the extension on the account page.",
      offTitle: "Not connected to the site",
      offDetail: "The site may already be open \u2014 go to Account \u2192 \u201CConnect extension\u201D (this is not a Chrome setting).",
      steamUnknown: "Steam: unknown",
      mismatchTitle: "Site connected \xB7 wrong Steam",
      mismatchDetail: "Steam does not match",
      noSteamTitle: "Site connected \xB7 not signed in to Steam",
      noSteamDetail: "Steam: no session",
      connectedUntil: "Connected until {{expires}}",
      connectedOkTitle: "Connected \xB7 site and Steam match",
      inventoryIssueTitle: "Steam OK \xB7 inventory issue",
      connectedTitle: "Connected",
      connectedDetail: "Site and Steam match \u2014 ready for deals.",
      steamAligned: "Site and Steam match"
    },
    buyerPhase: {
      wait_offer: "Waiting for offer",
      accept: "Accept",
      verifying: "Verifying",
      dispute: "Dispute / issue"
    },
    timeout: {
      expired: "Trade window expired \u2014 a dispute may open soon",
      minutes: "~{{minutes}} min left until auto-dispute",
      hoursMinutes: "~{{hours}} h {{minutes}} min left until auto-dispute"
    },
    settlement: {
      soonSuffix: "{{formatted}} (soon)",
      offerOk: "Steam offer: accepted",
      offerWarn: "Steam offer: problem",
      offerPending: "Steam offer: checking",
      offerUnknown: "Steam offer: clarifying",
      invOk: "Inventory: skin with buyer",
      invWarn: "Inventory: still with seller",
      invPending: "Inventory: checking",
      invUnknown: "Inventory: clarifying",
      deliveryTitleSeller: "Verifying delivery",
      deliveryTitleBuyer: "Item is yours \u2014 verifying delivery",
      deliveryBodySeller: "Matching Steam offer and inventory. No new offer needed for this deal.",
      deliveryBodyBuyer: "Nothing to do \u2014 the platform matches Steam offer and inventory.",
      fundsSellerKnown: "Funds available from: {{date}}",
      fundsSellerUnknown: "Funds available after the review window (up to {{days}} days)",
      fundsBuyerKnown: "Seller payout from: {{date}}",
      fundsBuyerUnknown: "Seller payout after the review window (up to {{days}} days)",
      holdTitleSeller: "Funds on hold",
      holdTitleBuyer: "Skin is yours \u2014 settlement on-platform",
      holdBodySeller: "Protects against chargebacks and Steam trade reversals. Payout to balance after hold.",
      holdBodyBuyer: "Item is in your inventory. Seller funds unlock after the on-platform review window."
    },
    dispute: {
      openTitle: "Dispute open",
      openBody: "Support is reviewing the deal. Do not accept other offers for this order and do not send money in chat.",
      needTitle: "Dispute needed",
      needMismatch: "Offer does not match the order. Do not press Accept \u2014 open a dispute with evidence (offerId, verify, time).",
      needGeneric: "There is a problem with this deal. Open a dispute \u2014 evidence fills the ticket automatically.",
      ticketPlaceholder: "(describe what went wrong)"
    },
    receipt: {
      eyebrow: "Receipt",
      bought: "Bought",
      sold: "Sold",
      price: "Deal price",
      commission: "Platform fee (5%)",
      paid: "You paid",
      credited: "Credited to balance",
      openOrder: "Open order"
    },
    session: {
      okTitle: "Ready for deals",
      okMessage: "Extension and Steam are connected.",
      disconnectedTitle: "Extension not connected",
      disconnectedMessage: "Open the site \u2192 Account \u2192 \u201CConnect extension\u201D.",
      disconnectedCta: "Open account on site",
      revokedTitle: "Extension session expired",
      revokedMessage: "Reconnect the extension on the account page.",
      revokedCta: "Connect on site",
      cookieTitle: "Not signed in to Steam",
      cookieMessage: "Sign in to steamcommunity.com in this Chrome with the seller account.",
      cookieCta: "Sign in to Steam",
      mismatchTitle: "Wrong Steam in the browser",
      mismatchMessage: "Chrome is signed in as {{session}}, need {{expected}}",
      mismatchCta: "Sign in to the right Steam",
      privateTitle: "Inventory is private",
      privateMessage: "Make your CS2 inventory visible to the extension (Privacy \u2192 Inventory: Public).",
      privateCta: "Open Steam settings",
      rateTitle: "Steam temporarily limited requests",
      rateMessage: "Wait 1\u20132 minutes and tap \u201CCheck again\u201D. No Steam key needed \u2014 if it lasts, contact support.",
      rateCta: "Open Steam inventory",
      inventoryTitle: "Inventory failed to load",
      inventoryMessage: "Open your CS2 inventory in Steam and check again.",
      inventoryCta: "Open Steam inventory"
    },
    notify: {
      guardTitle: "Sale \u2014 confirm Guard",
      guardBody: "{{short}} \xB7 {{item}}. Open Steam Mobile and confirm the trade.",
      acceptTitle: "Purchase \u2014 offer ready to accept",
      acceptBody: "{{short}} \xB7 {{item}}. Open the verified offer in Steam.",
      mismatchTitle: "Mismatch \u2014 do not accept",
      mismatchBody: "{{short}} \xB7 {{item}}. Skin mismatch \u2014 do not press Accept.",
      newDealTitle: "New sale \u2014 sending the trade",
      newDealBody: "{{short}} \xB7 {{item}}. Keep Steam open \u2014 the extension will send the offer.",
      groupMismatch: "Several mismatches \u2014 do not accept",
      groupGuard: "Several sales waiting for Guard",
      groupAccept: "Several purchases waiting to accept",
      groupNewDeal: "Several new sales",
      groupBody: "{{count}} deals need action",
      muteDeal: "Mute deal"
    },
    cardContext: {
      buy: "Buy",
      sell: "Sell",
      dispute: "Dispute",
      mismatch: "Mismatch",
      waitGuard: "Waiting for Guard",
      waitAccept: "Waiting for Accept",
      sendManual: "Send manually",
      confirmSent: "Confirm sent",
      confirmReceived: "Confirm received",
      platformCheck: "Platform check",
      completed: "Completed",
      offerReady: "Offer ready",
      waitBuyer: "Waiting for buyer",
      checking: "Checking\u2026",
      waitTrade: "Waiting for trade",
      tradeConfirmed: "Trade confirmed",
      hold: "Hold / settlement",
      failed: "Failed",
      canceled: "Canceled",
      inProgress: "In progress"
    },
    guided: {
      mismatchTitle: "Mismatch \u2014 do not accept",
      mismatchBuyer: "This offer does not match the R.I.P Market order. Do not press Accept in Steam.",
      mismatchSeller: "Offer does not match the order. Check on the site and do not ask the buyer to accept.",
      verifiedTitle: "Skin matched",
      verifiedBuyer: "You can accept with Steam\u2019s button on this page. Funds are already on the platform \u2014 do not pay in chat.",
      verifiedSeller: "Trade matched the order. Follow the next step on the site / Guard.",
      partialTitle: "Checking\u2026",
      partialBody: "Some checks are still running. Wait \u2014 do not rush Accept yet.",
      pendingTitle: "Waiting for verification",
      pendingBody: "Matching the offer to the R.I.P Market order.",
      name: "Name",
      stickers: "Stickers",
      partner: "Partner SteamID",
      assetId: "Asset ID",
      wear: "Wear",
      float: "Float",
      hintBlock: "Do not accept this trade in Steam",
      hintAccept: "Accept the trade with Steam\u2019s button on this page",
      hintWait: "Wait for verification to finish \u2014 do not rush Accept"
    },
    offerGate: {
      needCs2Title: "Select CS2",
      needCs2Body: "In the inventory list on the left, choose Counter-Strike 2. The extension will add the deal skin.",
      needItemTitle: "Add the skin to the trade",
      needItemBody: "Needed item: {{name}}. Click it in your inventory \u2014 it should appear under \u201CYour items\u201D.",
      itemReadyTitle: "Skin is in the offer",
      itemReadyBody: "Check the shield, then press \u201CMake Offer\u201D in Steam. Guard is confirmed only in the Steam app."
    },
    shield: {
      dealLine: "Order #{{short}} \xB7 {{amount}}",
      wear: "Wear",
      float: "Float",
      stickers: "Stickers",
      unknownPartner: "Counterparty",
      partnerMatch: "Steam partner matches",
      partnerMismatch: "Steam partner MISMATCH \u2014 do not accept",
      partnerMissingObserved: "Could not read partner from the Steam page",
      partnerMissingExpected: "Order has no counterparty SteamID",
      partnerUnknown: "Partner not recognized",
      partnerMatchCheck: "Partner SteamID matches the order",
      partnerMismatchCheck: "Partner SteamID does not match the order",
      partnerMissingObservedCheck: "Partner SteamID not found on the page",
      partnerMissingExpectedCheck: "Order has no counterparty SteamID",
      copySteamId: "Copy",
      copied: "Copied",
      openProfile: "Steam profile",
      steamIdMissing: "SteamID unavailable",
      expectedCol: "Expected",
      observedCol: "In offer",
      preSendTitle: "Before you send",
      preSendBody: "Confirm the buyer and item. Confirm Guard only in Steam Mobile.",
      compareTitle: "Match against Steam"
    },
    acceptAssist: {
      acceptSteam: "Accept (Steam)",
      confirmAccept: "Confirm Accept in Steam",
      cancel: "Cancel",
      openVerified: "Open verified offer #{{short}} and accept with Steam\u2019s button",
      acceptNotFound: "Steam Accept button not found. Press the green Accept on the page manually.",
      acceptClickFailed: "Could not click Accept. Press Steam\u2019s green button manually.",
      doubleConfirm: "Confirm again \u2014 only then we click Accept in Steam. We never auto-accept.",
      guardHint: "If Steam asks for Guard \u2014 confirm in Steam Mobile.",
      confirmAgain: "If Confirm appears \u2014 tap \u201CAccept (Steam)\u201D again, or Confirm in Steam.",
      commandSent: "Command sent to Steam. {{guardHint}}",
      assistFailed: "Could not help with Accept. Press Steam\u2019s green button on the page.",
      highlightHint: "We highlight Steam\u2019s button. Accept only after your second confirmation."
    },
    manualCreate: {
      buildOffer: "Build offer #{{short}}",
      autoFailed: "Auto-send failed \u2014 we will build the offer via Steam UI: item + buyer Trade URL.",
      canBuild: "You can build the offer manually with the same autofill as auto-send."
    },
    ops: {
      never: "never yet",
      justNow: "just now",
      secondsAgo: "{{seconds}}s ago",
      minutesAgo: "{{minutes}} min ago",
      hoursAgo: "{{hours}} h ago",
      pollStale: "Poll stale \xB7 {{age}}",
      pollNever: "Poll: no successful run yet",
      pollOld: "Poll old \xB7 {{age}}",
      pollOk: "Poll: {{age}}",
      rateLimited: "Steam: rate limit \u2014 wait 1\u20132 min",
      rateOk: "Steam: no rate limit",
      version: "Version {{version}}",
      updateExtension: "Update extension"
    },
    onboarding: {
      coachTitle: "Sell on R.I.P right from here",
      coachBody: "List here \u2014 the trade goes out on purchase. You confirm Guard only in Steam Mobile.",
      coachDismiss: "Got it",
      autoHideHint: "Hides in ~30 sec",
      extensionReady: "Extension connected",
      extensionHint: "Pairing with the site is needed for prices, listing, and auto-trade.",
      extensionAction: "Connect",
      tradeUrlTitle: "Trade URL on the site",
      tradeUrlHint: "Without a Trade URL buyers cannot receive the trade after paying.",
      tradeUrlAction: "Add Trade URL",
      checklistTitle: "Seller readiness",
      checklistReady: "All set \u2014 you can list from Steam",
      checklistProgress: "Ready {{ready}} of {{total}}"
    },
    twoMin: {
      title: "Start",
      lead: "Four steps \u2014 then deals run themselves.",
      progress: "{{ready}} / {{total}}",
      stepInstall: "Extension installed",
      hintInstall: "You\u2019re already here \u2014 this step is done.",
      stepPair: "Connect to the site",
      hintPair: "Account \u2192 \u201CConnect extension\u201D on p2pcs.ru.",
      stepInventory: "Open CS2 inventory",
      hintInventory: "Steam Community \u2192 Inventory \u2192 Counter-Strike 2.",
      stepList: "Trial list",
      hintList: "Pick a skin \u2192 blue \u201CSell\u201D on the card. Guard later only in Mobile.",
      ctaPair: "Open account on site",
      ctaInventory: "Open CS2 inventory",
      ctaList: "List your first skin",
      ctaDone: "Done",
      dismiss: "Later",
      trialTitle: "Trial list (~30 sec)",
      trialBody: "On a skin card in the grid, tap blue \u201CSell\u201D (not Steam\u2019s green Sell on the right). This checks the path \u2014 not play money.",
      trialDismiss: "Hide tip"
    },
    overlay: {
      brand: "R.I.P Market",
      openDispute: "Open dispute",
      openDisputeSupport: "Open dispute / support",
      openOrder: "Open order"
    },
    inventory: {
      layerBrand: "R.I.P Market",
      steamEnrichmentDegraded: "Some Steam float/prices are still loading \u2014 blue \u201CSell\u201D on cards is already available."
    }
  };

  // src/shared/extension-messages-ru.ts
  var extensionMessagesRu = {
    common: {
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437",
      openSite: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u0430\u0439\u0442",
      more: "\u0415\u0449\u0451",
      loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026",
      cancel: "\u041E\u0442\u043C\u0435\u043D\u0430",
      buy: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430",
      sell: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430",
      buyer: "\u041F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044C",
      seller: "\u041F\u0440\u043E\u0434\u0430\u0432\u0435\u0446"
    },
    popup: {
      lead: "\u0421\u0434\u0435\u043B\u043A\u0438 \u0438 \u0441\u0442\u0430\u0442\u0443\u0441 \xB7 p2pcs",
      openSite: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u0430\u0439\u0442",
      refreshHealth: "\u0421\u0442\u0430\u0442\u0443\u0441",
      refreshTrades: "\u0421\u0434\u0435\u043B\u043A\u0438",
      copyDebug: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043E\u0442\u0447\u0451\u0442",
      copyDebugBusy: "\u041A\u043E\u043F\u0438\u0440\u0443\u0435\u043C\u2026",
      copyDebugDone: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u2713",
      copyDebugOpened: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E \xB7 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u043C \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      disconnect: "\u041E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      pairHint: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430 \u043D\u0430 p2pcs.ru.",
      advanced: "\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E",
      toolsTitle: "\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B",
      healthTitle: "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435",
      trustTitle: "\u0414\u043E\u0432\u0435\u0440\u0438\u0435",
      quietNotifyLabel: "\u0422\u043E\u043B\u044C\u043A\u043E \u0432\u0430\u0436\u043D\u044B\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043F\u043E \u0441\u0434\u0435\u043B\u043A\u0430\u043C",
      quietNotifyNote: "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0438 \u0441\u043C\u0435\u043D\u0435 \u0441\u0442\u0430\u0442\u0443\u0441\u0430 \u0441\u0434\u0435\u043B\u043A\u0438. \u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u2192 \u043E\u0434\u043D\u043E \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0435. \xAB\u041F\u043E\u0437\u0436\u0435\xBB \u043F\u0440\u044F\u0447\u0435\u0442 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u043D\u0430 15 \u043C\u0438\u043D\u0443\u0442. \xAB\u0421\u043A\u0440\u044B\u0442\u044C \u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0443\xBB \u0433\u043B\u0443\u0448\u0438\u0442 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u0434\u043E \u043A\u043E\u043D\u0446\u0430 \u0441\u0434\u0435\u043B\u043A\u0438.",
      supportEmergency: "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \xB7 \u0430\u0432\u0430\u0440\u0438\u0439\u043D\u044B\u0439 \u0434\u043E\u0441\u0442\u0443\u043F",
      apiKeyNote: "\u041D\u0435 \u0434\u043B\u044F \u043E\u0431\u044B\u0447\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u044B. \u0412\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u043A\u043B\u044E\u0447 \u0442\u043E\u043B\u044C\u043A\u043E \u0435\u0441\u043B\u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 R.I.P Market \u044F\u0432\u043D\u043E \u043F\u043E\u043F\u0440\u043E\u0441\u0438\u043B\u0430 \u2014 \u0438 \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 \u0432\u0440\u0435\u043C\u044F \u0441\u0431\u043E\u044F Steam.",
      apiKeyLabel: "\u0417\u0430\u043F\u0430\u0441\u043D\u043E\u0439 Steam Web API key",
      apiKeyPlaceholder: "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u043E \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0438",
      apiKeySave: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",
      apiKeyClear: "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C",
      apiKeyStatusSaved: "\u041A\u043B\u044E\u0447 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E; \u0434\u043E\u0441\u0442\u0443\u043F \u043A api.steampowered.com \u0432\u044B\u0434\u0430\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F fallback.",
      apiKeyStatusEmpty: "\u041A\u043B\u044E\u0447 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D \u2014 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u0432\u0430\u0448\u0443 \u0441\u0435\u0441\u0441\u0438\u044E Steam \u0432 Chrome.",
      apiKeyPermissionDenied: "Chrome \u043D\u0435 \u0432\u044B\u0434\u0430\u043B \u0434\u043E\u0441\u0442\u0443\u043F \u043A api.steampowered.com \u2014 \u043A\u043B\u044E\u0447 \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D.",
      permissionsTitle: "\u0417\u0430\u0447\u0435\u043C \u043D\u0443\u0436\u043D\u044B \u043F\u0440\u0430\u0432\u0430",
      languageLabel: "\u042F\u0437\u044B\u043A \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u0430",
      languageRu: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
      languageEn: "English",
      languageHint: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0441 \u0441\u0430\u0439\u0442\u043E\u043C \u043F\u0440\u0438 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0438; \u043C\u043E\u0436\u043D\u043E \u0441\u043C\u0435\u043D\u0438\u0442\u044C \u0437\u0434\u0435\u0441\u044C.",
      buyersTitle: "\u041F\u043E\u043A\u0443\u043F\u043A\u0438",
      buyersSub: "\u0416\u0434\u0451\u043C \u043E\u0444\u0444\u0435\u0440 \xB7 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F",
      sellersTitle: "\u041F\u0440\u043E\u0434\u0430\u0436\u0438",
      sellersSub: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435 \xB7 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438",
      receiptsTitle: "\u041D\u0435\u0434\u0430\u0432\u043D\u0438\u0435 \u0441\u0434\u0435\u043B\u043A\u0438",
      receiptsSub: "\u0421\u0443\u043C\u043C\u0430, \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u044F \u0438 \u043E\u0431\u043C\u0435\u043D",
      actionTitle: "\u041D\u0443\u0436\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435",
      actionSub: "\u041E\u0434\u0438\u043D \u0433\u043B\u0430\u0432\u043D\u044B\u0439 \u0448\u0430\u0433 \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435",
      snoozeLater: "\u041F\u043E\u0437\u0436\u0435",
      emptyTitle: "\u0412\u0441\u0451 \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u043E",
      emptyBody: "\u041D\u0435\u0442 \u0441\u0434\u0435\u043B\u043E\u043A, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u044F\u043C\u043E \u0441\u0435\u0439\u0447\u0430\u0441."
    },
    safeMode: {
      offlineTitle: "\u0421\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u0430 \xB7 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C",
      offlineBody: "\u0421\u0430\u0439\u0442 \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435 \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0442\u044C\u0441\u044F, \u043D\u043E API \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u041F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u043C \u043A\u044D\u0448; \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043E\u0444\u0444\u0435\u0440\u043E\u0432 \u0441 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B, \u043F\u043E\u043A\u0430 \u0441\u0432\u044F\u0437\u044C \u043D\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0441\u044F.",
      degradedTitle: "\u0421\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430",
      degradedBody: "\u041A\u044D\u0448 \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435. \u0412\u044B\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u2014 Guard \u0438\u043B\u0438 Accept \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Steam, \u0435\u0441\u043B\u0438 \u043E\u0444\u0444\u0435\u0440 \u0443\u0436\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D.",
      cacheLine: "\u041A\u044D\u0448 \u0441\u0434\u0435\u043B\u043E\u043A \xB7 {{when}}",
      cacheEmpty: "\u041A\u044D\u0448\u0430 \u0441\u0434\u0435\u043B\u043E\u043A \u043F\u043E\u043A\u0430 \u043D\u0435\u0442 \u2014 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435, \u043A\u043E\u0433\u0434\u0430 API \u043E\u0436\u0438\u0432\u0451\u0442.",
      hint: "\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C: list \u0438 send \u0441 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B.",
      waitCta: "\u0416\u0434\u0451\u043C \u0441\u0432\u044F\u0437\u044C \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C",
      blockMessage: "API \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0438\u043B\u0438 \u0441\u0432\u044F\u0437\u044C \u043D\u0435\u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0430 \u2014 \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0430 \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043E\u0444\u0444\u0435\u0440\u043E\u0432 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B (\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C)."
    },
    cta: {
      openDispute: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440",
      openDisputeSupport: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440 / \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437",
      confirmGuard: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile",
      openTradeUrl: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C Trade URL",
      retrySend: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      retryAutoSend: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0430\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      confirmSent: "\u042F \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043B \u043E\u0431\u043C\u0435\u043D",
      openVerifiedOffer: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440",
      openVerifiedOfferSteam: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u0432 Steam",
      preAcceptAck: "\u0412\u0438\u0436\u0443 \u0432\u0435\u0440\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435",
      problemSupport: "\u041F\u0440\u043E\u0431\u043B\u0435\u043C\u0430 \u0441 \u043E\u0431\u043C\u0435\u043D\u043E\u043C",
      confirmReceived: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u043C\u0435\u043D\u044F",
      openOfferSteam: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u0444\u0444\u0435\u0440 \u0432 Steam",
      platformStatus: "\u0421\u0442\u0430\u0442\u0443\u0441 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      refreshStatus: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0430\u0442\u0443\u0441",
      waitSeller: "\u0416\u0434\u0451\u043C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      open: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C",
      openAccount: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442",
      loginNeededSteam: "\u0412\u043E\u0439\u0442\u0438 \u0432 \u043D\u0443\u0436\u043D\u044B\u0439 Steam",
      loginSteam: "\u0412\u043E\u0439\u0442\u0438 \u0432 Steam",
      openSteamInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam"
    },
    nextAction: {
      hintDisputeOpen: "\u0421\u043F\u043E\u0440 \u0443\u0436\u0435 \u043E\u0442\u043A\u0440\u044B\u0442 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0443\u0439\u0434\u0451\u0442 \u0432 \u0442\u0438\u043A\u0435\u0442. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u0438\u0435 \u043E\u0444\u0444\u0435\u0440\u044B.",
      hintMismatch: "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u0432 Steam. \u0414\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u0441\u044F \u0432 \u0442\u0438\u043A\u0435\u0442.",
      hintGuard: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 Guard \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u044B \u0432 Steam Mobile.",
      hintManualWithUrl: "\u041E\u0442\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0441\u043A\u0438\u043D \u0432\u0440\u0443\u0447\u043D\u0443\u044E, \u0437\u0430\u0442\u0435\u043C \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 offerId \u043D\u0430 \u0437\u0430\u043A\u0430\u0437\u0435.",
      hintManualRetry: "\u0410\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043D\u0435 \u0441\u043C\u043E\u0433\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C\u0441\u044F \u2014 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437.",
      hintAccept: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Accept \u0432 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043E\u0444\u0444\u0435\u0440\u0430.",
      hintConfirmReceived: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u043D\u0430 \u0441\u0430\u0439\u0442 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.",
      hintVerifying: "\u041F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u0441\u0432\u0435\u0440\u044F\u0435\u0442 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443 \u2014 \u043E\u0431\u044B\u0447\u043D\u043E \u043D\u0438\u0447\u0435\u0433\u043E \u0434\u0435\u043B\u0430\u0442\u044C \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.",
      hintWaitSeller: "\u041A\u0430\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0444\u0444\u0435\u0440 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u2014 \u0437\u0434\u0435\u0441\u044C \u0431\u0443\u0434\u0435\u0442 \u043A\u043D\u043E\u043F\u043A\u0430 \u043F\u0440\u0438\u043D\u044F\u0442\u044C.",
      hintWaitBuyer: "\u041E\u0431\u043C\u0435\u043D \u0443 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F. \u0421\u0442\u0430\u0442\u0443\u0441 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0441\u0430\u043C \u043F\u043E\u0441\u043B\u0435 Accept."
    },
    dealConfirm: {
      acceptTitle: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u0432 Steam",
      acceptBody: "\u0421\u0432\u0435\u0440\u044C\u0442\u0435 \u0449\u0438\u0442 \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 Accept. \u041C\u044B \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C \u0437\u0430 \u0432\u0430\u0441.",
      receivedTitle: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u0432\u0430\u0441?",
      receivedBody: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u0441\u0442\u0430\u0442\u0443\u0441 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0441\u0430\u043C.",
      verifyingTitle: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      verifyingBody: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C Steam \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C. \u041E\u0431\u044B\u0447\u043D\u043E \u0436\u0434\u0430\u0442\u044C \u043D\u0435\u0434\u043E\u043B\u0433\u043E.",
      doneTitle: "\u0413\u043E\u0442\u043E\u0432\u043E",
      doneBody: "\u0421\u0434\u0435\u043B\u043A\u0430 \u0443 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438. \u0417\u0430\u043A\u0430\u0437 \u043C\u043E\u0436\u043D\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438.",
      guardTitle: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile",
      guardBody: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443 \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438 Steam. \u0415\u0441\u043B\u0438 \u0441\u0442\u0430\u0442\u0443\u0441 \u0437\u0430\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F, \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435."
    },
    badge: {
      rePair: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      steam: "Steam",
      inventory: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C",
      guard: "Guard",
      accept: "Accept",
      mismatch: "Mismatch",
      sendManual: "\u0412\u0440\u0443\u0447\u043D\u0443\u044E",
      confirmSent: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C",
      confirmReceived: "\u041F\u043E\u043B\u0443\u0447\u0435\u043D\u043E",
      reportIssue: "\u041F\u0440\u043E\u0431\u043B\u0435\u043C\u0430"
    },
    connection: {
      revokedTitle: "\u0421\u0435\u0441\u0441\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u0430",
      revokedDetail: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430.",
      offTitle: "\u041D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u043A \u0441\u0430\u0439\u0442\u0443",
      offDetail: "\u0421\u0430\u0439\u0442 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442 \u2014 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB (\u044D\u0442\u043E \u043D\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 Chrome).",
      steamUnknown: "Steam: \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E",
      mismatchTitle: "\u0421\u0430\u0439\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \xB7 \u0434\u0440\u0443\u0433\u043E\u0439 Steam",
      mismatchDetail: "Steam \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      noSteamTitle: "\u0421\u0430\u0439\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \xB7 \u043D\u0435\u0442 \u0432\u0445\u043E\u0434\u0430 \u0432 Steam",
      noSteamDetail: "Steam: \u043D\u0435\u0442 \u0441\u0435\u0441\u0441\u0438\u0438",
      connectedUntil: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u0434\u043E {{expires}}",
      connectedOkTitle: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E \xB7 \u0441\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442",
      inventoryIssueTitle: "Steam \u043E\u043A \xB7 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u0441 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u043E\u0439",
      connectedTitle: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      connectedDetail: "\u0421\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442 \u2014 \u043C\u043E\u0436\u043D\u043E \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0441\u043E \u0441\u0434\u0435\u043B\u043A\u0430\u043C\u0438.",
      steamAligned: "\u0421\u0430\u0439\u0442 \u0438 Steam \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442"
    },
    buyerPhase: {
      wait_offer: "\u0416\u0434\u0451\u043C \u043E\u0444\u0444\u0435\u0440",
      accept: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C",
      verifying: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F",
      dispute: "\u0421\u043F\u043E\u0440 / \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430"
    },
    timeout: {
      expired: "\u0412\u0440\u0435\u043C\u044F \u043D\u0430 \u043E\u0431\u043C\u0435\u043D \u0438\u0441\u0442\u0435\u043A\u043B\u043E \u2014 \u0441\u043A\u043E\u0440\u043E \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0442\u044C\u0441\u044F \u0441\u043F\u043E\u0440",
      minutes: "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ~{{minutes}} \u043C\u0438\u043D \u0434\u043E \u0430\u0432\u0442\u043E\u0441\u043F\u043E\u0440\u0430",
      hoursMinutes: "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ~{{hours}} \u0447 {{minutes}} \u043C\u0438\u043D \u0434\u043E \u0430\u0432\u0442\u043E\u0441\u043F\u043E\u0440\u0430"
    },
    settlement: {
      soonSuffix: "{{formatted}} (\u0441\u043A\u043E\u0440\u043E)",
      offerOk: "Steam offer: \u043F\u0440\u0438\u043D\u044F\u0442",
      offerWarn: "Steam offer: \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430",
      offerPending: "Steam offer: \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C",
      offerUnknown: "Steam offer: \u0443\u0442\u043E\u0447\u043D\u044F\u0435\u043C",
      invOk: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0441\u043A\u0438\u043D \u0443 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F",
      invWarn: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0435\u0449\u0451 \u0443 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      invPending: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C",
      invUnknown: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C: \u0443\u0442\u043E\u0447\u043D\u044F\u0435\u043C",
      deliveryTitleSeller: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      deliveryTitleBuyer: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443 \u0432\u0430\u0441 \u2014 \u0441\u0432\u0435\u0440\u044F\u0435\u043C \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443",
      deliveryBodySeller: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C Steam offer \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C. \u041D\u043E\u0432\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u043F\u043E \u044D\u0442\u043E\u0439 \u0441\u0434\u0435\u043B\u043A\u0435 \u043D\u0435 \u043D\u0443\u0436\u0435\u043D.",
      deliveryBodyBuyer: "\u041D\u0438\u0447\u0435\u0433\u043E \u0434\u0435\u043B\u0430\u0442\u044C \u043D\u0435 \u043D\u0443\u0436\u043D\u043E \u2014 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u0441\u0432\u0435\u0440\u044F\u0435\u0442 Steam offer \u0438 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C.",
      fundsSellerKnown: "\u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0431\u0443\u0434\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B: {{date}}",
      fundsSellerUnknown: "\u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0431\u0443\u0434\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 (\u0434\u043E {{days}} \u0434\u043D.)",
      fundsBuyerKnown: "\u0412\u044B\u043F\u043B\u0430\u0442\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u0441: {{date}}",
      fundsBuyerUnknown: "\u0412\u044B\u043F\u043B\u0430\u0442\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 (\u0434\u043E {{days}} \u0434\u043D.)",
      holdTitleSeller: "\u0412\u044B\u0440\u0443\u0447\u043A\u0430 \u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0435",
      holdTitleBuyer: "\u0421\u043A\u0438\u043D \u0432\u0430\u0448 \u2014 \u0440\u0430\u0441\u0447\u0451\u0442 \u0443 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438",
      holdBodySeller: "\u0417\u0430\u0449\u0438\u0442\u0430 \u043E\u0442 chargeback \u0438 \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u0430 \u043E\u0431\u043C\u0435\u043D\u0430 \u0432 Steam. \u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0441\u0442\u0430\u043D\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u043F\u043E\u0441\u043B\u0435 \u043F\u0435\u0440\u0438\u043E\u0434\u0430 \u0437\u0430\u0449\u0438\u0442\u044B.",
      holdBodyBuyer: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0432 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u0435. \u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u2014 \u043F\u043E\u0441\u043B\u0435 \u043E\u043A\u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435."
    },
    dispute: {
      openTitle: "\u0421\u043F\u043E\u0440 \u043E\u0442\u043A\u0440\u044B\u0442",
      openBody: "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \u0440\u0430\u0437\u0431\u0438\u0440\u0430\u0435\u0442 \u0441\u0434\u0435\u043B\u043A\u0443. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u0434\u0440\u0443\u0433\u0438\u0435 \u043E\u0444\u0444\u0435\u0440\u044B \u043F\u043E \u044D\u0442\u043E\u043C\u0443 \u0437\u0430\u043A\u0430\u0437\u0443 \u0438 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442\u0435 \u0434\u0435\u043D\u044C\u0433\u0438 \u0432 \u0447\u0430\u0442.",
      needTitle: "\u041D\u0443\u0436\u0435\u043D \u0441\u043F\u043E\u0440",
      needMismatch: "\u041E\u0444\u0444\u0435\u0440 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u041D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435 Accept \u2014 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u043F\u043E\u0440 \u0441 \u0434\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438.",
      needGeneric: "\u0415\u0441\u0442\u044C \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0430 \u043F\u043E \u0441\u0434\u0435\u043B\u043A\u0435. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u043F\u043E\u0440 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u0441\u044F \u0432 \u0442\u0438\u043A\u0435\u0442 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438.",
      ticketPlaceholder: "(\u043E\u043F\u0438\u0448\u0438\u0442\u0435, \u0447\u0442\u043E \u043F\u043E\u0448\u043B\u043E \u043D\u0435 \u0442\u0430\u043A)"
    },
    receipt: {
      eyebrow: "\u041A\u0432\u0438\u0442\u0430\u043D\u0446\u0438\u044F",
      bought: "\u041A\u0443\u043F\u0438\u043B\u0438",
      sold: "\u041F\u0440\u043E\u0434\u0430\u043B\u0438",
      price: "\u0426\u0435\u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0438",
      commission: "\u041A\u043E\u043C\u0438\u0441\u0441\u0438\u044F \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438 (5%)",
      paid: "\u041E\u043F\u043B\u0430\u0442\u0438\u043B\u0438",
      credited: "\u041A \u0437\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044E",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437"
    },
    session: {
      okTitle: "\u0413\u043E\u0442\u043E\u0432\u043E \u043A \u0441\u0434\u0435\u043B\u043A\u0430\u043C",
      okMessage: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0438 Steam \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u044B.",
      disconnectedTitle: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      disconnectedMessage: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0430\u0439\u0442 \u2192 \u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB.",
      disconnectedCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      revokedTitle: "\u0421\u0435\u0441\u0441\u0438\u044F \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u0430",
      revokedMessage: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u043D\u043E\u0432\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430.",
      revokedCta: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      cookieTitle: "\u041D\u0435\u0442 \u0432\u0445\u043E\u0434\u0430 \u0432 Steam",
      cookieMessage: "\u0412\u043E\u0439\u0434\u0438\u0442\u0435 \u0432 steamcommunity.com \u0432 \u044D\u0442\u043E\u043C Chrome \u043F\u043E\u0434 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u043E\u043C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430.",
      cookieCta: "\u0412\u043E\u0439\u0442\u0438 \u0432 Steam",
      mismatchTitle: "\u0414\u0440\u0443\u0433\u043E\u0439 Steam \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435",
      mismatchMessage: "\u0412 Chrome \u0437\u0430\u043B\u043E\u0433\u0438\u043D\u0435\u043D {{session}}, \u043D\u0443\u0436\u0435\u043D {{expected}}",
      mismatchCta: "\u0412\u043E\u0439\u0442\u0438 \u0432 \u043D\u0443\u0436\u043D\u044B\u0439 Steam",
      privateTitle: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u0441\u043A\u0440\u044B\u0442",
      privateMessage: "\u0421\u0434\u0435\u043B\u0430\u0439\u0442\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2 \u0432\u0438\u0434\u0438\u043C\u044B\u043C \u0434\u043B\u044F \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F (Privacy \u2192 Inventory: Public).",
      privateCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 Steam",
      rateTitle: "Steam \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0438\u043B \u0437\u0430\u043F\u0440\u043E\u0441\u044B",
      rateMessage: "\u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 1\u20132 \u043C\u0438\u043D\u0443\u0442\u044B \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0441\u043D\u043E\u0432\u0430\xBB. \u041A\u043B\u044E\u0447 Steam \u043D\u0435 \u043D\u0443\u0436\u0435\u043D \u2014 \u043F\u0440\u0438 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u043C \u0441\u0431\u043E\u0435 \u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 \u0432 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443.",
      rateCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam",
      inventoryTitle: "\u0418\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u043B\u0441\u044F",
      inventoryMessage: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2 \u0432 Steam \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443.",
      inventoryCta: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C Steam"
    },
    notify: {
      guardTitle: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430 \u2014 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 Guard",
      guardBody: "{{short}} \xB7 {{item}}. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 Steam Mobile \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D.",
      acceptTitle: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430 \u2014 \u043E\u0444\u0444\u0435\u0440 \u0433\u043E\u0442\u043E\u0432 \u043A accept",
      acceptBody: "{{short}} \xB7 {{item}}. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 \u0432 Steam.",
      mismatchTitle: "Mismatch \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      mismatchBody: "{{short}} \xB7 {{item}}. \u0421\u043A\u0438\u043D \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u2014 \u043D\u0435 \u0436\u043C\u0438\u0442\u0435 Accept.",
      newDealTitle: "\u041D\u043E\u0432\u0430\u044F \u043F\u0440\u043E\u0434\u0430\u0436\u0430 \u2014 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u043C \u043E\u0431\u043C\u0435\u043D",
      newDealBody: "{{short}} \xB7 {{item}}. \u041E\u0441\u0442\u0430\u0432\u044C\u0442\u0435 Steam \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u043C \u2014 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442 offer.",
      groupMismatch: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E mismatch \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      groupGuard: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E\u0434\u0430\u0436 \u0436\u0434\u0443\u0442 Guard",
      groupAccept: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u043A\u0443\u043F\u043E\u043A \u0436\u0434\u0443\u0442 accept",
      groupNewDeal: "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043D\u043E\u0432\u044B\u0445 \u043F\u0440\u043E\u0434\u0430\u0436",
      groupBody: "{{count}} \u0441\u0434\u0435\u043B\u043A\u0438 \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F",
      muteDeal: "\u0421\u043A\u0440\u044B\u0442\u044C \u043D\u0430 \u0441\u0434\u0435\u043B\u043A\u0443"
    },
    cardContext: {
      buy: "\u041F\u043E\u043A\u0443\u043F\u043A\u0430",
      sell: "\u041F\u0440\u043E\u0434\u0430\u0436\u0430",
      dispute: "\u0421\u043F\u043E\u0440",
      mismatch: "\u041D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      waitGuard: "\u0416\u0434\u0451\u043C Guard",
      waitAccept: "\u0416\u0434\u0451\u0442 Accept",
      sendManual: "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0432\u0440\u0443\u0447\u043D\u0443\u044E",
      confirmSent: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443",
      confirmReceived: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u0435",
      platformCheck: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0438",
      completed: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E",
      offerReady: "\u041E\u0444\u0444\u0435\u0440 \u0433\u043E\u0442\u043E\u0432",
      waitBuyer: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F",
      checking: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u2026",
      waitTrade: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043E\u0431\u043C\u0435\u043D",
      tradeConfirmed: "\u041E\u0431\u043C\u0435\u043D \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D",
      hold: "Hold / \u0440\u0430\u0441\u0447\u0451\u0442",
      failed: "\u0412\u043E\u0437\u0432\u0440\u0430\u0442",
      canceled: "\u041E\u0442\u043C\u0435\u043D\u0451\u043D",
      inProgress: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435"
    },
    guided: {
      mismatchTitle: "\u041D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      mismatchBuyer: "\u042D\u0442\u043E\u0442 offer \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C R.I.P Market. \u041D\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435 Accept \u0432 Steam.",
      mismatchSeller: "Offer \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u0438 \u043D\u0435 \u043F\u0440\u043E\u0441\u0438\u0442\u0435 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C.",
      verifiedTitle: "\u0421\u043A\u0438\u043D \u0441\u043E\u0432\u043F\u0430\u043B",
      verifiedBuyer: "\u041C\u043E\u0436\u043D\u043E \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435. \u0414\u0435\u043D\u044C\u0433\u0438 \u0443\u0436\u0435 \u043D\u0430 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435 \u2014 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442\u0435 \u0432 \u0447\u0430\u0442.",
      verifiedSeller: "\u041E\u0431\u043C\u0435\u043D \u0441\u043E\u0432\u043F\u0430\u043B \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C. \u0414\u0430\u043B\u044C\u0448\u0435 \u043F\u043E next step \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 / Guard.",
      partialTitle: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u2026",
      partialBody: "\u0427\u0430\u0441\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043E\u043A \u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430. \u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u2014 Accept \u043F\u043E\u043A\u0430 \u043D\u0435 \u0442\u043E\u0440\u043E\u043F\u0438\u0442\u0435.",
      pendingTitle: "\u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438",
      pendingBody: "\u0421\u0432\u0435\u0440\u044F\u0435\u043C offer \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C R.I.P Market.",
      name: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435",
      stickers: "\u0421\u0442\u0438\u043A\u0435\u0440\u044B",
      partner: "\u041F\u0430\u0440\u0442\u043D\u0451\u0440 SteamID",
      assetId: "Asset ID",
      wear: "\u0418\u0437\u043D\u043E\u0441",
      float: "Float",
      hintBlock: "\u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u044D\u0442\u043E\u0442 \u043E\u0431\u043C\u0435\u043D \u0432 Steam",
      hintAccept: "\u041F\u0440\u0438\u043C\u0438\u0442\u0435 \u043E\u0431\u043C\u0435\u043D \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam \u043D\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435",
      hintWait: "\u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u2014 Accept \u043F\u043E\u043A\u0430 \u043D\u0435 \u0442\u043E\u0440\u043E\u043F\u0438\u0442\u0435"
    },
    offerGate: {
      needCs2Title: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 CS2",
      needCs2Body: "\u0412 \u0441\u043F\u0438\u0441\u043A\u0435 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044F \u0441\u043B\u0435\u0432\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 Counter-Strike 2. \u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u0430\u043C\u043E \u0434\u043E\u0431\u0430\u0432\u0438\u0442 \u0441\u043A\u0438\u043D \u0441\u0434\u0435\u043B\u043A\u0438.",
      needItemTitle: "\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0441\u043A\u0438\u043D \u0432 \u043E\u0431\u043C\u0435\u043D",
      needItemBody: "\u041D\u0443\u0436\u043D\u044B\u0439 \u043F\u0440\u0435\u0434\u043C\u0435\u0442: {{name}}. \u041A\u043B\u0438\u043A\u043D\u0438\u0442\u0435 \u0435\u0433\u043E \u0432 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u0435 \u2014 \u043E\u043D \u0434\u043E\u043B\u0436\u0435\u043D \u043F\u043E\u044F\u0432\u0438\u0442\u044C\u0441\u044F \u0432 \xAB\u0412\u0430\u0448\u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B\xBB.",
      itemReadyTitle: "\u0421\u043A\u0438\u043D \u0432 \u043E\u0431\u043C\u0435\u043D\u0435",
      itemReadyBody: "\u0421\u0432\u0435\u0440\u044C\u0442\u0435 \u0449\u0438\u0442 \u0441\u043F\u0440\u0430\u0432\u0430 \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0438\u0442\u044C \u043E\u0431\u043C\u0435\u043D\xBB \u0432 Steam. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438."
    },
    shield: {
      dealLine: "\u0417\u0430\u043A\u0430\u0437 #{{short}} \xB7 {{amount}}",
      wear: "\u0418\u0437\u043D\u043E\u0441",
      float: "Float",
      stickers: "\u0421\u0442\u0438\u043A\u0435\u0440\u044B",
      unknownPartner: "\u041A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442",
      partnerMatch: "Steam-\u043F\u0430\u0440\u0442\u043D\u0451\u0440 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442",
      partnerMismatch: "Steam-\u043F\u0430\u0440\u0442\u043D\u0451\u0440 \u041D\u0415 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u2014 \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435",
      partnerMissingObserved: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u0447\u0438\u0442\u0430\u0442\u044C \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B Steam",
      partnerMissingExpected: "\u0412 \u0437\u0430\u043A\u0430\u0437\u0435 \u043D\u0435\u0442 SteamID \u043A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442\u0430",
      partnerUnknown: "\u041F\u0430\u0440\u0442\u043D\u0451\u0440 \u043D\u0435 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D",
      partnerMatchCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C",
      partnerMismatchCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043A\u0430\u0437\u043E\u043C",
      partnerMissingObservedCheck: "SteamID \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D",
      partnerMissingExpectedCheck: "\u0412 \u0437\u0430\u043A\u0430\u0437\u0435 \u043D\u0435\u0442 SteamID \u043A\u043E\u043D\u0442\u0440\u0430\u0433\u0435\u043D\u0442\u0430",
      copySteamId: "\u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C",
      copied: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E",
      openProfile: "\u041F\u0440\u043E\u0444\u0438\u043B\u044C Steam",
      steamIdMissing: "SteamID \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D",
      expectedCol: "\u041E\u0436\u0438\u0434\u0430\u0435\u043C",
      observedCol: "\u0412 \u043E\u0444\u0444\u0435\u0440\u0435",
      preSendTitle: "\u041F\u0435\u0440\u0435\u0434 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u043E\u0439",
      preSendBody: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Steam Mobile.",
      compareTitle: "\u0421\u0432\u0435\u0440\u043A\u0430 \u0441 Steam"
    },
    acceptAssist: {
      acceptSteam: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C (Steam)",
      confirmAccept: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C Accept \u0432 Steam",
      cancel: "\u041E\u0442\u043C\u0435\u043D\u0430",
      openVerified: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043E\u0444\u0444\u0435\u0440 #{{short}} \u0438 \u043F\u0440\u0438\u043D\u044F\u0442\u044C \u043A\u043D\u043E\u043F\u043A\u043E\u0439 Steam",
      acceptNotFound: "\u041A\u043D\u043E\u043F\u043A\u0430 Accept \u0432 Steam \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E Accept \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0432\u0440\u0443\u0447\u043D\u0443\u044E.",
      acceptClickFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043D\u0430\u0436\u0430\u0442\u044C Accept. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u0432\u0440\u0443\u0447\u043D\u0443\u044E.",
      doubleConfirm: "\u0415\u0449\u0451 \u0440\u0430\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u043E\u0433\u0434\u0430 \u043D\u0430\u0436\u043C\u0451\u043C Accept \u0432 Steam. \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u043E\u043C \u043D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C.",
      guardHint: "\u0415\u0441\u043B\u0438 Steam \u043F\u043E\u043F\u0440\u043E\u0441\u0438\u0442 Guard \u2014 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile.",
      confirmAgain: "\u0415\u0441\u043B\u0438 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F Confirm \u2014 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437 \xAB\u041F\u0440\u0438\u043D\u044F\u0442\u044C (Steam)\xBB, \u043B\u0438\u0431\u043E Confirm \u0432 Steam.",
      commandSent: "\u041A\u043E\u043C\u0430\u043D\u0434\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0430 \u0432 Steam. {{guardHint}}",
      assistFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043C\u043E\u0447\u044C \u0441 Accept. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435.",
      highlightHint: "\u041F\u043E\u0434\u0441\u0432\u0435\u0442\u0438\u043C \u043A\u043D\u043E\u043F\u043A\u0443 Steam. Accept \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0441\u043B\u0435 \u0432\u0430\u0448\u0435\u0433\u043E \u0432\u0442\u043E\u0440\u043E\u0433\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F."
    },
    manualCreate: {
      buildOffer: "\u0421\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440 #{{short}}",
      autoFailed: "\u0410\u0432\u0442\u043E \u043D\u0435 \u0441\u043C\u043E\u0433 \u2014 \u0441\u043E\u0431\u0435\u0440\u0451\u043C \u043E\u0444\u0444\u0435\u0440 \u0447\u0435\u0440\u0435\u0437 Steam UI: \u043F\u0440\u0435\u0434\u043C\u0435\u0442 + Trade URL \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F.",
      canBuild: "\u041C\u043E\u0436\u043D\u043E \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440 \u0432\u0440\u0443\u0447\u043D\u0443\u044E \u0447\u0435\u0440\u0435\u0437 \u0442\u043E\u0442 \u0436\u0435 autofill, \u0447\u0442\u043E \u0438 \u0430\u0432\u0442\u043E-\u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430."
    },
    ops: {
      never: "\u0435\u0449\u0451 \u043D\u0435 \u0431\u044B\u043B\u043E",
      justNow: "\u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E",
      secondsAgo: "{{seconds}} \u0441\u0435\u043A \u043D\u0430\u0437\u0430\u0434",
      minutesAgo: "{{minutes}} \u043C\u0438\u043D \u043D\u0430\u0437\u0430\u0434",
      hoursAgo: "{{hours}} \u0447 \u043D\u0430\u0437\u0430\u0434",
      pollStale: "\u041E\u043F\u0440\u043E\u0441 \u0443\u0441\u0442\u0430\u0440\u0435\u043B \xB7 {{age}}",
      pollNever: "\u041E\u043F\u0440\u043E\u0441: \u0435\u0449\u0451 \u043D\u0435 \u0431\u044B\u043B\u043E \u0443\u0441\u043F\u0435\u0448\u043D\u043E\u0433\u043E",
      pollOld: "\u041E\u043F\u0440\u043E\u0441 \u0434\u0430\u0432\u043D\u043E \xB7 {{age}}",
      pollOk: "\u041E\u043F\u0440\u043E\u0441: {{age}}",
      rateLimited: "Steam: rate limit \u2014 \u043F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 1\u20132 \u043C\u0438\u043D",
      rateOk: "Steam: \u0431\u0435\u0437 rate limit",
      version: "\u0412\u0435\u0440\u0441\u0438\u044F {{version}}",
      updateExtension: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435"
    },
    onboarding: {
      coachTitle: "\u041F\u0440\u043E\u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u043D\u0430 R.I.P \u043F\u0440\u044F\u043C\u043E \u043E\u0442\u0441\u044E\u0434\u0430",
      coachBody: "\u0412\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0441\u044E\u0434\u0430 \u2014 \u043E\u0431\u043C\u0435\u043D \u043F\u0440\u0438 \u043F\u043E\u043A\u0443\u043F\u043A\u0435 \u0443\u0439\u0434\u0451\u0442 \u0441\u0430\u043C. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u044B \u0432 Steam Mobile.",
      coachDismiss: "\u041F\u043E\u043D\u044F\u0442\u043D\u043E",
      autoHideHint: "\u0421\u043A\u0440\u043E\u0435\u0442\u0441\u044F \u0447\u0435\u0440\u0435\u0437 ~30 \u0441\u0435\u043A",
      extensionReady: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E",
      extensionHint: "\u041F\u0430\u0440\u0430 \u0441 \u0441\u0430\u0439\u0442\u043E\u043C \u043D\u0443\u0436\u043D\u0430 \u0434\u043B\u044F \u0446\u0435\u043D, \u0432\u044B\u0441\u0442\u0430\u0432\u043A\u0438 \u0438 \u0430\u0432\u0442\u043E-\u043E\u0431\u043C\u0435\u043D\u0430.",
      extensionAction: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C",
      tradeUrlTitle: "Trade URL \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      tradeUrlHint: "\u0411\u0435\u0437 Trade URL \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u0438 \u043D\u0435 \u0441\u043C\u043E\u0433\u0443\u0442 \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043E\u0431\u043C\u0435\u043D \u043F\u043E\u0441\u043B\u0435 \u043E\u043F\u043B\u0430\u0442\u044B.",
      tradeUrlAction: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C Trade URL",
      checklistTitle: "\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430",
      checklistReady: "\u0412\u0441\u0451 \u0433\u043E\u0442\u043E\u0432\u043E \u2014 \u043C\u043E\u0436\u043D\u043E \u0432\u044B\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u0438\u0437 Steam",
      checklistProgress: "\u0413\u043E\u0442\u043E\u0432\u043E {{ready}} \u0438\u0437 {{total}}"
    },
    twoMin: {
      title: "\u0421\u0442\u0430\u0440\u0442",
      lead: "\u0427\u0435\u0442\u044B\u0440\u0435 \u0448\u0430\u0433\u0430 \u2014 \u0438 \u0441\u0434\u0435\u043B\u043A\u0438 \u0438\u0434\u0443\u0442 \u0441\u0430\u043C\u0438.",
      progress: "{{ready}} / {{total}}",
      stepInstall: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E",
      hintInstall: "\u0412\u044B \u0443\u0436\u0435 \u0437\u0434\u0435\u0441\u044C \u2014 \u044D\u0442\u043E\u0442 \u0448\u0430\u0433 \u0433\u043E\u0442\u043E\u0432.",
      stepPair: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043A \u0441\u0430\u0439\u0442\u0443",
      hintPair: "\u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u2192 \xAB\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435\xBB \u043D\u0430 p2pcs.ru.",
      stepInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2",
      hintInventory: "Steam Community \u2192 Inventory \u2192 Counter-Strike 2.",
      stepList: "\u041F\u0440\u043E\u0431\u043D\u044B\u0439 list",
      hintList: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043A\u0438\u043D \u2192 \u0441\u0438\u043D\u044F\u044F \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435. Guard \u043F\u043E\u0442\u043E\u043C \u0442\u043E\u043B\u044C\u043A\u043E \u0432 Mobile.",
      ctaPair: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435",
      ctaInventory: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C CS2",
      ctaList: "\u0412\u044B\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u0435\u0440\u0432\u044B\u0439 \u0441\u043A\u0438\u043D",
      ctaDone: "\u0413\u043E\u0442\u043E\u0432\u043E",
      dismiss: "\u041F\u043E\u0437\u0436\u0435",
      trialTitle: "\u041F\u0440\u043E\u0431\u043D\u044B\u0439 list (~30 \u0441\u0435\u043A)",
      trialBody: "\u041D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435 \u0441\u043A\u0438\u043D\u0430 \u0432 \u0441\u0435\u0442\u043A\u0435 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0441\u0438\u043D\u044E\u044E \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB (\u043D\u0435 \u0437\u0435\u043B\u0451\u043D\u0443\u044E \u043A\u043D\u043E\u043F\u043A\u0443 Steam \u0441\u043F\u0440\u0430\u0432\u0430). \u042D\u0442\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u0443\u0442\u0438 \u2014 \u043D\u0435 \u0442\u0435\u0441\u0442-\u0434\u0435\u043D\u044C\u0433\u0438.",
      trialDismiss: "\u0421\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0443"
    },
    overlay: {
      brand: "R.I.P Market",
      openDispute: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440",
      openDisputeSupport: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u043E\u0440 / \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443",
      openOrder: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437"
    },
    inventory: {
      layerBrand: "R.I.P Market",
      steamEnrichmentDegraded: "\u0427\u0430\u0441\u0442\u044C float/\u0446\u0435\u043D Steam \u0435\u0449\u0451 \u043F\u043E\u0434\u0433\u0440\u0443\u0436\u0430\u0435\u0442\u0441\u044F \u2014 \u0441\u0438\u043D\u044F\u044F \xAB\u041F\u0440\u043E\u0434\u0430\u0442\u044C\xBB \u043D\u0430 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430\u0445 \u0443\u0436\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430."
    }
  };

  // src/shared/extension-i18n.ts
  var messagesByLocale = {
    ru: extensionMessagesRu,
    en: extensionMessagesEn
  };
  function tx(locale, key, params) {
    return translateExtension(messagesByLocale[locale], key, params);
  }
  function createExtensionT(locale) {
    return (key, params) => tx(locale, key, params);
  }

  // src/shared/manual-create-offer.ts
  function canManualCreateOffer(trade) {
    if (trade.role !== "seller") {
      return false;
    }
    if (trade.orderStatus !== "WAITING_TRADE") {
      return false;
    }
    if (trade.nextAction.kind === "confirm_guard") {
      return false;
    }
    if (trade.offerId?.trim()) {
      return false;
    }
    if (!trade.buyerTradeUrl?.trim()) {
      return false;
    }
    if (!trade.item.assetExternalId?.trim()) {
      return false;
    }
    return trade.nextAction.kind === "send_manual" || trade.nextAction.kind === "wait" || trade.nextAction.kind === "confirm_sent";
  }
  function buildManualCreateCandidate(trade, locale = DEFAULT_EXTENSION_LOCALE) {
    if (!canManualCreateOffer(trade)) {
      return null;
    }
    const t = createExtensionT(locale);
    const reason = trade.nextAction.kind === "send_manual" ? "send_manual" : "waiting_no_offer";
    return {
      orderId: trade.orderId,
      orderShortId: trade.orderShortId,
      itemName: trade.item.marketHashName,
      assetId: trade.item.assetExternalId,
      buyerTradeUrl: trade.buyerTradeUrl.trim(),
      amountMinor: trade.amountMinor,
      floatValue: trade.item.floatValue,
      siteUrl: trade.siteUrl,
      reason,
      ctaLabel: t("manualCreate.buildOffer", { short: trade.orderShortId }),
      hint: reason === "send_manual" ? t("manualCreate.autoFailed") : t("manualCreate.canBuild")
    };
  }
  function listManualCreateCandidates(trades, locale = DEFAULT_EXTENSION_LOCALE) {
    return trades.map((trade) => buildManualCreateCandidate(trade, locale)).filter((entry) => entry !== null).sort((a, b) => {
      if (a.reason !== b.reason) {
        return a.reason === "send_manual" ? -1 : 1;
      }
      return a.orderShortId.localeCompare(b.orderShortId);
    });
  }

  // src/shared/manual-accept-assist.ts
  function steamTradeOfferUrl(offerId) {
    const id = offerId.trim();
    return `https://steamcommunity.com/tradeoffer/${encodeURIComponent(id)}/`;
  }
  function canShowManualAcceptAssist(trade) {
    if (trade.role !== "buyer") {
      return false;
    }
    if (trade.verificationStatus !== "verified") {
      return false;
    }
    if (!trade.offerId?.trim()) {
      return false;
    }
    if (trade.orderStatus === "DISPUTE") {
      return false;
    }
    if (trade.nextAction.kind === "report_issue" || trade.nextAction.kind === "platform_verifying") {
      return false;
    }
    return trade.orderStatus === "WAITING_TRADE" || trade.nextAction.kind === "accept_in_steam";
  }
  function buildManualAcceptListCta(trade, locale = DEFAULT_EXTENSION_LOCALE) {
    if (!canShowManualAcceptAssist(trade) || !trade.offerId) {
      return null;
    }
    const t = createExtensionT(locale);
    return {
      offerId: trade.offerId,
      orderShortId: trade.orderShortId,
      href: steamTradeOfferUrl(trade.offerId),
      label: t("acceptAssist.acceptSteam"),
      hint: t("acceptAssist.openVerified", { short: trade.orderShortId })
    };
  }

  // src/shared/trade-offer-card-context.ts
  function roleLabelForTrade(role, locale = DEFAULT_EXTENSION_LOCALE) {
    const t = createExtensionT(locale);
    return role === "buyer" ? t("cardContext.buy") : t("cardContext.sell");
  }
  function platformStatusForTrade(trade, locale = DEFAULT_EXTENSION_LOCALE) {
    const t = createExtensionT(locale);
    if (trade.verificationStatus === "mismatch" || trade.nextAction.kind === "report_issue" || trade.orderStatus === "DISPUTE") {
      return {
        label: trade.orderStatus === "DISPUTE" ? t("cardContext.dispute") : t("cardContext.mismatch"),
        tone: "error"
      };
    }
    switch (trade.nextAction.kind) {
      case "confirm_guard":
        return { label: t("cardContext.waitGuard"), tone: "warn" };
      case "accept_in_steam":
        return { label: t("cardContext.waitAccept"), tone: "ok" };
      case "send_manual":
        return { label: t("cardContext.sendManual"), tone: "warn" };
      case "confirm_sent":
        return { label: t("cardContext.confirmSent"), tone: "info" };
      case "confirm_received":
        return { label: t("cardContext.confirmReceived"), tone: "info" };
      case "platform_verifying":
        return { label: t("cardContext.platformCheck"), tone: "info" };
      case "completed":
        return { label: t("cardContext.completed"), tone: "ok" };
      default:
        break;
    }
    switch (trade.orderStatus) {
      case "WAITING_TRADE":
        if (trade.verificationStatus === "verified") {
          return {
            label: trade.role === "buyer" ? t("cardContext.offerReady") : t("cardContext.waitBuyer"),
            tone: "ok"
          };
        }
        if (trade.verificationStatus === "partial") {
          return { label: t("cardContext.checking"), tone: "warn" };
        }
        return { label: t("cardContext.waitTrade"), tone: "neutral" };
      case "TRADE_CONFIRMED":
        return { label: t("cardContext.tradeConfirmed"), tone: "ok" };
      case "SETTLEMENT_HOLD":
        return { label: t("cardContext.hold"), tone: "info" };
      case "COMPLETED":
        return { label: t("cardContext.completed"), tone: "ok" };
      case "CANCELLED":
      case "REFUNDED":
        return {
          label: trade.orderStatus === "REFUNDED" ? t("cardContext.failed") : t("cardContext.canceled"),
          tone: "neutral"
        };
      default:
        return {
          label: trade.nextAction.title?.trim() || trade.orderStatus || t("cardContext.inProgress"),
          tone: "neutral"
        };
    }
  }
  function buildOfferCardContext(trade, locale = DEFAULT_EXTENSION_LOCALE) {
    const roleLabel = roleLabelForTrade(trade.role, locale);
    const priceLabel = formatMoneyMinor(trade.amountMinor);
    const platform = platformStatusForTrade(trade, locale);
    const orderShortId = trade.orderShortId.trim() || trade.orderId.slice(0, 8);
    return {
      orderShortId,
      priceLabel,
      roleLabel,
      platformStatusLabel: platform.label,
      platformStatusTone: platform.tone,
      summaryLine: `#${orderShortId} \xB7 ${priceLabel} \xB7 ${roleLabel} \xB7 ${platform.label}`,
      itemName: trade.item.marketHashName,
      nextActionTitle: trade.nextAction.title
    };
  }

  // src/shared/extension-ops-health.ts
  var POLL_STALE_ERROR_MS = 5 * 6e4;
  var RATE_LIMIT_ACTIVE_WINDOW_MS = 2 * 6e4;

  // src/shared/offline-safe-mode.ts
  var SITE_LINK_STORAGE_KEY = "rip:siteLink";
  function defaultSiteLinkSnapshot(nowMs = Date.now()) {
    return {
      mode: "offline",
      safeMode: true,
      fromCache: false,
      cacheUpdatedAt: null,
      lastError: null,
      checkedAt: new Date(nowMs).toISOString()
    };
  }
  async function getStoredSiteLinkSnapshot() {
    try {
      if (typeof chrome === "undefined" || !chrome.storage?.local?.get) {
        return defaultSiteLinkSnapshot();
      }
      const stored = await chrome.storage.local.get(SITE_LINK_STORAGE_KEY);
      const raw = stored[SITE_LINK_STORAGE_KEY];
      if (!raw || typeof raw !== "object") {
        return defaultSiteLinkSnapshot();
      }
      const record = raw;
      const mode = record.mode === "live" || record.mode === "degraded" || record.mode === "offline" ? record.mode : "offline";
      return {
        mode,
        safeMode: mode !== "live",
        fromCache: Boolean(record.fromCache),
        cacheUpdatedAt: typeof record.cacheUpdatedAt === "string" ? record.cacheUpdatedAt : null,
        lastError: typeof record.lastError === "string" ? record.lastError : null,
        checkedAt: typeof record.checkedAt === "string" ? record.checkedAt : (/* @__PURE__ */ new Date()).toISOString()
      };
    } catch {
      return defaultSiteLinkSnapshot();
    }
  }

  // src/shared/active-trades-cache.ts
  var GUIDED_BUYER_ENABLED_KEY = "extensionGuidedBuyerEnabled";

  // src/shared/extension-flags.ts
  function isRemoteFlagOn(stored) {
    return stored !== false;
  }
  async function isExtensionGuidedBuyerEnabled() {
    try {
      const stored = await chrome.storage.local.get(GUIDED_BUYER_ENABLED_KEY);
      return isRemoteFlagOn(stored[GUIDED_BUYER_ENABLED_KEY]);
    } catch {
      return true;
    }
  }

  // src/shared/trade-offer-guided-gate.ts
  function guidedGateHeadline(status, role, locale = DEFAULT_EXTENSION_LOCALE) {
    const t = createExtensionT(locale);
    if (status === "mismatch") {
      return {
        title: t("guided.mismatchTitle"),
        subtitle: role === "buyer" ? t("guided.mismatchBuyer") : t("guided.mismatchSeller"),
        tone: "error"
      };
    }
    if (status === "verified") {
      return {
        title: t("guided.verifiedTitle"),
        subtitle: role === "buyer" ? t("guided.verifiedBuyer") : t("guided.verifiedSeller"),
        tone: "ok"
      };
    }
    if (status === "partial") {
      return {
        title: t("guided.partialTitle"),
        subtitle: t("guided.partialBody"),
        tone: "warn"
      };
    }
    return {
      title: t("guided.pendingTitle"),
      subtitle: t("guided.pendingBody"),
      tone: "pending"
    };
  }
  function normalize(value) {
    const trimmed = value?.trim() ?? "";
    return trimmed || "\u2014";
  }
  function compareTone(expected, observed, opts) {
    if (expected === "\u2014" && observed === "\u2014") {
      return "neutral";
    }
    if (observed === "\u2014") {
      return opts?.softWhenMissingObserved ? "warn" : "warn";
    }
    if (expected === "\u2014") {
      return "warn";
    }
    return expected === observed ? "ok" : "error";
  }
  function buildGuidedCompareRows(expected, observed, locale = DEFAULT_EXTENSION_LOCALE, partner) {
    const t = createExtensionT(locale);
    const expectedName = normalize(expected.marketHashName);
    const observedName = normalize(observed?.marketHashName);
    const expectedAsset = normalize(expected.assetExternalId);
    const observedAsset = normalize(observed?.assetId);
    const expectedFloat = normalize(expected.floatValue);
    const observedFloat = normalize(observed?.floatValue);
    const expectedWear = normalize(expected.wear);
    const observedWear = normalize(observed?.wear);
    const expectedPartner = normalize(
      partner?.expectedPartnerSteamId ?? null
    );
    const observedPartner = normalize(
      partner?.observedPartnerSteamId ?? observed?.partnerSteamId
    );
    const rows = [
      {
        key: "partner",
        label: t("guided.partner"),
        expected: expectedPartner,
        observed: observedPartner,
        tone: compareTone(expectedPartner, observedPartner, {
          softWhenMissingObserved: true
        })
      },
      {
        key: "name",
        label: t("guided.name"),
        expected: expectedName,
        observed: observedName,
        tone: compareTone(expectedName, observedName, {
          softWhenMissingObserved: true
        })
      },
      {
        key: "asset",
        label: t("guided.assetId"),
        expected: expectedAsset,
        observed: observedAsset,
        tone: compareTone(expectedAsset, observedAsset, {
          softWhenMissingObserved: true
        })
      }
    ];
    if (expectedWear !== "\u2014" || observedWear !== "\u2014") {
      rows.push({
        key: "wear",
        label: t("guided.wear"),
        expected: expectedWear,
        observed: observedWear,
        tone: compareTone(expectedWear, observedWear, {
          softWhenMissingObserved: true
        })
      });
    }
    if (expectedFloat !== "\u2014" || observedFloat !== "\u2014") {
      rows.push({
        key: "float",
        label: t("guided.float"),
        expected: expectedFloat,
        observed: observedFloat,
        tone: compareTone(expectedFloat, observedFloat, {
          softWhenMissingObserved: true
        })
      });
    }
    if (expected.stickers && expected.stickers.length > 0) {
      rows.push({
        key: "stickers",
        label: t("guided.stickers"),
        expected: expected.stickers.map(
          (sticker) => sticker.wearPercent != null ? `${sticker.name} (${sticker.wearPercent}%)` : sticker.name
        ).join(", "),
        observed: "\u2014",
        tone: "neutral"
      });
    }
    return rows;
  }

  // src/shared/steam-id64.ts
  function isRealSteamId64(steamId) {
    return typeof steamId === "string" && /^7656119\d{10}$/.test(steamId.trim());
  }
  function buildSteamProfileUrl(steamId64) {
    return `https://steamcommunity.com/profiles/${steamId64.trim()}`;
  }

  // src/shared/deal-shield.ts
  function normalizeId(value) {
    return value?.trim() ?? "";
  }
  function resolvePartnerMatch(params) {
    const expected = normalizeId(params.expectedSteamId);
    const observed = normalizeId(params.observedSteamId);
    if (!expected || !isRealSteamId64(expected)) {
      return "missing_expected";
    }
    if (!observed) {
      return "missing_observed";
    }
    if (!isRealSteamId64(observed)) {
      return "unknown";
    }
    return expected === observed ? "match" : "mismatch";
  }
  function applyPartnerObservation(trade, observedPartnerSteamId, locale = DEFAULT_EXTENSION_LOCALE) {
    const t = createExtensionT(locale);
    const match = resolvePartnerMatch({
      expectedSteamId: trade.counterparty.steamId,
      observedSteamId: observedPartnerSteamId
    });
    const withoutPartnerChecks = trade.checks.filter(
      (check) => check.key !== "partner_steam_match"
    );
    if (match === "mismatch") {
      return {
        ...trade,
        verificationStatus: "mismatch",
        checks: [
          ...withoutPartnerChecks,
          {
            key: "partner_steam_match",
            passed: false,
            label: t("shield.partnerMismatchCheck"),
            severity: "error"
          }
        ]
      };
    }
    if (match === "match") {
      return {
        ...trade,
        checks: [
          ...withoutPartnerChecks,
          {
            key: "partner_steam_match",
            passed: true,
            label: t("shield.partnerMatchCheck"),
            severity: "ok"
          }
        ]
      };
    }
    if (match === "missing_observed" && trade.verificationStatus === "verified") {
      return {
        ...trade,
        verificationStatus: "partial",
        checks: [
          ...withoutPartnerChecks,
          {
            key: "partner_steam_match",
            passed: false,
            label: t("shield.partnerMissingObservedCheck"),
            severity: "warn"
          }
        ]
      };
    }
    if (match === "missing_expected") {
      return {
        ...trade,
        verificationStatus: trade.verificationStatus === "verified" ? "partial" : trade.verificationStatus,
        checks: [
          ...withoutPartnerChecks,
          {
            key: "partner_steam_match",
            passed: false,
            label: t("shield.partnerMissingExpectedCheck"),
            severity: "warn"
          }
        ]
      };
    }
    return trade;
  }
  function buildItemCharacteristicLines(item, locale = DEFAULT_EXTENSION_LOCALE) {
    const t = createExtensionT(locale);
    const lines = [];
    const wear = item.wear?.trim();
    if (wear) {
      lines.push({ key: "wear", label: t("shield.wear"), value: wear });
    }
    const floatValue = item.floatValue?.trim();
    if (floatValue) {
      lines.push({ key: "float", label: t("shield.float"), value: floatValue });
    }
    const stickers = item.stickers?.filter((s) => s.name?.trim()) ?? [];
    if (stickers.length > 0) {
      lines.push({
        key: "stickers",
        label: t("shield.stickers"),
        value: stickers.map(
          (s) => s.wearPercent != null ? `${s.name} (${s.wearPercent}%)` : s.name
        ).join(", ")
      });
    }
    return lines;
  }
  function partnerMatchLabel(match, locale) {
    const t = createExtensionT(locale);
    switch (match) {
      case "match":
        return t("shield.partnerMatch");
      case "mismatch":
        return t("shield.partnerMismatch");
      case "missing_observed":
        return t("shield.partnerMissingObserved");
      case "missing_expected":
        return t("shield.partnerMissingExpected");
      default:
        return t("shield.partnerUnknown");
    }
  }
  function buildDealShieldModel(params) {
    const locale = params.locale ?? DEFAULT_EXTENSION_LOCALE;
    const t = createExtensionT(locale);
    const observedPartner = params.observed?.partnerSteamId ?? null;
    const trade = applyPartnerObservation(
      params.trade,
      observedPartner,
      locale
    );
    const match = resolvePartnerMatch({
      expectedSteamId: trade.counterparty.steamId,
      observedSteamId: observedPartner
    });
    const steamId = trade.counterparty.steamId?.trim() || null;
    const displayName = trade.counterparty.personaName?.trim() || trade.counterparty.username.trim() || t("shield.unknownPartner");
    const isPreSend = params.isPreSend === true || trade.role === "seller" && !trade.offerId;
    const compareRows = buildGuidedCompareRows(
      trade.item,
      params.observed ?? null,
      locale,
      {
        expectedPartnerSteamId: steamId,
        observedPartnerSteamId: observedPartner
      }
    );
    return {
      orderId: trade.orderId,
      orderShortId: trade.orderShortId,
      amountLabel: formatMoneyMinor(trade.amountMinor),
      role: trade.role,
      counterpartyRoleLabel: trade.role === "buyer" ? t("common.seller") : t("common.buyer"),
      headline: guidedGateHeadline(trade.verificationStatus, trade.role, locale),
      effectiveStatus: trade.verificationStatus,
      partner: {
        displayName,
        steamId,
        avatarUrl: trade.counterparty.avatarUrl?.trim() || null,
        profileUrl: steamId && isRealSteamId64(steamId) ? buildSteamProfileUrl(steamId) : null,
        match,
        matchLabel: partnerMatchLabel(match, locale)
      },
      item: {
        marketHashName: trade.item.marketHashName,
        iconUrl: trade.item.iconUrl,
        lines: buildItemCharacteristicLines(trade.item, locale),
        assetExternalId: trade.item.assetExternalId
      },
      compareRows,
      checks: trade.checks,
      blocksAccept: trade.verificationStatus === "mismatch" || match === "mismatch",
      isPreSend,
      siteUrl: trade.siteUrl,
      offerId: trade.offerId
    };
  }

  // src/shared/extension-context.ts
  function isExtensionContextValid() {
    try {
      return Boolean(
        typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.id === "string" && chrome.runtime.id.length > 0
      );
    } catch {
      return false;
    }
  }
  function isExtensionContextInvalidatedError(error) {
    if (!error) {
      return false;
    }
    const message = error instanceof Error ? error.message : typeof error === "string" ? error : String(error);
    return /Extension context invalidated/i.test(message);
  }
  async function withExtensionContext(run, fallback) {
    if (!isExtensionContextValid()) {
      return { ok: false, invalidated: true, value: fallback };
    }
    try {
      const value = await run();
      return { ok: true, value };
    } catch (error) {
      const invalidated = isExtensionContextInvalidatedError(error);
      if (invalidated || !isExtensionContextValid()) {
        return { ok: false, invalidated: true, value: fallback };
      }
      return { ok: false, invalidated: false, value: fallback };
    }
  }

  // src/shared/steam-offer-page-lifecycle.ts
  var ACCEPTED_RE = /trade\s*accepted|обмен\s*принят|предложение\s*принято|trade\s*completed|обмен\s*заверш/i;
  var INVALID_RE = /no\s*longer\s*valid|больше\s*не\s*действ|is\s*no\s*longer\s*available|это\s*предложение\s*обмена\s*больше\s*не\s*действ/i;
  var ERROR_BANNER_RE = /oh\s*nooooooes|some\s*kind\s*of\s*error\s*has\s*occurred/i;
  function detectSteamOfferPageLifecycle(root = document) {
    const doc = root;
    const hasSlots = typeof doc.querySelector === "function" && Boolean(
      doc.querySelector(
        "#trade_ygifts, #trade_themitems, .trade_item_box, #you_notready, #trade_confirmbtn"
      )
    );
    const text = collectSteamStatusText(root);
    if (text) {
      if (ACCEPTED_RE.test(text)) {
        return {
          lifecycle: "accepted",
          offerStatusHint: "accepted",
          reasonRu: "Steam \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442: \u043E\u0431\u043C\u0435\u043D \u043F\u0440\u0438\u043D\u044F\u0442"
        };
      }
      if (INVALID_RE.test(text) || ERROR_BANNER_RE.test(text)) {
        return {
          lifecycle: "invalid",
          offerStatusHint: null,
          reasonRu: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u0442\u044C \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0432 Steam"
        };
      }
    }
    if (hasSlots) {
      return { lifecycle: "active", offerStatusHint: null, reasonRu: null };
    }
    return { lifecycle: "unknown", offerStatusHint: null, reasonRu: null };
  }
  function collectSteamStatusText(root) {
    const chunks = [];
    const doc = root;
    if (typeof doc.querySelectorAll === "function") {
      const nodes = doc.querySelectorAll(
        ".error_ctn, .error_msg, #error_msg, .tradeoffer_items_banner, .trade_accepted, .pageheader, h2, .maincontent"
      );
      for (const node of Array.from(nodes).slice(0, 12)) {
        const value = node.textContent?.replace(/\s+/g, " ").trim();
        if (value) {
          chunks.push(value);
        }
      }
    }
    if (chunks.length === 0 && "body" in doc && doc.body) {
      chunks.push(
        (doc.body.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 2e3)
      );
    }
    return chunks.join("\n");
  }
  function isPostAcceptSteamLifecycle(lifecycle) {
    return lifecycle === "accepted";
  }

  // src/content/trade-offers-list-bridge.ts
  var TOOLBAR_ID = "rip-market-tradeoffers-toolbar";
  var DETAIL_ID = "rip-market-tradeoffers-detail";
  var STICKY_ID = "rip-market-anti-scam-sticky";
  var RELOAD_BANNER_ID = "rip-market-tradeoffers-reload";
  var BADGE_ATTR = "data-rip-offer-mark";
  var ACCEPT_ASSIST_ATTR = "data-rip-accept-assist";
  var CONTEXT_ATTR = "data-rip-offer-context";
  var FILTER_STORAGE_KEY = "rip:tradeoffers-filter-rip-only";
  var MAX_MANUAL_CREATE_PRIMARY = 1;
  var manualCreateStatus = { kind: "idle" };
  var listBridgeLocale = DEFAULT_EXTENSION_LOCALE;
  var guidedBuyerEnabled = true;
  var extensionContextInvalidated = false;
  var listPollTimer = null;
  var listObserver = null;
  var reportedListSteamPageKeys = /* @__PURE__ */ new Set();
  function maybeReportListSteamOfferPage(trade, card) {
    const offerId = trade.offerId?.trim();
    if (!offerId) {
      return;
    }
    const page = detectSteamOfferPageLifecycle(card);
    if (!isPostAcceptSteamLifecycle(page.lifecycle)) {
      return;
    }
    const key = `${trade.orderId}:${offerId}:${page.lifecycle}`;
    if (reportedListSteamPageKeys.has(key)) {
      return;
    }
    reportedListSteamPageKeys.add(key);
    void runtimeRequest({
      type: TRADE_VERIFICATION_RUNTIME.REPORT_STEAM_OFFER_PAGE,
      orderId: trade.orderId,
      offerId,
      lifecycle: page.lifecycle === "invalid" ? "invalid" : "accepted",
      idempotencyKey: `steam-page-list:${trade.orderId}:${offerId}:${page.lifecycle}`
    }).catch(() => void 0);
  }
  function escapeHtml(value) {
    return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }
  function isTradeOffersListPage(pathname) {
    return /\/tradeoffers\/?/i.test(pathname) && !/\/tradeoffer\/\d+/i.test(pathname);
  }
  async function runtimeRequest(message) {
    if (!isExtensionContextValid()) {
      extensionContextInvalidated = true;
      throw new Error("Extension context invalidated");
    }
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (error) {
      if (isExtensionContextInvalidatedError(error) || !isExtensionContextValid()) {
        extensionContextInvalidated = true;
      }
      throw error;
    }
  }
  async function loadActiveTrades() {
    const empty = { trades: [], siteSafeMode: true };
    const result = await withExtensionContext(async () => {
      const refreshed = await runtimeRequest({
        type: TRADE_VERIFICATION_RUNTIME.REFRESH_ACTIVE_TRADES
      });
      if (refreshed.ok && refreshed.trades) {
        return {
          trades: refreshed.trades,
          siteSafeMode: Boolean(refreshed.siteLink?.safeMode)
        };
      }
      const cached = await runtimeRequest({
        type: TRADE_VERIFICATION_RUNTIME.GET_ACTIVE_TRADES
      });
      const stored = await getStoredSiteLinkSnapshot();
      return {
        trades: cached.ok && cached.trades ? cached.trades : [],
        siteSafeMode: Boolean(cached.siteLink?.safeMode ?? stored.safeMode)
      };
    }, empty);
    if (!result.ok && result.invalidated) {
      extensionContextInvalidated = true;
    }
    return result.value;
  }
  function listTradeOfferElements() {
    const byClass = Array.from(document.querySelectorAll(".tradeoffer"));
    if (byClass.length > 0) {
      return byClass;
    }
    return Array.from(
      document.querySelectorAll('[id^="tradeofferid_"]')
    );
  }
  function badgeClass(kind) {
    switch (kind) {
      case "rip_verified":
        return "rip-badge rip-badge--verified";
      case "rip_pending":
        return "rip-badge rip-badge--pending";
      case "rip_mismatch":
        return "rip-badge rip-badge--mismatch";
      default:
        return "rip-badge rip-badge--foreign";
    }
  }
  function cardClass(kind) {
    switch (kind) {
      case "rip_verified":
        return "rip-card--verified";
      case "rip_pending":
        return "rip-card--pending";
      case "rip_mismatch":
        return "rip-card--mismatch";
      default:
        return "rip-card--foreign";
    }
  }
  function ensureBadgeStyles() {
    let style = document.getElementById(
      "rip-market-tradeoffers-style"
    );
    if (!style) {
      style = document.createElement("style");
      style.id = "rip-market-tradeoffers-style";
      document.documentElement.appendChild(style);
    }
    style.textContent = `
    :root {
      --rip-bg: #0b0d12;
      --rip-elevated-solid: #181c26;
      --rip-text: #f4f4f5;
      --rip-muted: #94a3b8;
      --rip-soft: #a8b0c0;
      --rip-link: #7dd3fc;
      --rip-border: rgba(255, 255, 255, 0.08);
      --rip-primary-from: #0284c7;
      --rip-primary-to: #2563eb;
      --rip-success: #86efac;
      --rip-success-bg: rgba(34, 197, 94, 0.16);
      --rip-warn: #fde047;
      --rip-warn-bg: rgba(234, 179, 8, 0.14);
      --rip-danger: #fecaca;
      --rip-danger-bg: rgba(239, 68, 68, 0.14);
      --rip-radius: 12px;
      --rip-radius-sm: 8px;
    }
    .rip-tradeoffers-toolbar {
      display: flex; flex-wrap: wrap; gap: 10px; align-items: center;
      margin: 12px 0 16px; padding: 12px 14px; border-radius: var(--rip-radius);
      background: var(--rip-elevated-solid); border: 1px solid var(--rip-border);
      color: var(--rip-text);
      font-family: Inter, system-ui, -apple-system, sans-serif; font-size: 13px;
    }
    .rip-tradeoffers-toolbar strong { color: var(--rip-link); }
    .rip-tradeoffers-toolbar label {
      display: inline-flex; align-items: center; gap: 8px; cursor: pointer;
      user-select: none;
    }
    .rip-tradeoffers-toolbar .count { color: var(--rip-muted); }
    .rip-tradeoffers-toolbar .manual-create {
      flex: 1 1 100%; display: flex; flex-direction: column; gap: 8px;
      margin-top: 4px; padding-top: 10px; border-top: 1px solid var(--rip-border);
    }
    .rip-tradeoffers-toolbar .manual-create-head {
      display: flex; flex-wrap: wrap; gap: 8px; align-items: baseline;
    }
    .rip-tradeoffers-toolbar .manual-create-head strong { color: var(--rip-text); }
    .rip-tradeoffers-toolbar .manual-create-actions {
      display: flex; flex-wrap: wrap; gap: 8px;
    }
    .rip-tradeoffers-toolbar button.manual-cta {
      border: 1px solid var(--rip-border); border-radius: var(--rip-radius-sm);
      padding: 8px 12px; background: rgba(15, 23, 42, 0.65);
      color: var(--rip-text); cursor: pointer; font: inherit; font-weight: 600;
    }
    .rip-tradeoffers-toolbar button.manual-cta--primary {
      border: none;
      background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
      color: #fff;
    }
    .rip-tradeoffers-toolbar button.manual-cta--ghost {
      background: transparent; color: var(--rip-muted); font-weight: 500;
    }
    .rip-tradeoffers-toolbar button.manual-cta:hover:not(:disabled) {
      filter: brightness(1.06);
    }
    .rip-tradeoffers-toolbar button.manual-cta:disabled {
      opacity: 0.65; cursor: wait;
    }
    .rip-tradeoffers-toolbar details.manual-create-more summary {
      cursor: pointer; font-size: 12px; color: var(--rip-muted); user-select: none;
      list-style: none;
    }
    .rip-tradeoffers-toolbar details.manual-create-more summary::-webkit-details-marker {
      display: none;
    }
    .rip-tradeoffers-toolbar .manual-status {
      color: var(--rip-soft); font-size: 12px; line-height: 1.4;
    }
    .rip-tradeoffers-toolbar .manual-status--error { color: var(--rip-danger); }
    .rip-tradeoffers-toolbar .manual-status--success { color: var(--rip-success); }
    .rip-tradeoffers-toolbar .manual-status a {
      color: var(--rip-link); margin-left: 6px;
    }
    .rip-badge {
      display: inline-flex; align-items: center; gap: 6px;
      margin: 8px 0 4px; padding: 4px 10px; border-radius: 999px;
      font-size: 12px; font-weight: 700; cursor: pointer; border: 1px solid transparent;
      font-family: Inter, system-ui, -apple-system, sans-serif;
    }
    .rip-badge svg { width: 12px; height: 12px; flex: 0 0 auto; }
    .rip-badge--verified {
      background: var(--rip-success-bg); color: var(--rip-success);
      border-color: rgba(134, 239, 172, 0.35);
    }
    .rip-badge--pending {
      background: rgba(56, 189, 248, 0.12); color: var(--rip-link);
      border-color: rgba(125, 211, 252, 0.35);
    }
    .rip-badge--mismatch {
      background: var(--rip-danger-bg); color: var(--rip-danger);
      border-color: rgba(248, 113, 113, 0.4);
    }
    .rip-badge--foreign {
      background: rgba(30, 41, 59, 0.55); color: var(--rip-muted);
      border-color: var(--rip-border);
    }
    .rip-badge-row {
      display: inline-flex; flex-wrap: wrap; gap: 8px; align-items: center;
      margin: 8px 0 4px;
    }
    .rip-badge-row .rip-badge { margin: 0; }
    a.rip-accept-assist {
      display: inline-flex; align-items: center; padding: 4px 12px; border-radius: 999px;
      font-size: 12px; font-weight: 700; text-decoration: none; cursor: pointer;
      font-family: Inter, system-ui, -apple-system, sans-serif;
      background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
      color: #fff; border: none;
    }
    a.rip-accept-assist:hover { filter: brightness(1.07); }
    .rip-card-context {
      display: flex; flex-wrap: wrap; gap: 6px 10px; align-items: center;
      margin: 0 0 8px; padding: 8px 10px; border-radius: var(--rip-radius-sm);
      background: var(--rip-elevated-solid); border: 1px solid var(--rip-border);
      font-family: Inter, system-ui, -apple-system, sans-serif; font-size: 12px;
      color: var(--rip-soft); cursor: pointer; max-width: 100%; width: 100%;
      text-align: left; appearance: none; -webkit-appearance: none;
    }
    .rip-card-context:hover { border-color: rgba(125, 211, 252, 0.35); }
    .rip-card-context .chip {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 2px 8px; border-radius: 999px; background: rgba(15, 23, 42, 0.72);
      border: 1px solid var(--rip-border); color: var(--rip-text); font-weight: 600;
      white-space: nowrap;
    }
    .rip-card-context .chip-order { color: var(--rip-link); border-color: rgba(125, 211, 252, 0.28); }
    .rip-card-context .chip-price { color: var(--rip-success); border-color: rgba(134, 239, 172, 0.28); }
    .rip-card-context .chip-role { color: var(--rip-soft); }
    .rip-card-context .chip-status { font-weight: 700; }
    .rip-card-context .chip-status.tone-ok {
      color: var(--rip-success); border-color: rgba(134, 239, 172, 0.35);
      background: var(--rip-success-bg);
    }
    .rip-card-context .chip-status.tone-warn {
      color: var(--rip-warn); border-color: rgba(253, 224, 71, 0.35);
      background: var(--rip-warn-bg);
    }
    .rip-card-context .chip-status.tone-error {
      color: var(--rip-danger); border-color: rgba(248, 113, 113, 0.4);
      background: var(--rip-danger-bg);
    }
    .rip-card-context .chip-status.tone-info {
      color: var(--rip-link); border-color: rgba(125, 211, 252, 0.28);
      background: rgba(56, 189, 248, 0.1);
    }
    .rip-card-context .chip-status.tone-neutral { color: var(--rip-muted); }
    .rip-card-context .item-line {
      flex: 1 1 100%; margin: 0; font-size: 11px; color: var(--rip-muted);
      line-height: 1.35; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    #${DETAIL_ID} a.rip-detail-primary {
      display: block; text-align: center; text-decoration: none; margin-top: 10px;
      background: linear-gradient(135deg, var(--rip-primary-from), var(--rip-primary-to));
      color: #fff; border-radius: var(--rip-radius-sm); padding: 10px 12px; font-weight: 700;
    }
    #${DETAIL_ID} a.rip-detail-secondary {
      display: block; text-align: center; text-decoration: none; margin-top: 8px;
      background: transparent; color: var(--rip-link);
      border: 1px solid var(--rip-border); border-radius: var(--rip-radius-sm);
      padding: 8px 12px; font-weight: 600;
    }
    #${DETAIL_ID} a.rip-detail-inline-link {
      display: inline; margin: 0; padding: 0; border: none; background: none;
      color: var(--rip-link); font-size: 12px; font-weight: 600;
    }
    #${DETAIL_ID} .context-grid {
      display: grid; grid-template-columns: auto 1fr; gap: 4px 10px;
      margin: 0 0 10px; font-size: 12px;
    }
    #${DETAIL_ID} .context-grid dt { color: var(--rip-muted); margin: 0; }
    #${DETAIL_ID} .context-grid dd { margin: 0; color: var(--rip-text); font-weight: 600; }
    .tradeoffer.rip-card--verified,
    [id^="tradeofferid_"].rip-card--verified {
      outline: 2px solid rgba(134, 239, 172, 0.55); outline-offset: 2px;
    }
    .tradeoffer.rip-card--pending,
    [id^="tradeofferid_"].rip-card--pending {
      outline: 2px solid rgba(125, 211, 252, 0.45); outline-offset: 2px;
    }
    .tradeoffer.rip-card--mismatch,
    [id^="tradeofferid_"].rip-card--mismatch {
      outline: 2px solid rgba(248, 113, 113, 0.55); outline-offset: 2px;
    }
    .tradeoffer.rip-card--foreign,
    [id^="tradeofferid_"].rip-card--foreign {
      outline: 1px solid var(--rip-border); outline-offset: 1px;
    }
    .tradeoffer.rip-card--hidden,
    [id^="tradeofferid_"].rip-card--hidden { display: none !important; }
    #${DETAIL_ID} {
      position: fixed; z-index: 2147483646; width: min(340px, calc(100vw - 24px));
      border-radius: var(--rip-radius); padding: 14px; background: var(--rip-elevated-solid);
      color: var(--rip-text); border: 1px solid var(--rip-border);
      box-shadow: 0 16px 48px rgba(0,0,0,.55);
      font-family: Inter, system-ui, -apple-system, sans-serif; font-size: 13px;
    }
    #${DETAIL_ID} h2 { margin: 0 0 8px; font-size: 14px; color: var(--rip-text); }
    #${DETAIL_ID} p { margin: 0 0 8px; color: var(--rip-soft); line-height: 1.4; }
    #${DETAIL_ID} .meta { color: var(--rip-muted); font-size: 12px; }
    #${DETAIL_ID} .rip-detail-hero {
      display: flex; gap: 10px; align-items: center; margin: 0 0 10px;
      padding: 8px; border-radius: var(--rip-radius-sm);
      background: rgba(15, 23, 42, 0.55); border: 1px solid var(--rip-border);
    }
    #${DETAIL_ID} .rip-detail-avatar {
      width: 40px; height: 40px; border-radius: 50%; object-fit: cover; flex-shrink: 0;
    }
    #${DETAIL_ID} .rip-detail-avatar-fallback {
      width: 40px; height: 40px; border-radius: 50%; display: grid; place-items: center;
      background: var(--rip-bg); border: 1px solid var(--rip-border);
      color: var(--rip-muted); font-weight: 700; flex-shrink: 0;
    }
    #${DETAIL_ID} button.close {
      width: 100%; margin-top: 8px; border: 1px solid var(--rip-border); border-radius: var(--rip-radius-sm);
      padding: 8px 12px; background: transparent; color: var(--rip-muted); cursor: pointer;
      font-family: inherit; font-size: 12px;
    }
    #${DETAIL_ID} button.close:hover { color: var(--rip-text); }
    #${STICKY_ID} {
      position: fixed; left: 12px; right: 12px; bottom: 12px; z-index: 2147483645;
      max-width: 520px; margin: 0 auto; padding: 10px 14px; border-radius: var(--rip-radius-sm);
      background: var(--rip-warn-bg); color: var(--rip-warn);
      border: 1px solid rgba(253, 224, 71, 0.35);
      font-family: Inter, system-ui, -apple-system, sans-serif; font-size: 12px; line-height: 1.4;
      box-shadow: 0 10px 28px rgba(0,0,0,.45); pointer-events: none;
    }
    .rip-tradeoffers-reload {
      display: flex; flex-wrap: wrap; gap: 10px; align-items: center;
      margin: 12px 0 16px; padding: 12px 14px; border-radius: var(--rip-radius);
      background: var(--rip-warn-bg); border: 1px solid rgba(253, 224, 71, 0.35);
      color: #f5e6b8;
      font-family: Inter, system-ui, -apple-system, sans-serif; font-size: 13px;
    }
    .rip-tradeoffers-reload strong { color: var(--rip-warn); }
    .rip-tradeoffers-reload button {
      border: 1px solid rgba(253, 224, 71, 0.4); border-radius: var(--rip-radius-sm);
      padding: 8px 12px; background: rgba(15, 23, 42, 0.72); color: var(--rip-text);
      cursor: pointer; font: inherit; font-weight: 600;
    }
  `;
  }
  function ensureStickyHint() {
    ensureBadgeStyles();
    let sticky = document.getElementById(STICKY_ID);
    if (!sticky) {
      sticky = document.createElement("div");
      sticky.id = STICKY_ID;
      document.documentElement.appendChild(sticky);
    }
    sticky.textContent = antiScamStickyShort();
  }
  function shieldSvg() {
    return `<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M8 1.2 2.5 3.4v4.2c0 3.4 2.3 5.9 5.5 7 3.2-1.1 5.5-3.6 5.5-7V3.4L8 1.2Zm0 1.7 4 1.4v3.3c0 2.4-1.5 4.3-4 5.2-2.5-.9-4-2.8-4-5.2V4.3l4-1.4Z"/></svg>`;
  }
  function findBadgeHost(card) {
    return card.querySelector(".tradeoffer_header") ?? card.querySelector(".tradeoffer_items_banner") ?? card;
  }
  function upsertBadge(card, mark) {
    const host = findBadgeHost(card);
    let row = host.querySelector(".rip-badge-row");
    if (!row) {
      row = document.createElement("div");
      row.className = "rip-badge-row";
      host.prepend(row);
    }
    let badge = row.querySelector(`button[${BADGE_ATTR}]`);
    if (!badge) {
      badge = document.createElement("button");
      badge.type = "button";
      badge.setAttribute(BADGE_ATTR, "1");
      row.prepend(badge);
    }
    badge.className = badgeClass(mark.kind);
    badge.dataset.kind = mark.kind;
    badge.innerHTML = `${shieldSvg()}<span>${escapeHtml(mark.label)}</span>`;
    badge.title = mark.kind === "not_ours" ? "\u041D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0439 \u0441\u0434\u0435\u043B\u043A\u0438 R.I.P Market \u0441 \u044D\u0442\u0438\u043C offerId" : "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0434\u0435\u0442\u0430\u043B\u0438 \u0441\u0434\u0435\u043B\u043A\u0438 R.I.P Market";
    return badge;
  }
  function upsertAcceptAssist(card, mark, locale) {
    const host = findBadgeHost(card);
    const row = host.querySelector(".rip-badge-row");
    const existing = row?.querySelector(
      `a[${ACCEPT_ASSIST_ATTR}]`
    );
    if (!guidedBuyerEnabled) {
      existing?.remove();
      return;
    }
    const cta = mark.trade ? buildManualAcceptListCta(mark.trade, locale) : null;
    if (!cta || !row) {
      existing?.remove();
      return;
    }
    let link = existing;
    if (!link) {
      link = document.createElement("a");
      link.setAttribute(ACCEPT_ASSIST_ATTR, "1");
      link.className = "rip-accept-assist";
      row.appendChild(link);
    }
    link.href = cta.href;
    link.removeAttribute("target");
    link.removeAttribute("rel");
    link.textContent = cta.label;
    link.title = cta.hint;
    link.onclick = (event) => {
      event.stopPropagation();
    };
  }
  function upsertCardContext(card, mark, locale) {
    const host = findBadgeHost(card);
    const existing = host.querySelector(`[${CONTEXT_ATTR}]`);
    if (!mark.trade || !isRipOfferMark(mark.kind)) {
      existing?.remove();
      return;
    }
    const ctx = buildOfferCardContext(mark.trade, locale);
    let strip = existing;
    if (!strip) {
      strip = document.createElement("button");
      strip.type = "button";
      strip.setAttribute(CONTEXT_ATTR, "1");
      strip.className = "rip-card-context";
      const row = host.querySelector(".rip-badge-row");
      if (row?.nextSibling) {
        host.insertBefore(strip, row.nextSibling);
      } else if (row) {
        row.after(strip);
      } else {
        host.prepend(strip);
      }
    }
    strip.title = `${ctx.summaryLine} \xB7 ${ctx.nextActionTitle}`;
    strip.innerHTML = `
    <span class="chip chip-order">#${escapeHtml(ctx.orderShortId)}</span>
    <span class="chip chip-price">${escapeHtml(ctx.priceLabel)}</span>
    <span class="chip chip-role">${escapeHtml(ctx.roleLabel)}</span>
    <span class="chip chip-status tone-${escapeHtml(ctx.platformStatusTone)}">${escapeHtml(ctx.platformStatusLabel)}</span>
    <p class="item-line">${escapeHtml(ctx.itemName)}</p>
  `;
    strip.onclick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      showDetail(mark, strip);
    };
  }
  function clearCardMarkClasses(card) {
    card.classList.remove(
      "rip-card--verified",
      "rip-card--pending",
      "rip-card--mismatch",
      "rip-card--foreign",
      "rip-card--hidden"
    );
  }
  function applyCardMark(card, mark, ripOnly, locale) {
    clearCardMarkClasses(card);
    card.classList.add(cardClass(mark.kind));
    if (ripOnly && !isRipOfferMark(mark.kind)) {
      card.classList.add("rip-card--hidden");
    }
    const badge = upsertBadge(card, mark);
    upsertAcceptAssist(card, mark, locale);
    upsertCardContext(card, mark, locale);
    badge.onclick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      showDetail(mark, badge);
    };
  }
  function closeDetail() {
    document.getElementById(DETAIL_ID)?.remove();
  }
  function showDetail(mark, anchor) {
    closeDetail();
    const panel = document.createElement("div");
    panel.id = DETAIL_ID;
    const trade = mark.trade;
    if (!trade) {
      panel.innerHTML = `
      <h2>\u041D\u0435 \u043D\u0430\u0448\u0430 \u0441\u0434\u0435\u043B\u043A\u0430</h2>
      <p>\u041E\u0444\u0444\u0435\u0440 \u043D\u0435 \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D \u043A \u0437\u0430\u043A\u0430\u0437\u0443 R.I.P Market. \u041D\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0439\u0442\u0435 \u043E\u0431\u043C\u0435\u043D\u044B \u0438\u0437 \u0447\u0430\u0442\u0430 \u0438\u043B\u0438 \u043E\u0442 \u043D\u0435\u0437\u043D\u0430\u043A\u043E\u043C\u0446\u0435\u0432.</p>
      <button class="close" type="button">\u0417\u0430\u043A\u0440\u044B\u0442\u044C</button>
    `;
    } else {
      const shield = buildDealShieldModel({
        trade,
        locale: listBridgeLocale
      });
      const t = createExtensionT(listBridgeLocale);
      const ctx = buildOfferCardContext(trade, listBridgeLocale);
      const acceptCta = guidedBuyerEnabled ? buildManualAcceptListCta(trade, listBridgeLocale) : null;
      const avatar = shield.partner.avatarUrl ? `<img class="rip-detail-avatar" src="${escapeHtml(shield.partner.avatarUrl)}" alt="" />` : `<span class="rip-detail-avatar-fallback">${escapeHtml(shield.partner.displayName.slice(0, 1).toUpperCase())}</span>`;
      const profile = shield.partner.steamId && isRealSteamId64(shield.partner.steamId) ? `<a class="rip-detail-inline-link" href="${escapeHtml(buildSteamProfileUrl(shield.partner.steamId))}" target="_blank" rel="noreferrer">${escapeHtml(t("shield.openProfile"))}</a>` : "";
      const itemLines = shield.item.lines.length > 0 ? `<p class="meta">${escapeHtml(
        shield.item.lines.map((l) => `${l.label}: ${l.value}`).join(" \xB7 ")
      )}</p>` : "";
      panel.innerHTML = `
      <h2>${escapeHtml(mark.label)}</h2>
      <div class="rip-detail-hero">
        ${avatar}
        <div>
          <p class="meta">${escapeHtml(shield.counterpartyRoleLabel)}</p>
          <p><strong>${escapeHtml(shield.partner.displayName)}</strong></p>
          <p class="meta">SteamID64: <code>${escapeHtml(shield.partner.steamId || "\u2014")}</code></p>
          ${profile}
        </div>
      </div>
      <p><strong>${escapeHtml(ctx.itemName)}</strong></p>
      ${itemLines}
      <dl class="context-grid">
        <dt>\u0417\u0430\u043A\u0430\u0437</dt><dd>#${escapeHtml(ctx.orderShortId)}</dd>
        <dt>\u0426\u0435\u043D\u0430</dt><dd>${escapeHtml(ctx.priceLabel)}</dd>
        <dt>\u0420\u043E\u043B\u044C</dt><dd>${escapeHtml(ctx.roleLabel)}</dd>
        <dt>\u0421\u0442\u0430\u0442\u0443\u0441</dt><dd>${escapeHtml(ctx.platformStatusLabel)}</dd>
        <dt>\u0414\u0430\u043B\u044C\u0448\u0435</dt><dd>${escapeHtml(ctx.nextActionTitle)}</dd>
      </dl>
      ${acceptCta ? `<a class="rip-detail-primary" href="${escapeHtml(acceptCta.href)}">${escapeHtml(acceptCta.label)}</a>
      <a class="rip-detail-secondary" href="${escapeHtml(trade.siteUrl)}" target="_blank" rel="noreferrer">${escapeHtml(t("common.openOrder"))}</a>` : `<a class="rip-detail-primary" href="${escapeHtml(trade.siteUrl)}" target="_blank" rel="noreferrer">${escapeHtml(t("common.openOrder"))}</a>`}
      <button class="close" type="button">\u0417\u0430\u043A\u0440\u044B\u0442\u044C</button>
    `;
    }
    document.documentElement.appendChild(panel);
    const rect = anchor.getBoundingClientRect();
    const top = Math.min(window.innerHeight - 24, Math.max(12, rect.bottom + 8));
    const left = Math.min(window.innerWidth - 24, Math.max(12, rect.left));
    panel.style.top = `${top}px`;
    panel.style.left = `${left}px`;
    panel.querySelector("button.close")?.addEventListener("click", () => closeDetail());
  }
  async function getRipOnlyFilter() {
    const result = await withExtensionContext(async () => {
      const stored = await chrome.storage.local.get(FILTER_STORAGE_KEY);
      return stored[FILTER_STORAGE_KEY] === true;
    }, false);
    if (!result.ok && result.invalidated) {
      extensionContextInvalidated = true;
    }
    return result.value;
  }
  async function setRipOnlyFilter(value) {
    const result = await withExtensionContext(async () => {
      await chrome.storage.local.set({ [FILTER_STORAGE_KEY]: value });
    }, void 0);
    if (!result.ok && result.invalidated) {
      extensionContextInvalidated = true;
    }
  }
  function stopListBridgeLoops() {
    if (listPollTimer !== null) {
      window.clearInterval(listPollTimer);
      listPollTimer = null;
    }
    listObserver?.disconnect();
    listObserver = null;
  }
  function showExtensionReloadBanner() {
    ensureBadgeStyles();
    stopListBridgeLoops();
    document.getElementById(TOOLBAR_ID)?.remove();
    document.getElementById(DETAIL_ID)?.remove();
    document.getElementById(STICKY_ID)?.remove();
    let banner = document.getElementById(RELOAD_BANNER_ID);
    if (!banner) {
      banner = document.createElement("div");
      banner.id = RELOAD_BANNER_ID;
      banner.className = "rip-tradeoffers-reload";
      const mount2 = document.querySelector(".profile_leftcol") ?? document.querySelector("#mainContents") ?? document.querySelector(".responsive_page_template_content") ?? document.body;
      mount2.prepend(banner);
    }
    banner.innerHTML = `
    <strong>R.I.P Market \u043E\u0431\u043D\u043E\u0432\u0438\u043B\u0441\u044F</strong>
    <span>\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u044D\u0442\u0443 \u0432\u043A\u043B\u0430\u0434\u043A\u0443 Steam \u2014 \u0438\u043D\u0430\u0447\u0435 \u0431\u0435\u0439\u0434\u0436\u0438 \u0441\u0434\u0435\u043B\u043E\u043A \u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u044E\u0442.</span>
    <button type="button" data-rip-reload-tab>\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443</button>
  `;
    banner.querySelector("[data-rip-reload-tab]")?.addEventListener("click", () => {
      window.location.reload();
    });
  }
  function renderManualCreateStatusHtml() {
    if (manualCreateStatus.kind === "busy") {
      return `<p class="manual-status">\u0421\u043E\u0431\u0438\u0440\u0430\u0435\u043C \u043E\u0444\u0444\u0435\u0440\u2026 Steam \u043E\u0442\u043A\u0440\u043E\u0435\u0442 Trade URL \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F \u0438 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u0438\u0442 \u043F\u0440\u0435\u0434\u043C\u0435\u0442. Guard \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432\u0440\u0443\u0447\u043D\u0443\u044E.</p>`;
    }
    if (manualCreateStatus.kind === "error") {
      return `<p class="manual-status manual-status--error">${escapeHtml(manualCreateStatus.message)}</p>`;
    }
    if (manualCreateStatus.kind === "success") {
      const guard = manualCreateStatus.confirmPending ? " \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0432 Steam Mobile (Guard)." : "";
      const link = manualCreateStatus.siteUrl ? ` <a href="${escapeHtml(manualCreateStatus.siteUrl)}" target="_blank" rel="noreferrer">\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437</a>` : "";
      return `<p class="manual-status manual-status--success">\u041E\u0444\u0444\u0435\u0440 ${escapeHtml(manualCreateStatus.offerId)} \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D.${guard}${link}</p>`;
    }
    return "";
  }
  function renderManualCreateButtonHtml(entry, variant) {
    const busy = manualCreateStatus.kind === "busy" && manualCreateStatus.orderId === entry.orderId;
    const disabled = manualCreateStatus.kind === "busy";
    const cls = variant === "primary" ? "manual-cta manual-cta--primary" : "manual-cta manual-cta--ghost";
    return `<button type="button" class="${cls}" data-priority="${escapeHtml(entry.reason)}" data-order-id="${escapeHtml(entry.orderId)}" title="${escapeHtml(entry.hint)}" ${disabled ? "disabled" : ""}>${busy ? "\u0421\u043E\u0431\u0438\u0440\u0430\u0435\u043C\u2026" : escapeHtml(entry.ctaLabel)}</button>`;
  }
  function renderManualCreateSectionHtml(candidates) {
    if (candidates.length === 0 && manualCreateStatus.kind === "idle") {
      return "";
    }
    const primary = candidates.slice(0, MAX_MANUAL_CREATE_PRIMARY);
    const extras = candidates.slice(MAX_MANUAL_CREATE_PRIMARY);
    const primaryBlock = primary.length === 0 ? "" : `<div class="manual-create-actions">${primary.map((entry) => renderManualCreateButtonHtml(entry, "primary")).join("")}</div>`;
    const extrasBlock = extras.length === 0 ? "" : `<details class="manual-create-more"><summary>\u0415\u0449\u0451 \u0437\u0430\u043A\u0430\u0437\u044B (${extras.length})</summary><div class="manual-create-actions">${extras.map((entry) => renderManualCreateButtonHtml(entry, "ghost")).join("")}</div></details>`;
    const buttons = primaryBlock || extrasBlock ? `${primaryBlock}${extrasBlock}` : "";
    return `
    <div class="manual-create" data-manual-create>
      <div class="manual-create-head">
        <strong>\u0421\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440</strong>
        <span class="count">\u0435\u0441\u043B\u0438 \u0430\u0432\u0442\u043E \u043D\u0435 \u0441\u043C\u043E\u0433 \u2014 \u0442\u043E\u0442 \u0436\u0435 autofill, \u0447\u0442\u043E \u0438 \u043F\u0440\u0438 \u043F\u043E\u043A\u0443\u043F\u043A\u0435</span>
      </div>
      ${buttons}
      ${renderManualCreateStatusHtml()}
    </div>
  `;
  }
  async function launchManualCreate(orderId) {
    if (manualCreateStatus.kind === "busy") {
      return;
    }
    manualCreateStatus = { kind: "busy", orderId };
    void markAllOffers();
    try {
      const result = await runtimeRequest({
        type: TRADE_VERIFICATION_RUNTIME.MANUAL_CREATE_OFFER,
        orderId
      });
      if (!result.ok || !result.offerId) {
        manualCreateStatus = {
          kind: "error",
          message: result.error?.trim() || "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440"
        };
      } else {
        manualCreateStatus = {
          kind: "success",
          orderId,
          offerId: result.offerId,
          confirmPending: Boolean(result.confirmPending),
          siteUrl: result.siteUrl
        };
      }
    } catch (error) {
      if (isExtensionContextInvalidatedError(error) || !isExtensionContextValid()) {
        extensionContextInvalidated = true;
        showExtensionReloadBanner();
        return;
      }
      manualCreateStatus = {
        kind: "error",
        message: error instanceof Error ? error.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u043E\u0444\u0444\u0435\u0440"
      };
    }
    await markAllOffers();
  }
  function ensureToolbar(stats) {
    let toolbar = document.getElementById(TOOLBAR_ID);
    if (!toolbar) {
      toolbar = document.createElement("div");
      toolbar.id = TOOLBAR_ID;
      toolbar.className = "rip-tradeoffers-toolbar";
      const mount2 = document.querySelector(".profile_leftcol") ?? document.querySelector("#mainContents") ?? document.querySelector(".responsive_page_template_content") ?? document.body;
      mount2.prepend(toolbar);
    }
    toolbar.innerHTML = `
    <strong>R.I.P Market</strong>
    <span class="count">\u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435: ${stats.rip}/${stats.total} \u043D\u0430\u0448\u0438\u0445${stats.mismatch > 0 ? ` \xB7 \u043F\u043E\u0434\u043E\u0437\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445: ${stats.mismatch}` : ""}</span>
    <label>
      <input type="checkbox" data-rip-filter />
      \u0422\u043E\u043B\u044C\u043A\u043E \u0441\u0434\u0435\u043B\u043A\u0438 R.I.P
    </label>
    <span class="count" data-anti-scam-hint>${escapeHtml(antiScamStickyShort())}</span>
    ${renderManualCreateSectionHtml(stats.candidates)}
  `;
    return toolbar;
  }
  async function markAllOffers() {
    if (extensionContextInvalidated || !isExtensionContextValid()) {
      extensionContextInvalidated = true;
      showExtensionReloadBanner();
      return;
    }
    try {
      ensureBadgeStyles();
      ensureStickyHint();
      const locale = await getStoredExtensionLocale();
      listBridgeLocale = locale;
      guidedBuyerEnabled = await isExtensionGuidedBuyerEnabled();
      if (extensionContextInvalidated || !isExtensionContextValid()) {
        showExtensionReloadBanner();
        return;
      }
      const loaded = await loadActiveTrades();
      if (extensionContextInvalidated) {
        showExtensionReloadBanner();
        return;
      }
      const trades = loaded.trades;
      const candidates = loaded.siteSafeMode ? [] : listManualCreateCandidates(trades, locale);
      const ripOnly = await getRipOnlyFilter();
      if (extensionContextInvalidated) {
        showExtensionReloadBanner();
        return;
      }
      const cards = listTradeOfferElements();
      let rip = 0;
      let mismatch = 0;
      for (const card of cards) {
        const offerId = parseTradeOfferIdFromElementId(card.id);
        if (!offerId) {
          continue;
        }
        const mark = classifyOfferMark(offerId, trades);
        if (mark.trade) {
          maybeReportListSteamOfferPage(mark.trade, card);
        }
        if (isRipOfferMark(mark.kind)) {
          rip += 1;
        }
        if (mark.kind === "rip_mismatch") {
          mismatch += 1;
        }
        applyCardMark(card, mark, ripOnly, locale);
      }
      document.getElementById(RELOAD_BANNER_ID)?.remove();
      const toolbar = ensureToolbar({
        total: cards.length,
        rip,
        mismatch,
        candidates
      });
      const checkbox = toolbar.querySelector("input[data-rip-filter]");
      if (checkbox) {
        checkbox.checked = ripOnly;
        checkbox.onchange = () => {
          void setRipOnlyFilter(checkbox.checked).then(() => markAllOffers());
        };
      }
      toolbar.querySelectorAll("button.manual-cta").forEach((button) => {
        button.onclick = (event) => {
          event.preventDefault();
          event.stopPropagation();
          const orderId = button.dataset.orderId?.trim();
          if (orderId) {
            void launchManualCreate(orderId);
          }
        };
      });
    } catch (error) {
      if (isExtensionContextInvalidatedError(error) || !isExtensionContextValid()) {
        extensionContextInvalidated = true;
        showExtensionReloadBanner();
        return;
      }
      throw error;
    }
  }
  function watchListDom() {
    const root = document.querySelector(".profile_leftcol") ?? document.querySelector("#mainContents") ?? document.body;
    let timer = null;
    listObserver?.disconnect();
    listObserver = new MutationObserver(() => {
      if (extensionContextInvalidated) {
        listObserver?.disconnect();
        return;
      }
      if (timer !== null) {
        window.clearTimeout(timer);
      }
      timer = window.setTimeout(() => {
        void markAllOffers();
      }, 250);
    });
    listObserver.observe(root, { childList: true, subtree: true });
  }
  async function mount() {
    if (!isTradeOffersListPage(window.location.pathname)) {
      return;
    }
    await markAllOffers();
    if (extensionContextInvalidated) {
      return;
    }
    watchListDom();
    listPollTimer = window.setInterval(() => {
      void markAllOffers();
    }, 3e4);
  }
  void mount().catch((error) => {
    if (isExtensionContextInvalidatedError(error) || !isExtensionContextValid()) {
      extensionContextInvalidated = true;
      showExtensionReloadBanner();
      return;
    }
    console.warn("[rip-market] tradeoffers list bridge failed", error);
  });
})();
//# sourceMappingURL=trade-offers-list-bridge.js.map
