"use strict";
(() => {
  // src/shared/steam-receipt-context.ts
  var RECEIPT_CONTEXT_KEY = "rip-market:receipt-context:v1";
  function readReceiptContext(raw, referrer, now) {
    try {
      const value = JSON.parse(raw ?? "null");
      if (!value || !/^[a-f0-9-]{36}$/.test(value.orderId) || !/^[1-9][0-9]{0,19}$/.test(value.offerId)) return null;
      if (!Number.isFinite(value.savedAt) || now < value.savedAt || now - value.savedAt > 30 * 6e4) return null;
      const from = new URL(referrer);
      if (from.origin !== "https://steamcommunity.com" || from.pathname !== `/tradeoffer/${value.offerId}/`) return null;
      return value;
    } catch {
      return null;
    }
  }

  // src/shared/trade-verification-runtime.ts
  var TRADE_VERIFICATION_RUNTIME = {
    GET_ACTIVE_TRADES: "RIP_MARKET_GET_ACTIVE_TRADES",
    VERIFY_TRADE: "RIP_MARKET_VERIFY_TRADE",
    ACK_TRADE: "RIP_MARKET_ACK_TRADE",
    REFRESH_ACTIVE_TRADES: "RIP_MARKET_REFRESH_ACTIVE_TRADES",
    REPORT_STEAM_OFFER_PAGE: "RIP_MARKET_REPORT_STEAM_OFFER_PAGE",
    RESOLVE_ASSET_FLOAT: "RIP_MARKET_RESOLVE_ASSET_FLOAT",
    GET_INVENTORY_PLATFORM_STATUS: "RIP_MARKET_GET_INVENTORY_PLATFORM_STATUS",
    GET_INVENTORY_PRICE_HINTS: "RIP_MARKET_GET_INVENTORY_PRICE_HINTS",
    /** Load CS2 enrichment facts from the Steam inventory tab MAIN world. */
    GET_INVENTORY_PAGE_FACTS: "RIP_MARKET_GET_INVENTORY_PAGE_FACTS",
    BROWSER_ASSIST_INVENTORY_SYNC: "RIP_MARKET_BROWSER_ASSIST_INVENTORY_SYNC",
    CREATE_INVENTORY_LOT: "RIP_MARKET_CREATE_INVENTORY_LOT",
    CREATE_INVENTORY_LOTS_BATCH: "RIP_MARKET_CREATE_INVENTORY_LOTS_BATCH",
    UPDATE_INVENTORY_LOT_PRICE: "RIP_MARKET_UPDATE_INVENTORY_LOT_PRICE",
    CANCEL_INVENTORY_LOT: "RIP_MARKET_CANCEL_INVENTORY_LOT",
    GET_SELLER_ONBOARDING_STATUS: "RIP_MARKET_GET_SELLER_ONBOARDING_STATUS",
    MANUAL_CREATE_OFFER: "RIP_MARKET_MANUAL_CREATE_OFFER"
  };

  // src/content/steam-receipt-bridge.ts
  async function reportReceipt() {
    if (!/^\/trade\/[1-9][0-9]{0,19}\/receipt\/?$/.test(location.pathname)) return;
    const completed = Array.from(document.querySelectorAll("h1")).some(
      (h) => /^(обмен заверш[её]н|trade completed)$/i.test(h.textContent?.trim() ?? "")
    );
    if (!completed) return;
    let context;
    try {
      context = readReceiptContext(sessionStorage.getItem(RECEIPT_CONTEXT_KEY), document.referrer, Date.now());
    } catch {
      return;
    }
    if (!context) return;
    const result = await chrome.runtime.sendMessage({
      type: TRADE_VERIFICATION_RUNTIME.REPORT_STEAM_OFFER_PAGE,
      orderId: context.orderId,
      offerId: context.offerId,
      lifecycle: "accepted",
      idempotencyKey: `steam-page:${context.orderId}:${context.offerId}:accepted`
    });
    const panel = document.createElement("p");
    panel.textContent = result?.ok ? "R.I.P Market: Steam \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B \u043E\u0431\u043C\u0435\u043D. \u041F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0443; \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u043E\u0431\u043C\u0435\u043D \u043D\u0435 \u043D\u0443\u0436\u043D\u043E. " : "R.I.P Market: Steam \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B \u043E\u0431\u043C\u0435\u043D. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043A\u0430\u0437 \u0434\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0441\u0442\u0430\u0442\u0443\u0441\u0430. ";
    const link = document.createElement("a");
    link.href = `https://p2pcs.ru/orders/${context.orderId}`;
    link.textContent = "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043A\u0430\u0437";
    panel.append(link);
    (document.querySelector("#mainContent") ?? document.body).append(panel);
  }
  void reportReceipt().catch(() => void 0);
})();
//# sourceMappingURL=steam-receipt-bridge.js.map
