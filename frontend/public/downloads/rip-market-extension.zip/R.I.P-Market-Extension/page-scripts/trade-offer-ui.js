"use strict";
(() => {
  // src/shared/trade-offer-messages.ts
  var TRADE_OFFER_BRIDGE_SOURCE = "rip-market-trade-offer-bridge";
  var TRADE_OFFER_PAGE_SOURCE = "rip-market-trade-offer-page";
  var STEAM_BRIDGE_MESSAGE = {
    RUN_AUTOFILL_FLOW: "RUN_AUTOFILL_FLOW"
  };

  // ../extension/src/steam-offer-id.util.ts
  var STEAM_OFFER_ID_PATTERN = /^\d{6,20}$/;
  function isValidSteamOfferId(offerId) {
    return STEAM_OFFER_ID_PATTERN.test(offerId.trim());
  }
  function normalizeSteamOfferId(offerId) {
    if (offerId === null || offerId === void 0) {
      return null;
    }
    const normalized = String(offerId).trim();
    return isValidSteamOfferId(normalized) ? normalized : null;
  }

  // src/shared/trade-offer-send-errors.ts
  function parseSteamSendResponse(parsed) {
    const strError = parsed.strError?.trim() ?? "";
    const normalizedOfferId = normalizeSteamOfferId(parsed.tradeofferid);
    if (normalizedOfferId) {
      return {
        ok: true,
        offerId: normalizedOfferId,
        confirmPending: Boolean(parsed.needs_mobile_confirmation),
        strError: strError || void 0
      };
    }
    if (strError) {
      return { ok: false, error: strError, strError };
    }
    return { ok: false, error: "Offer send failed" };
  }

  // src/page-scripts/trade-offer-ui.ts
  var CS2_APP_ID = 730;
  var CS2_CONTEXT = 2;
  var DEFAULT_TRADE_NOTE = "R.I.P Market trade";
  var PAGE_SCRIPT_ID = "rip-market-trade-offer-ui";
  function getSteamWindow() {
    return window;
  }
  function clickElement(selector) {
    const win = getSteamWindow();
    const jquery = win.$J ?? win.jQuery;
    if (jquery) {
      jquery(selector).click();
      return;
    }
    document.querySelector(selector)?.click();
  }
  function prepareYourInventory() {
    clickElement("#inventory_select_your_inventory");
  }
  function readActiveAppId(win) {
    if (typeof win.g_ActiveAppId === "number" && Number.isFinite(win.g_ActiveAppId)) {
      return win.g_ActiveAppId;
    }
    const inventory = win.g_ActiveInventory;
    const raw = Number(inventory?.appid ?? inventory?.m_appid);
    return Number.isFinite(raw) ? raw : null;
  }
  function requestCs2Inventory() {
    const win = getSteamWindow();
    if (typeof win.SelectInventory === "function") {
      try {
        win.SelectInventory(CS2_APP_ID, CS2_CONTEXT);
      } catch {
      }
    }
    clickElement("#inventory_select_your_inventory");
    for (const selector of [
      "#appselect_you",
      "#appselect",
      "#appselect_activeapp",
      ".appselect_activeapp"
    ]) {
      clickElement(selector);
    }
    const optionIds = [
      "appselect_option_you_730_2",
      "appselect_option_you_730_16",
      "appselect_option_you_730",
      "appselect_you_app_730"
    ];
    for (const id of optionIds) {
      const option = document.getElementById(id);
      if (option) {
        option.click();
        return;
      }
    }
    const labeled = Array.from(
      document.querySelectorAll(
        "#appselect_applist .appselect_option, .appselect_option"
      )
    ).find((el) => {
      if (el.id.includes("_them_")) {
        return false;
      }
      const text = (el.textContent ?? "").toLowerCase();
      return text.includes("counter-strike") || /\bcs2\b/.test(text) || el.id.includes("730");
    });
    labeled?.click();
  }
  function ensureCs2InventoryActive() {
    requestCs2Inventory();
  }
  function isCs2TradeInventoryReady(assetId) {
    if (assetId && findAssetElement(CS2_APP_ID, CS2_CONTEXT, assetId)) {
      return true;
    }
    if (assetId && isTradeItemVisibleInDom(assetId)) {
      return true;
    }
    const win = getSteamWindow();
    const inventoryBox = document.getElementById("inventory_730_2") ?? document.getElementById("inventory_730_16") ?? document.querySelector('#inventories [id^="inventory_730"]');
    if (inventoryBox && inventoryBox.style.display !== "none") {
      const hasCells = Boolean(
        inventoryBox.querySelector(".item, .itemHolder .item, .itemHolder")
      );
      if (hasCells) {
        return true;
      }
    }
    return readActiveAppId(win) === CS2_APP_ID && Boolean(win.UserYou) && Boolean(win.g_ActiveInventory);
  }
  async function waitForTradePageReady(timeoutMs = 15e3, assetId) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      prepareYourInventory();
      requestCs2Inventory();
      if (isCs2TradeInventoryReady(assetId)) {
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
    throw new Error(
      "CS2 inventory did not load. Select Counter-Strike 2 in the inventory list, then retry."
    );
  }
  function findAssetElement(appId, contextId, assetId) {
    const win = getSteamWindow();
    const found = win.UserYou?.findAsset(
      appId,
      String(contextId),
      String(assetId)
    );
    if (found?.element instanceof HTMLElement) {
      return found.element;
    }
    return null;
  }
  function isTradeItemVisibleInDom(assetId) {
    return Boolean(
      document.getElementById(`asset_730_2_${assetId}`) ?? document.getElementById(`item730_2_${assetId}`) ?? document.querySelector(`[data-assetid="${assetId}"]`)
    );
  }
  function selectItemViaDom(appId, contextId, assetId) {
    const elementIds = [
      `asset_${appId}_${contextId}_${assetId}`,
      `asset_${appId}_2_${assetId}`,
      `item${appId}_${contextId}_${assetId}`,
      `item${appId}_2_${assetId}`
    ];
    for (const elementId of elementIds) {
      const element = document.getElementById(elementId);
      if (element) {
        element.click();
        return true;
      }
    }
    const byData = document.querySelector(
      `[data-assetid="${assetId}"], [data-id="${assetId}"]`
    );
    if (byData instanceof HTMLElement) {
      byData.click();
      return true;
    }
    return false;
  }
  function isItemInTradeOffer(assetId) {
    const selectors = [
      `#trade_slot_drag_target .item[data-assetid="${assetId}"]`,
      `#your_slots .item[data-assetid="${assetId}"]`,
      `#your_slots .item[id$="_${assetId}"]`,
      `#your_slots #item730_2_${assetId}`,
      `#trade_items .item[id$="_${assetId}"]`,
      `.tradeoffer_items_ctn .item[id$="_${assetId}"]`
    ];
    for (const selector of selectors) {
      if (document.querySelector(selector)) {
        return true;
      }
    }
    return false;
  }
  function selectItemForTrade(appId = CS2_APP_ID, contextId = CS2_CONTEXT, assetId) {
    prepareYourInventory();
    requestCs2Inventory();
    const win = getSteamWindow();
    const element = findAssetElement(appId, contextId, assetId);
    if (element && typeof win.MoveItemToTrade === "function") {
      win.MoveItemToTrade(element);
      return;
    }
    if (selectItemViaDom(appId, contextId, assetId)) {
      return;
    }
    throw new Error(`Item ${assetId} not found in trade inventory`);
  }
  async function selectItemForTradeWithRetry(assetId, timeoutMs = 15e3) {
    const deadline = Date.now() + timeoutMs;
    let lastError = `Item ${assetId} not found in trade inventory`;
    while (Date.now() < deadline) {
      try {
        selectItemForTrade(CS2_APP_ID, CS2_CONTEXT, assetId);
        await new Promise((resolve) => setTimeout(resolve, 400));
        if (isItemInTradeOffer(assetId)) {
          return;
        }
        lastError = `Item ${assetId} was clicked but not added to trade offer`;
      } catch (error) {
        lastError = error instanceof Error ? error.message : lastError;
      }
      await new Promise((resolve) => setTimeout(resolve, 300));
    }
    throw new Error(lastError);
  }
  function setTradeNote(text) {
    const noteInput = document.querySelector("#trade_offer_note");
    if (!noteInput) {
      throw new Error("Trade note field not found");
    }
    noteInput.value = text;
    noteInput.dispatchEvent(new Event("input", { bubbles: true }));
  }
  function clickReadyIfPresent() {
    const readyButton = document.querySelector("#trade_confirmbtn");
    if (readyButton && readyButton.style.display !== "none") {
      readyButton.click();
    }
  }
  function submitTradeOffer() {
    const win = getSteamWindow();
    clickReadyIfPresent();
    if (typeof win.ConfirmTradeOffer === "function") {
      win.ConfirmTradeOffer();
      return;
    }
    const confirmButton = document.querySelector(
      "#trade_confirm_ok_btn"
    );
    if (confirmButton) {
      confirmButton.click();
      return;
    }
    const sendButton = document.querySelector("#trade_confirmbtn");
    if (sendButton) {
      sendButton.click();
      return;
    }
    throw new Error("Send button not available on trade page");
  }
  function installSendInterceptor(timeoutMs = 3e4) {
    return new Promise((resolve, reject) => {
      const win = getSteamWindow();
      const jquery = win.$J ?? win.jQuery;
      if (!jquery) {
        reject(new Error("Steam jQuery ($J) not available"));
        return;
      }
      const boundJquery = jquery;
      const timeout = window.setTimeout(() => {
        boundJquery(document).off("ajaxComplete", onAjaxComplete);
        reject(new Error("Send interceptor timeout"));
      }, timeoutMs);
      function onAjaxComplete(_event, xhr, settings) {
        const url = settings.url ?? "";
        if (!url.includes("tradeoffer/new/send")) {
          return;
        }
        window.clearTimeout(timeout);
        boundJquery(document).off("ajaxComplete", onAjaxComplete);
        const responseText = xhr.responseText ?? "";
        if (!responseText || responseText === "null") {
          reject(new Error("Steam returned empty send response"));
          return;
        }
        try {
          resolve(JSON.parse(responseText));
        } catch {
          reject(
            new Error(
              `Steam returned invalid send JSON: ${responseText.slice(0, 200)}`
            )
          );
        }
      }
      boundJquery(document).ajaxComplete(onAjaxComplete);
    });
  }
  var preparedDraft = null;
  function hasExactPreparedComposition(draft) {
    const status = window.g_rgCurrentTradeStatus;
    const assets = status?.me?.assets;
    if (!assets || !status?.them || assets.length !== 1 || (status.them.assets?.length ?? 0) !== 0 || (status.me?.currency?.length ?? 0) !== 0 || (status.them.currency?.length ?? 0) !== 0)
      return false;
    const item = assets[0];
    const actual = new URL(window.location.href);
    const expected = new URL(draft.buyerTradeUrl);
    return actual.origin === expected.origin && actual.pathname.replace(/\/$/, "") === "/tradeoffer/new" && actual.searchParams.get("partner") === expected.searchParams.get("partner") && actual.searchParams.get("token") === expected.searchParams.get("token") && Number(item.appid) === CS2_APP_ID && String(item.contextid) === String(CS2_CONTEXT) && String(item.assetid) === draft.item.assetId && Number(item.amount) === 1;
  }
  async function prepareAndSelectItem(draft) {
    if (!window.location.pathname.includes("/tradeoffer/new")) {
      return { ok: false, error: "Not on Steam trade offer page" };
    }
    try {
      await waitForTradePageReady(3e4, draft.item.assetId);
      await selectItemForTradeWithRetry(draft.item.assetId);
      setTradeNote(draft.note?.trim() || DEFAULT_TRADE_NOTE);
      preparedDraft = draft;
      if (!hasExactPreparedComposition(draft))
        return {
          ok: false,
          error: "Offer composition or recipient does not match the order"
        };
      return { ok: true };
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : "Trade offer prepare failed"
      };
    }
  }
  async function submitAndWaitForSend() {
    try {
      if (!preparedDraft || !hasExactPreparedComposition(preparedDraft))
        return {
          ok: false,
          error: "Offer composition changed or cannot be verified"
        };
      const sendingDraft = preparedDraft;
      preparedDraft = null;
      const interceptor = installSendInterceptor();
      submitTradeOffer();
      const steamResponse = await interceptor;
      const result = parseSteamSendResponse(steamResponse);
      if (result.ok && sendingDraft.draftId)
        window.postMessage(
          {
            source: TRADE_OFFER_PAGE_SOURCE,
            type: "SEND_RESULT",
            draftId: sendingDraft.draftId,
            assetId: sendingDraft.item.assetId,
            buyerTradeUrl: sendingDraft.buyerTradeUrl,
            result
          },
          window.location.origin
        );
      return result;
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : "Trade offer send failed"
      };
    }
  }
  async function runAutofillFlow(draft) {
    const prepared = await prepareAndSelectItem(draft);
    if (!prepared.ok) {
      return prepared;
    }
    return submitAndWaitForSend();
  }
  function postPageResponse(requestId, result) {
    const message = {
      source: TRADE_OFFER_PAGE_SOURCE,
      requestId,
      result
    };
    window.postMessage(message, "*");
  }
  function handleBridgeMessage(event) {
    if (event.source !== window) {
      return;
    }
    const data = event.data;
    if (!data || data.source !== TRADE_OFFER_BRIDGE_SOURCE) {
      return;
    }
    if (data.type !== STEAM_BRIDGE_MESSAGE.RUN_AUTOFILL_FLOW) {
      return;
    }
    void runAutofillFlow(data.payload).then((result) => postPageResponse(data.requestId, result)).catch((error) => {
      postPageResponse(data.requestId, {
        ok: false,
        error: error instanceof Error ? error.message : "Autofill flow failed"
      });
    });
  }
  function bootstrapPageScript() {
    const api = {
      runAutofillFlow,
      prepareAndSelectItem,
      submitAndWaitForSend
    };
    if (document.getElementById(PAGE_SCRIPT_ID)) {
      getSteamWindow().__ripMarketTradeOffer = api;
      return;
    }
    const marker = document.createElement("meta");
    marker.id = PAGE_SCRIPT_ID;
    marker.setAttribute("data-rip-market", "trade-offer-ui");
    document.documentElement.appendChild(marker);
    getSteamWindow().__ripMarketTradeOffer = api;
    document.documentElement.setAttribute(
      "data-rip-market-trade-offer-ui",
      "ready"
    );
    window.addEventListener("message", handleBridgeMessage);
  }
  bootstrapPageScript();
})();
//# sourceMappingURL=trade-offer-ui.js.map
